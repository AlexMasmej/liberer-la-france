import json
from pathlib import Path

sources = json.loads(Path('source.json').read_text())
drafts = {}


def add(number, xml, reason, notes):
    assert number not in drafts
    drafts[number] = {
        'proposed_xml': xml.strip(),
        'reason': reason,
        'review_notes': notes,
        'status': 'rewrite_draft',
    }


add('49 K', '''
<p>Si le début ou le terme de la période d'exonération prévue au I de l'article 44 octies A ne correspond pas au début ou au terme de l'année ou de l'exercice d'imposition, les fractions du bénéfice imposable et du bénéfice exonéré sont déterminées au prorata du temps.</p>
''', "Réécriture à droit constant : la condition de décalage de la période d'exonération et son effet sur les deux fractions du bénéfice sont exprimés directement. Aucune réforme de fond n'est appliquée à ce régime territorial.", "Renvoi au I de l'article 44 octies A conservé. Le prorata concerne à la fois le bénéfice imposable et le bénéfice exonéré ; aucune durée d'exonération n'est modifiée.")

add('49 L', '''
<p>Le contribuable qui remplit les conditions pour bénéficier de l'article 44 octies A du code général des impôts doit joindre à sa déclaration de résultat, pour la période d'imposition considérée, un document conforme au modèle établi par l'administration. Ce document contient les éléments nécessaires pour déterminer le bénéfice ouvrant droit à exonération.</p>
''', "Réécriture à droit constant : l'obligation de joindre le document et le contenu de celui-ci sont répartis entre deux phrases, dans le même alinéa. Aucune suppression de formalité ni réforme de l'exonération n'est introduite.", "Modèle administratif, déclaration destinataire et période d'imposition conservés. La note relative à l'article 35-I-3° a de la loi n° 2021-1900 du 30 décembre 2021 est historique ; elle ne fixe pas l'entrée en vigueur d'une réforme future. L'objectif de réemploi des données ne vaut pas dispense générale de cette pièce.")

add('49 N', '''
<p>Les bailleurs d'immeubles mentionnés au 5° du I de l'article 35 du code général des impôts qui bénéficient de l'article 44 octies A du même code doivent joindre à leur déclaration de résultat, pour chaque période d'imposition des bénéfices, un document indiquant le lieu d'implantation de chaque immeuble donné à bail. Si leurs moyens d'exploitation ne sont pas tous situés dans les zones franches urbaines-territoires entrepreneurs, ils doivent aussi annexer à cette déclaration un compte séparé indiquant, pour chaque immeuble situé dans ces zones, le bénéfice net tiré de son exploitation.</p>
''', "Réécriture à droit constant : les bailleurs concernés sont désignés explicitement et la condition imposant le compte séparé est formulée plus directement. Les deux obligations documentaires et leur champ sont maintenus, sans réforme de fond.", "Conserver la distinction entre le document relatif à chaque immeuble donné à bail et le compte relatif à chaque immeuble situé dans les zones. Le compte séparé reste exigé lorsque tous les moyens d'exploitation ne sont pas situés dans ces zones. La note de coordination de la loi n° 2021-1900 du 30 décembre 2021 reste une indication historique.")

add('49 O', '''
<p>Le contribuable qui transfère une activité dans une zone franche urbaine-territoire entrepreneur doit indiquer le ou les lieux où il exerçait auparavant cette activité, ainsi que le service des impôts auprès duquel les déclarations de résultat ont été déposées. Il doit également préciser, le cas échéant, la nature et le montant des subventions et des aides que l'État et les collectivités publiques lui ont accordées.</p>
''', "Réécriture à droit constant : le contribuable est le sujet explicite des deux obligations et les informations relatives à l'activité antérieure sont formulées en termes directs. Aucune condition nouvelle de transfert ou d'aide n'est créée.", "Maintien de l'ensemble des lieux antérieurs, du service fiscal et, le cas échéant, de la nature et du montant des aides et subventions. La note visant l'article 48-III de la loi n° 2014-1655 du 29 décembre 2014 concerne une modification passée. Aucun support ou délai absent de la source n'est ajouté.")

add('49 P', '''
<p>Le contribuable notifie l'option mentionnée au troisième alinéa du III de l'article 44 octies A du code général des impôts, sur papier libre, au service des impôts auprès duquel il dépose sa déclaration de résultat.</p>
''', "Réécriture à droit constant : la notification est mise à la voix active et son auteur est explicité. Le support et le service destinataire sont maintenus ; aucune réforme de fond n'est introduite.", "Le troisième alinéa du III de l'article 44 octies A porte bien l'option entre régimes dans le corpus local. Papier libre conservé. La note visant la loi n° 2021-1900 du 30 décembre 2021 ne constitue pas une date de réforme future.")

add('49 Q', '''
<p>L'entreprise satisfait aux indicateurs de performance économique mentionnés au c du 3° de l'article 44 sexies-0 A du code général des impôts si elle remplit les deux conditions suivantes à la clôture de l'exercice :</p>
<p>a) Son effectif, calculé selon les modalités prévues aux articles L. 1111-2, L. 1111-3 et L. 1251-54 du code du travail, a augmenté à la fois d'au moins 100 % et d'au moins dix salariés en équivalents temps plein par rapport à l'effectif constaté à la clôture de l'antépénultième exercice ;</p>
<p>b) Le montant des dépenses de recherche mentionnées au c du 3° du même article 44 sexies-0 A qu'elle a engagées au cours de cet exercice est au moins égal à celui de l'exercice précédent.</p>
<p>Pour appliquer le présent article, la durée de l'exercice est, si nécessaire, ramenée ou portée à douze mois.</p>
''', "Réécriture à droit constant : le caractère cumulatif des deux critères et des deux seuils d'effectif est rendu explicite ; la non-diminution des dépenses est exprimée par une comparaison directe. Aucune réforme de fond des critères de jeune entreprise innovante n'est appliquée.", "Contrôles : hausse d'au moins 100 % ET d'au moins dix équivalents temps plein ; comparaison d'effectif avec l'antépénultième exercice, et comparaison des dépenses avec l'exercice précédent. Renvois au code du travail conservés. La note source fixe l'entrée en vigueur existante au 1er juin 2024, en application de l'article 2 du décret n° 2024-464 du 24 mai 2024 ; cette date n'est pas celle d'une réforme à venir.")

add('49 U', '''
<p>Si le début ou le terme de la période d'exonération prévue au I de l'article 44 duodecies du code général des impôts ne correspond pas au début ou au terme de l'année ou de l'exercice d'imposition, les fractions du bénéfice imposable et du bénéfice exonéré sont déterminées au prorata du temps.</p>
''', "Réécriture à droit constant : la condition de décalage temporel et la règle de calcul des deux fractions du bénéfice sont simplifiées dans un alinéa unique. Aucune réforme de fond du régime des bassins d'emploi à redynamiser n'est introduite.", "Renvoi au I de l'article 44 duodecies conservé. La règle reste un prorata temporel, sans changement de durée ni de champ de l'exonération.")

add('49 V', '''
<p>Le contribuable qui remplit les conditions pour bénéficier de l'article 44 duodecies du code général des impôts doit joindre à sa déclaration de résultat, pour chaque période d'imposition des bénéfices, les documents suivants :</p>
<p>1. Un document conforme au modèle établi par l'administration, contenant les éléments nécessaires pour déterminer et suivre le bénéfice ouvrant droit à exonération et pour vérifier le respect des conditions et limites prévues par les règlements mentionnés au huitième alinéa du II de l'article 44 duodecies du code général des impôts ;</p>
<p>2. Le cas échéant, s'il est bailleur d'immeubles mentionné au 5° du I de l'article 35 du code général des impôts, un document indiquant le lieu d'implantation de chaque immeuble donné à bail. Si ses moyens d'exploitation ne sont pas tous situés dans les bassins d'emploi à redynamiser, il doit également annexer à sa déclaration de résultat un compte séparé indiquant, pour chaque immeuble situé dans ces bassins, le bénéfice net tiré de son exploitation ;</p>
<p>3. Le cas échéant, s'il transfère une activité dans un bassin d'emploi à redynamiser, un état indiquant les lieux où l'activité était exercée auparavant, le service des impôts auprès duquel les déclarations de résultat ont été déposées, ainsi que la nature et le montant des subventions et des aides accordées par l'État et les collectivités publiques.</p>
''', "Réécriture à droit constant : les trois pièces restent numérotées et leurs conditions sont formulées avec le contribuable pour sujet. Le compte séparé est distingué du document de localisation au sein du même 2. Aucune réforme de fond ni dispense déclarative n'est introduite.", "Le huitième alinéa du II de l'article 44 duodecies vise les règlements d'aides dans le corpus local ; numérotation 1., 2., 3. conservée. Le document de localisation vise chaque immeuble donné à bail ; le compte vise chaque immeuble situé dans les bassins et reste conditionné à la présence de moyens d'exploitation hors de ceux-ci. Les informations sur les transferts sont toutes conservées.")

add('49 W', '''
<p>Le contribuable notifie l'option mentionnée au deuxième alinéa du III de l'article 44 duodecies du code général des impôts au service des impôts auprès duquel il dépose sa déclaration de résultat. Il utilise pour cette notification un document conforme au modèle établi par l'administration.</p>
''', "Réécriture à droit constant : l'auteur et le destinataire de la notification sont explicités, puis le support imposé est précisé dans une seconde phrase du même alinéa. Aucune réforme de fond n'est introduite.", "L'option du deuxième alinéa du III est distincte de l'option relative aux aides mentionnée au II de l'article 44 duodecies. Modèle administratif conservé, sans lui substituer le papier libre prévu pour d'autres régimes.")

add('49 X', '''
<p>Si le début ou le terme de la période d'exonération prévue au I de l'article 44 terdecies du code général des impôts ne correspond pas au début ou au terme de l'année ou de l'exercice d'imposition, les fractions du bénéfice imposable et du bénéfice exonéré sont déterminées au prorata du temps.</p>
''', "Réécriture à droit constant : la condition et la conséquence du décalage entre période d'exonération et période d'imposition sont exprimées directement. Aucune réforme de fond des zones de restructuration de la défense n'est introduite.", "Renvoi au I de l'article 44 terdecies et calcul temporel des deux fractions du bénéfice conservés. Aucune durée ou condition d'implantation n'est modifiée.")

add('49 Y', '''
<p>Le contribuable qui remplit les conditions pour bénéficier de l'article 44 terdecies du code général des impôts joint à sa déclaration de résultat, pour chaque période d'imposition des bénéfices, les documents suivants :</p>
<p>1. Un document conforme au modèle établi par l'administration, contenant les éléments nécessaires pour déterminer et suivre le bénéfice ouvrant droit à exonération et pour vérifier le respect des conditions et limites prévues par les règlements mentionnés au huitième alinéa du II de l'article 44 terdecies précité ;</p>
<p>2. Le cas échéant, s'il est bailleur d'immeubles mentionné au 5° du I de l'article 35 du code général des impôts, un document indiquant le lieu d'implantation de chaque immeuble donné à bail. Il doit également annexer à sa déclaration de résultat un compte séparé indiquant, pour chaque immeuble situé dans les zones de restructuration de la défense et les emprises foncières libérées mentionnées au premier alinéa du I de l'article 44 terdecies précité, le bénéfice net tiré de son exploitation, si ses moyens d'exploitation ne sont pas tous situés dans ces zones ;</p>
<p>3. Le cas échéant, s'il transfère une activité dans une zone de restructuration de la défense ou une emprise foncière libérée mentionnées au premier alinéa du I de l'article 44 terdecies précité, un état indiquant les lieux où l'activité était exercée auparavant, le service des impôts auprès duquel les déclarations de résultat ont été déposées, ainsi que la nature et le montant des subventions et des aides accordées par l'État et les collectivités publiques.</p>
''', "Réécriture à droit constant : les obligations sont rattachées explicitement au contribuable et la longue phrase du 2. est scindée, sans déplacer son contenu dans un autre alinéa. Les zones, emprises et informations exigées sont maintenues ; aucune réforme de fond n'est introduite.", "Renvois aux premier alinéa du I et huitième alinéa du II de l'article 44 terdecies vérifiés dans le corpus local. Au 2., l'expression source « ces zones » pour la localisation des moyens d'exploitation ne désigne pas expressément les emprises foncières libérées : cette ambiguïté préexistante est conservée et appelle un contrôle de portée, sans extension silencieuse. Le document de localisation et le compte séparé restent distincts.")

add('49 Z', '''
<p>Le contribuable notifie l'option mentionnée au deuxième alinéa du III de l'article 44 terdecies du code général des impôts, sur papier libre, au service des impôts auprès duquel il dépose sa déclaration de résultat.</p>
''', "Réécriture à droit constant : la notification est formulée à la voix active, avec désignation de son auteur. Le support et le destinataire sont conservés ; aucune réforme de fond n'est introduite.", "Le deuxième alinéa du III de l'article 44 terdecies porte l'option entre régimes. Maintien du papier libre ; aucun modèle administratif ou délai supplémentaire n'est ajouté.")

add('49 ZA', '''
<p>Les règles suivantes régissent l'application du 2° du III de l'article 44 quaterdecies du code général des impôts :</p>
<p>1° Un établissement public de coopération intercommunale est considéré comme particulièrement défavorisé si son taux de pauvreté dépasse 40 %.</p>
<p>Le taux de pauvreté mentionné au premier alinéa correspond à la part de la population de l'établissement public de coopération intercommunale dont le revenu disponible est inférieur à 60 % du revenu disponible médian. L'Institut national de la statistique et des études économiques établit ce taux à l'échelle de l'établissement public de coopération intercommunale, à partir des données disponibles pour l'année 2021 ;</p>
<p>2° Sont éligibles les communes de Bras-Panon, de La Plaine-des-Palmistes, de Saint-André, de Saint-Benoît, de Sainte-Rose et de Salazie.</p>
''', "Réécriture à droit constant : les deux seuils stricts sont exprimés directement, l'organisme chargé du calcul devient le sujet de la phrase et la liste des communes est conservée intégralement. Aucune réforme de fond des abattements ultramarins n'est introduite.", "Seuils conservés : taux de pauvreté strictement supérieur à 40 %, revenu disponible strictement inférieur à 60 % de la médiane ; données de 2021 et six communes inchangées. Imprécision préexistante : « mentionné au premier alinéa » est conservé, alors que le taux figure dans l'alinéa numéroté 1°, après l'alinéa introductif ; une coordination expresse de ce renvoi serait à examiner. Le champ et les périodes d'application demeurent ceux du 2° du III de l'article 44 quaterdecies, sans pérennisation implicite.")

add('49 ZB', '''
<p>I. – 1. Le contribuable qui remplit les conditions pour bénéficier de l'article 44 quaterdecies du code général des impôts joint à sa déclaration de résultat, pour chaque période d'imposition des bénéfices, un document conforme au modèle établi par l'administration. Ce document contient les éléments nécessaires pour déterminer et suivre le bénéfice ouvrant droit à abattement et pour vérifier le respect des conditions prévues par cet article. Il indique notamment :</p>
<p>1° Le chiffre d'affaires de l'exercice, ramené, le cas échéant, à douze mois, et l'effectif salarié à la clôture de l'exercice ;</p>
<p>2° L'adresse et l'activité principale de chaque exploitation dont les bénéfices peuvent ouvrir droit à l'abattement, le montant de ces bénéfices, le taux d'abattement applicable et les modalités de répartition du bénéfice global de l'entreprise entre ces exploitations ;</p>
<p>3° (Sans objet)</p>
<p>4° Si le contribuable remplit les conditions pour bénéficier du b du 4° du III de l'article 44 quaterdecies du code général des impôts, la référence de l'autorisation délivrée par le service des douanes pour bénéficier du régime de perfectionnement actif défini à l'article 256 du règlement (UE) n° 952/2013 du Parlement européen et du Conseil du 9 octobre 2013 établissant le code des douanes de l'Union, ainsi que le montant du chiffre d'affaires correspondant aux opérations mettant en œuvre des marchandises ayant bénéficié de ce régime.</p>
<p>2. (Abrogé)</p>
<p>3. Si l'entreprise n'est pas soumise à un régime réel d'imposition, le contribuable joint le document mentionné au 1 à sa déclaration d'ensemble des revenus.</p>
<p>II. – Le contribuable notifie l'option mentionnée au VII de l'article 44 quaterdecies du code général des impôts, sur papier libre, au service des impôts auprès duquel est déposée la déclaration de résultat de l'entreprise ou, si celle-ci n'est pas soumise à un régime réel d'imposition, sa déclaration d'ensemble des revenus.</p>
''', "Réécriture à droit constant : le contenu du document est séparé de l'obligation de dépôt et la déclaration applicable hors régime réel est explicitée. Les subdivisions, mentions sans objet et abrogées, données requises et modalités de l'option sont conservées. Aucune réforme de fond ou dispense documentaire n'est introduite.", "Maintien de I.1, des 1° à 4°, de I.2 abrogé, de I.3 et de II. Les renvois au b du 4° du III et au VII de l'article 44 quaterdecies concordent avec le corpus local. L'article 256 du règlement (UE) n° 952/2013 et sa date du 9 octobre 2013 sont conservés. Le chiffre d'affaires est seulement « ramené », et non porté, à douze mois, comme dans la source ; aucune règle de réemploi des données non définie n'écarte ces justificatifs.")

add('49 ZC', '''
<p>I. – 1. Pour l'application du a du 3° du III de l'article 44 quaterdecies du code général des impôts, le secteur de la recherche et du développement comprend les activités suivantes :</p>
<p>1° Recherche-développement en biotechnologie ;</p>
<p>2° Recherche-développement en autres sciences physiques et naturelles ;</p>
<p>3° Recherche-développement en sciences humaines et sociales.</p>
<p>2. Pour l'application du b du 3° du III de l'article 44 quaterdecies du code général des impôts, le secteur des technologies de l'information et de la communication comprend les activités suivantes :</p>
<p>1° Télécommunications filaires ;</p>
<p>2° Télécommunications sans fil ;</p>
<p>3° Télécommunications par satellite ;</p>
<p>4° Autres activités de télécommunication ;</p>
<p>5° Programmation informatique ;</p>
<p>6° (Abrogé) ;</p>
<p>7° Tierce maintenance de systèmes et d'applications informatiques ;</p>
<p>8° Gestion d'installations informatiques ;</p>
<p>9° Autres activités informatiques ;</p>
<p>10° Traitement de données, hébergement et activités connexes ;</p>
<p>11° Portails internet ;</p>
<p>12° Activités cinématographiques, vidéo et de télévision, y compris la production audiovisuelle ;</p>
<p>13° Programmation et diffusion ;</p>
<p>14° Conception, réalisation et productions rédactionnelles, multimédia, flux informatiques et numériques, y compris la presse produite localement et les activités qui s'y rapportent ;</p>
<p>3. Pour l'application du c du 3° du III de l'article 44 quaterdecies du code général des impôts, le secteur du tourisme comprend les activités suivantes :</p>
<p>1° Hôtels et hébergement similaire ;</p>
<p>2° Hébergement touristique et autre hébergement de courte durée ;</p>
<p>3° Terrains de camping et parcs pour caravanes ou véhicules de loisirs ;</p>
<p>4° Activités des parcs d'attractions et parcs à thèmes, sauf l'exploitation de jeux d'argent et de hasard ;</p>
<p>5° Autres activités récréatives et de loisirs, sauf l'exploitation de jeux d'argent et de hasard, à condition qu'elles s'intègrent directement et à titre principal à une activité hôtelière ou touristique ;</p>
<p>6° Enseignement de disciplines sportives et d'activités de loisirs, à condition que ces activités s'intègrent directement et à titre principal à une activité hôtelière ou touristique ;</p>
<p>7° Activités liées au sport, à condition qu'elles s'intègrent directement et à titre principal à une activité hôtelière ou touristique ;</p>
<p>8° Entretien corporel, limité aux activités thermales, de balnéothérapie ou de thalassothérapie ;</p>
<p>9° Location de courte durée de voitures et de véhicules automobiles légers, limitée aux locations de moins d'un mois ; la part de cette activité réalisée dans le cadre de prestations touristiques peut être évaluée à 75 % du bénéfice tiré de ces locations ;</p>
<p>10° Transports maritimes et côtiers de passagers, y compris l'exploitation de bateaux d'excursion, de croisière ou de tourisme, au départ et à destination des départements d'outre-mer, sauf l'exploitation de lignes régulières ;</p>
<p>11° Transports fluviaux de passagers, y compris l'exploitation de bateaux d'excursion, de croisière ou de tourisme, au départ et à destination des départements d'outre-mer, sauf l'exploitation de lignes régulières ;</p>
<p>12° Transports aériens de passagers, y compris les vols de tourisme, au départ et à destination des départements d'outre-mer, sauf l'exploitation de lignes régulières et à condition que ces activités s'intègrent directement et à titre principal à une activité touristique ;</p>
<p>13° Transports de voyageurs par taxis ; la part de cette activité réalisée dans le cadre de prestations touristiques peut être évaluée à 50 % du bénéfice ;</p>
<p>14° Autres transports routiers de voyageurs, sauf l'exploitation de lignes régulières ;</p>
<p>15° Activités des agences de voyage, voyagistes, services de réservation et activités connexes, lorsqu'ils sont physiquement implantés sur le territoire du département d'outre-mer ;</p>
<p>16° Organisation de foires, salons professionnels et congrès ;</p>
<p>17° Restauration traditionnelle ; la part de cette activité réalisée dans le cadre de prestations touristiques peut être évaluée à 50 % du bénéfice.</p>
<p>4. Pour l'application du d du 3° du III de l'article 44 quaterdecies du code général des impôts, le secteur de l'agro-nutrition comprend les activités suivantes :</p>
<p>1° Culture et production animale, chasse et services annexes ;</p>
<p>2° Sylviculture et exploitation forestière ;</p>
<p>3° Pêche et aquaculture ;</p>
<p>4° Industries alimentaires ;</p>
<p>5° Fabrication de boissons.</p>
<p>5. Pour l'application du e du 3° du III de l'article 44 quaterdecies du code général des impôts, le secteur de l'environnement comprend les activités suivantes :</p>
<p>1° Captage, traitement et distribution d'eau ;</p>
<p>2° Collecte et traitement des eaux usées ;</p>
<p>3° Collecte des déchets non dangereux ;</p>
<p>4° Collecte des déchets dangereux ;</p>
<p>5° Traitement et élimination des déchets non dangereux ;</p>
<p>6° Traitement et élimination des déchets dangereux ;</p>
<p>7° Démantèlement d'épaves ;</p>
<p>8° Récupération de déchets triés ;</p>
<p>9° Dépollution et autres services de gestion des déchets ;</p>
<p>10° Travaux d'isolation thermique.</p>
<p>6. Pour l'application du f du 3° du III de l'article 44 quaterdecies du code général des impôts, le secteur des énergies renouvelables comprend les activités suivantes :</p>
<p>1° Production d'électricité à partir d'énergies renouvelables : production éolienne, géothermique, hydraulique, marémotrice, solaire, ou à partir de la biomasse ou de la mer ;</p>
<p>2° Production de combustibles gazeux à partir d'énergies renouvelables : production éolienne, géothermique, hydraulique, marémotrice, solaire, ou à partir de la biomasse ou de la mer ;</p>
<p>3° Production de vapeur et d'air conditionné à partir d'énergie renouvelable : production éolienne, géothermique, hydraulique, marémotrice, solaire, ou à partir de la biomasse ou de la mer.</p>
<p>4° Production ou pose d'équipements ou d'installations destinés à réduire la consommation d'énergie ou à améliorer la performance énergétique de tout type de construction, ainsi qu'installation d'équipements thermiques, à condition que ces équipements respectent les normes d'éco-conditionnalité fixées par arrêté.</p>
<p>II. – Sauf disposition contraire, les secteurs mentionnés au I correspondent à ceux de la nomenclature d'activités françaises, selon les activités que ses rubriques incluent ou excluent. L'activité réellement exercée est seule prise en compte.</p>
''', "Réécriture à droit constant : les six rattachements sectoriels sont formulés directement, les conditions et exclusions sont clarifiées dans leurs alinéas d'origine et la règle de nomenclature est scindée en deux phrases. Les intitulés d'activités sont conservés lorsqu'ils identifient les catégories ; les listes ne sont ni abrégées ni remplacées par un résumé. Aucune réforme de fond du champ des activités n'est introduite.", "Contrôle intégral des six listes : 3, 14 (dont le 6° abrogé), 17, 5, 10 et 4 entrées. Maintien des exclusions des jeux d'argent et de hasard, des lignes régulières, de l'intégration directe et principale aux activités hôtelières ou touristiques, de l'implantation physique et des normes d'éco-conditionnalité. Locations strictement inférieures à un mois ; évaluations facultatives à 75 %, 50 % et 50 % conservées. Renvois a à f du 3° du III de l'article 44 quaterdecies et règle d'activité réellement exercée maintenus. Aucune extension aux autres secteurs de cet article du CGI n'est déduite de la présente énumération.")

add('49 bis', '''
<p>Le remboursement, effectué depuis le 1er janvier 1960, de sommes versées à titre d'avances, de prêts ou d'acomptes par une personne morale mentionnée à l'article 108 du code général des impôts ouvre droit à restitution lorsque ces sommes ont été considérées, lors de leur versement, comme des revenus distribués en application du a de l'article 111 du même code ou de l'article 41 du décret n° 48-1986 du 9 décembre 1948. La restitution porte sur les impositions auxquelles ce versement a donné lieu. Elle est accordée au bénéficiaire des avances, prêts ou acomptes, ou à ses ayants cause, dans les conditions fixées aux articles 49 ter à 49 sexies.</p>
<p>Lorsque plusieurs avances, prêts ou acomptes ont été consentis au même bénéficiaire, les remboursements partiels sont imputés selon les articles 1253 à 1256 du code civil.</p>
''', "Réécriture à droit constant : la phrase initiale est répartie entre la condition de restitution, son objet et ses bénéficiaires, sans changer d'alinéa. L'imputation des remboursements reste dans le second alinéa. Aucune réforme de fond ni application rétroactive du taux d'IS proposé n'est introduite.", "Date du 1er janvier 1960, article 41 du décret n° 48-1986 du 9 décembre 1948 et renvois fiscaux conservés pour les situations historiques. Le renvoi aux articles 1253 à 1256 du code civil est ancien et appelle un contrôle de coordination avec les règles issues de la réforme du droit des obligations, notamment l'article 1342-10, ainsi que de leur application dans le temps. Ce code étant hors du corpus fourni, aucune substitution n'est effectuée ni présentée comme vérifiée ici.")

add('49 ter', '''
<p>I. – Pour chacune des impositions énumérées à l'article 49 quater, le montant à restituer en application de l'article 49 bis est égal à la différence entre les deux montants suivants :</p>
<p>D'une part, l'impôt régulièrement liquidé et effectivement acquitté pour l'année ou l'exercice au titre duquel l'acompte, le prêt ou l'avance a été inclus dans la base d'imposition ;</p>
<p>D'autre part, le montant du même impôt calculé en excluant la fraction de l'acompte, du prêt ou de l'avance qui a été remboursée.</p>
<p>II. – Le calcul prévu au I porte uniquement sur le principal des droits. Il exclut les intérêts ou indemnités de retard, les majorations de droits et les amendes fiscales.</p>
''', "Réécriture à droit constant : les deux termes de la différence sont présentés parallèlement et les exclusions du calcul sont formulées en deux phrases. Les subdivisions et alinéas sont conservés. Aucune réforme de fond du calcul de restitution n'est introduite.", "Maintien du cumul des conditions d'impôt régulièrement liquidé et effectivement acquitté, de la seule fraction remboursée et du calcul sur le principal. Tous les accessoires exclus demeurent énumérés. La restitution se calcule sur les impositions concernées, sans substituer le nouveau taux normal d'IS proposé à leurs taux historiques.")

add('49 quater', '''
<p>I. – Si l'encaissement de l'avance, du prêt ou de l'acompte a entraîné l'assujettissement du bénéficiaire à l'impôt sur le revenu, la révision prévue à l'article 49 ter porte, pour les sommes remboursées, sur les impositions suivantes :</p>
<p>1° La taxe proportionnelle et la surtaxe progressive, si l'avance, le prêt ou l'acompte a été versé entre le 1er janvier 1949 et le 31 décembre 1958 ;</p>
<p>2° La taxe proportionnelle et l'impôt sur le revenu des personnes physiques, si le versement a eu lieu en 1959 ;</p>
<p>3° La retenue à la source sur les revenus de capitaux mobiliers et l'impôt sur le revenu des personnes physiques, si le versement a eu lieu entre le 1er janvier 1960 et le 31 décembre 1961 ;</p>
<p>4° La taxe complémentaire, si le versement a eu lieu entre le 1er janvier 1962 et le 31 décembre 1969 ;</p>
<p>5° L'impôt sur le revenu, si le versement a eu lieu après le 31 décembre 1961.</p>
<p>II. – Si l'encaissement de l'avance, du prêt ou de l'acompte a entraîné l'assujettissement du bénéficiaire à l'impôt sur les sociétés, la révision prévue à l'article 49 ter porte, pour les sommes remboursées, sur les impositions suivantes :</p>
<p>1° La taxe proportionnelle et l'impôt sur les sociétés, si l'avance, le prêt ou l'acompte a été versé entre le 1er janvier 1949 et le 31 décembre 1959 ;</p>
<p>2° La retenue à la source sur les revenus de capitaux mobiliers et l'impôt sur les sociétés, si le versement a eu lieu entre le 1er janvier 1960 et le 31 décembre 1961 ;</p>
<p>3° L'impôt sur les sociétés, si le versement a eu lieu après le 31 décembre 1961.</p>
<p>Toutefois, si l'avance, le prêt ou l'acompte a été consenti à une société qui remplit, en raison de sa participation au capital de la société versante, les conditions prévues à l'article 145 du code général des impôts, la restitution de la taxe proportionnelle ou de la retenue à la source consécutive au remboursement est limitée. Elle ne peut dépasser l'excédent de la taxe ou de la retenue acquittée par la société versante sur l'imposition de même nature dont la société bénéficiaire a été, le cas échéant, dispensée au titre de ses propres distributions en application de cet article.</p>
<p>III. – Si la révision des bases de l'impôt sur le revenu ou de l'impôt sur les sociétés fait apparaître un déficit pour l'année ou la période d'imposition concernée, l'intéressé peut, s'il y a lieu, reporter ce déficit sur ses revenus ou bénéfices ultérieurs. Ce report suit les règles en vigueur pour l'époque au titre de laquelle il est demandé.</p>
''', "Réécriture à droit constant : les deux séries d'impositions historiques sont présentées en phrases parallèles, le plafonnement applicable aux sociétés participantes est explicité et la règle de report est scindée. Toutes les périodes et subdivisions sont conservées ; aucune réforme de fond ni rétroactivité du taux d'IS proposé n'est introduite.", "Toutes les dates de 1949 à 1969 sont maintenues. Le chevauchement des I.4° et I.5° est conservé : il concerne des impôts distincts. L'exception du II reste son cinquième alinéa, cible du IV de l'article 49 quinquies ; ses deux phrases demeurent dans un même paragraphe. La limite porte sur l'excédent de taxe ou retenue de même nature, compte tenu de la dispense de la bénéficiaire. Le report de déficit reste soumis aux règles de l'époque pour laquelle il est sollicité.")

add('49 quinquies', '''
<p>I. – L'intéressé demande la restitution au directeur départemental ou, le cas échéant, régional des finances publiques du département où il avait son domicile ou son principal établissement au 1er janvier de l'année de sa réclamation. La restitution est ordonnée sur cette demande.</p>
<p>II. – L'associé ou ses ayants cause doivent présenter la demande de restitution au plus tard le 31 décembre de l'année suivant celle du remboursement.</p>
<p>III. – Les requérants doivent indiquer dans la demande la dénomination et le siège de la société, le montant et la date du remboursement, ainsi que les renseignements suivants :</p>
<p>a. Pour la taxe proportionnelle ou la retenue à la source : le service des impôts où l'imposition a été acquittée, la date de dépôt de la déclaration ayant servi de base à cette imposition et le montant de l'avance, du prêt ou de l'acompte inclus dans la base d'imposition de la société ;</p>
<p>b. Pour la surtaxe progressive ou l'impôt sur le revenu et pour la taxe complémentaire : l'année d'imposition, le montant de l'avance, du prêt ou de l'acompte inclus dans le revenu imposable de cette année, l'article du rôle sous lequel l'imposition a été établie et la date de mise en recouvrement du rôle ;</p>
<p>c. Pour l'impôt sur les sociétés : la période d'imposition, le montant de l'avance, du prêt ou de l'acompte inclus dans le bénéfice net imposable de cette période et, le cas échéant, l'article du rôle sous lequel l'imposition a été établie et la date de mise en recouvrement du rôle.</p>
<p>Pour justifier les renseignements mentionnés aux b ou c, les requérants doivent produire une attestation régulière du comptable établissant le paiement de l'impôt.</p>
<p>IV. – Dans le cas prévu au cinquième alinéa du II de l'article 49 quater, la demande doit également contenir tous les renseignements permettant de déterminer le montant de la taxe proportionnelle ou de la retenue à la source dont la société bénéficiaire de l'avance, du prêt ou de l'acompte a été, le cas échéant, dispensée au titre de ses propres distributions en application de l'article 145 du code général des impôts.</p>
''', "Réécriture à droit constant : le demandeur et l'autorité compétente sont explicités, les renseignements communs sont distingués des trois catégories fiscales et les formulations nominales sont allégées. Tous les justificatifs, délais et subdivisions sont conservés. Aucune réforme de fond ni suppression de preuve n'est introduite.", "Contrôles : rattachement territorial au 1er janvier de l'année de réclamation ; échéance au 31 décembre de l'année suivant le remboursement ; attestation du comptable pour b ou c ; mention conditionnelle du rôle en c. Le renvoi du IV au cinquième alinéa du II de l'article 49 quater reste exact grâce au maintien de cet alinéa dans la proposition. Les taxes historiques et l'article 145 ne sont pas supprimés au motif de leur ancienneté.")

add('49 sexies', '''
<p>Les dispositions du titre III du livre des procédures fiscales relatives aux formes et délais de réclamation, à la procédure devant le tribunal administratif et aux dégrèvements d'office s'appliquent aux demandes de restitution prévues à l'article 49 quinquies, dans la mesure où elles ne sont pas contraires aux dispositions de cet article.</p>
''', "Réécriture à droit constant : les règles applicables sont présentées avant la réserve de compatibilité et le renvoi aux demandes est explicité. Aucune réforme de fond de la procédure de restitution n'est introduite.", "Maintien des trois matières procédurales et de la primauté des règles spéciales de l'article 49 quinquies, notamment son délai de demande. Le renvoi au titre III du livre des procédures fiscales est conservé sans inventer de numéros d'articles de ce livre, hors des textes assignés.")

add('49 septies F', '''
<p>Pour l'application de l'article 244 quater B du code général des impôts, les activités suivantes constituent des opérations de recherche scientifique ou technique :</p>
<p>a. Les activités de recherche fondamentale qui contribuent à analyser les propriétés, les structures et les phénomènes physiques et naturels afin d'organiser les faits issus de cette analyse au moyen de schémas explicatifs ou de théories interprétatives ;</p>
<p>b. Les activités de recherche appliquée qui visent à identifier les applications possibles des résultats d'une recherche fondamentale ou à trouver des solutions nouvelles permettant à l'entreprise d'atteindre un objectif déterminé et choisi à l'avance.</p>
<p>Une recherche appliquée a pour résultat un modèle probatoire de produit, d'opération ou de méthode ;</p>
<p>c. Les opérations de développement expérimental menées au moyen de prototypes ou d'installations pilotes afin de réunir toutes les informations nécessaires pour fournir les éléments techniques sur lesquels fonder les décisions de production de nouveaux matériaux, dispositifs, produits, procédés, systèmes ou services, ou d'amélioration substantielle de ceux-ci. Une amélioration est substantielle si les modifications ne résultent pas d'une simple utilisation de l'état des techniques existantes et présentent un caractère de nouveauté.</p>
''', "Réécriture à droit constant : les trois catégories sont définies par des verbes directs, la finalité du développement expérimental est clarifiée et les deux conditions de l'amélioration substantielle sont conservées. Les lettres et l'alinéa propre au modèle probatoire sont maintenus. Aucune réforme de fond du crédit d'impôt recherche n'est introduite.", "Conserver les deux finalités alternatives de la recherche appliquée, le modèle probatoire, les prototypes ou installations pilotes, les six catégories de matériaux, dispositifs, produits, procédés, systèmes et services visées par la production et l'amélioration, ainsi que le cumul nouveauté/absence de simple utilisation des techniques existantes. Aucun taux de crédit d'impôt ni champ de dépense nouveau n'est créé ; le renvoi reste l'article 244 quater B.")

add('49 septies G', '''
<p>Les catégories suivantes composent le personnel de recherche :</p>
<p>1. Les chercheurs, c'est-à-dire les scientifiques ou les ingénieurs qui travaillent à concevoir ou à créer des connaissances, des produits, des procédés, des méthodes ou des systèmes nouveaux. Les salariés qui, sans posséder de diplôme, ont acquis la qualification d'ingénieur au sein de leur entreprise sont assimilés aux ingénieurs.</p>
<p>2. Les techniciens, c'est-à-dire les personnels qui travaillent en étroite collaboration avec les chercheurs pour apporter le soutien technique indispensable aux travaux de recherche et de développement expérimental.</p>
<p>Les techniciens assurent notamment les tâches suivantes :</p>
<p>Ils préparent les substances, les matériaux et les appareils nécessaires aux expériences ;</p>
<p>Ils assistent les chercheurs pendant les expériences ou réalisent celles-ci sous leur contrôle ;</p>
<p>Ils assurent l'entretien et le fonctionnement des appareils et des équipements nécessaires à la recherche et au développement expérimental.</p>
<p>Si une entreprise ne dispose pas d'un département de recherche, seules les rémunérations versées aux chercheurs et aux techniciens à l'occasion d'opérations de recherche sont prises en compte pour calculer le crédit d'impôt.</p>
''', "Réécriture à droit constant : les définitions des chercheurs et techniciens et les tâches de ces derniers sont formulées directement. L'assimilation des salariés sans diplôme et la restriction propre aux entreprises sans département de recherche sont maintenues. Aucune réforme de fond des rémunérations éligibles n'est introduite.", "Numérotation 1. et 2. et succession des alinéas conservées. La liste des tâches reste indicative (« notamment »), la qualification peut être acquise sans diplôme au sein de l'entreprise et les expériences effectuées par les techniciens restent sous le contrôle des chercheurs. La limitation aux rémunérations liées aux opérations de recherche demeure propre au cas énoncé au dernier alinéa.")

add('49 septies H', '''
<p>I. – Le ministère chargé de la recherche délivre, par décision, l'agrément des organismes de recherche ou des experts scientifiques ou techniques mentionné au d bis du II de l'article 244 quater B du code général des impôts. L'organisme ou l'expert présente sa demande, établie selon le modèle fixé par l'administration, aux services centraux de la direction générale de la recherche et de l'innovation de ce ministère.</p>
<p>L'organisme ou l'expert joint à sa demande les pièces justificatives attestant qu'il a mené, sous sa responsabilité, des opérations de recherche scientifique et technique dans l'année précédant la demande, qu'il en a défini la démarche scientifique et qu'il a réalisé les travaux avec ses propres moyens. Un arrêté conjoint des ministres chargés du budget et de la recherche fixe la liste de ces pièces.</p>
<p>Les demandes de renouvellement de l'agrément sont présentées selon les mêmes modalités.</p>
<p>II. – L'agrément est accordé pour trois ans. Cette durée est d'un an si l'organisme ou l'expert n'a achevé aucune opération de recherche dans les douze mois précédant la demande.</p>
<p>À compter de la troisième demande de renouvellement, l'agrément peut être accordé pour cinq ans aux organismes ou experts agréés de manière continue depuis au moins neuf ans au 31 décembre de l'année d'expiration, s'ils ont achevé une opération de recherche dans les douze mois précédant la demande.</p>
<p>III. – La première demande d'agrément doit être déposée avant le 31 mars si elle porte sur l'année en cours. Une demande de renouvellement doit être déposée avant la fin de l'année d'expiration.</p>
''', "Réécriture à droit constant : l'autorité, le demandeur et le destinataire sont désignés explicitement ; les justificatifs et les conditions des durées d'agrément sont formulés en phrases plus courtes. Les subdivisions I à III et les alinéas matérialisés par les sauts de ligne de la source sont conservés. Aucune réforme de fond de l'agrément n'est introduite.", "Renvoi au d bis du II de l'article 244 quater B vérifié dans le corpus local ; autorité ministérielle et direction destinataire conservées. Durées de trois ans, un an et possibilité de cinq ans à partir de la troisième demande de renouvellement maintenues. Neuf ans continus sont appréciés au 31 décembre de l'année d'expiration ; achèvement d'une opération dans les douze mois précédents exigé pour les cinq ans. Distinction conservée entre opérations menées pour les pièces du I et opérations achevées pour les durées du II. Délais « avant le 31 mars » et « avant la fin de l'année d'expiration » inchangés.")

add('49 septies I', '''
<p>Les dépenses de recherche mentionnées aux a, b et au 2° du h du II de l'article 244 quater B du code général des impôts sont déterminées en retenant les éléments suivants :</p>
<p>a. Les dotations aux amortissements déductibles fiscalement ;</p>
<p>b. Pour les dépenses de personnel, les rémunérations et leurs accessoires, ainsi que les charges sociales correspondant à des cotisations sociales obligatoires.</p>
''', "Réécriture à droit constant : la règle de détermination des dépenses est formulée directement et les deux éléments sont présentés en alinéas identifiés par les lettres d'origine. La limitation des charges sociales aux cotisations obligatoires est conservée. Aucune réforme de fond des dépenses éligibles n'est introduite.", "Renvois aux a, b et 2° du h du II de l'article 244 quater B conservés et vérifiés dans le corpus local. Les amortissements restent fiscalement déductibles ; la condition de caractère obligatoire porte sur les cotisations correspondant aux charges sociales. Les réformes de CSG, d'allègements employeur ou de capitalisation ne sont pas assimilées ici, sans texte de coordination spécifique, à une modification de cette définition.")

assert len(drafts) == len(sources) == 24
answer = []
for source in sources:
    row = {key: source[key] for key in ('code_id', 'source_id', 'source_sha256', 'number')}
    row.update(drafts[source['number']])
    answer.append(row)
Path('answer.json').write_text(json.dumps(answer, ensure_ascii=False, indent=2) + '\n')
print(f'answer.json : {len(answer)} articles')
