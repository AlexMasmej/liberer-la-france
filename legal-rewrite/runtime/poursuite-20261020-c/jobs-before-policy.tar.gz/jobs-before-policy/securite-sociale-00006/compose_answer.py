import json
from html import escape
from pathlib import Path

sources = json.loads(Path('source.json').read_text())
drafts = {}


def article(number, text, reason, review_notes):
    paragraphs = [p.strip() for p in text.strip().split('\n\n')]
    assert paragraphs and all(paragraphs)
    drafts[number] = {
        'proposed_xml': '\n'.join('<p>' + escape(p, quote=False) + '</p>' for p in paragraphs),
        'reason': reason,
        'review_notes': review_notes,
        'status': 'rewrite_draft',
    }


article('L124-6', '''
Lorsque les particularités de certains régimes le nécessitent, des décrets en Conseil d'État peuvent adapter à ces régimes les dispositions des articles L. 121-1, L. 122-1, L. 123-1, L. 123-2 et L. 123-3.
''', "Réécriture à droit constant : la condition tenant aux besoins de certains régimes précède désormais la compétence d'adaptation du pouvoir réglementaire. Les cinq articles visés et le recours au décret en Conseil d'État sont conservés.", "Aucune réforme de fond dans cet article. Les renvois et la limitation des adaptations aux nécessités propres aux régimes sont maintenus.")

article('L130-1', '''
I. - Pour l'application du présent code, l'effectif salarié annuel d'un employeur est la moyenne du nombre de personnes employées au cours de chacun des mois de l'année civile précédente. Cette règle s'applique aussi lorsque l'employeur est une personne morale comprenant plusieurs établissements.

Par dérogation au premier alinéa du présent I, l'effectif retenu pour la tarification du risque « accidents du travail et maladies professionnelles » est celui de la dernière année connue.

Pour l'année au cours de laquelle l'entreprise crée son premier emploi salarié titulaire d'un contrat de travail, l'effectif retenu est celui présent le dernier jour du mois de cette première embauche.

Un décret en Conseil d'État détermine les catégories de personnes comprises dans l'effectif et les modalités de leur décompte.

II. - Le franchissement à la hausse d'un seuil d'effectif salarié est pris en compte si ce seuil a été atteint ou dépassé pendant cinq années civiles consécutives.

Le franchissement à la baisse d'un seuil d'effectif sur une année civile fait recommencer l'application de la règle du premier alinéa du présent II.

III. - Pour l'application du présent code, les salariés qu'un groupement d'employeurs met, en tout ou partie, à la disposition d'un ou de plusieurs de ses membres ne sont pas comptés dans l'effectif de ce groupement. Ils y sont toutefois comptés pour l'application des dispositions relatives à la tarification des risques d'accidents du travail et de maladies professionnelles.
''', "Réécriture à droit constant : les règles de moyenne annuelle, de première embauche, de franchissement de seuil et de mise à disposition sont formulées séparément. Les subdivisions I à III et l'ordre des alinéas sont conservés ; aucun seuil ni délai n'est réformé.", "La période de cinq années civiles consécutives et les deux règles particulières de tarification AT-MP sont conservées. La note source fixe une entrée en vigueur par décret au plus tard le 1er janvier 2025 en citant les lois des 26 décembre 2023 et 28 février 2025 : cette chronologie appelle un contrôle de consolidation et ne sert pas de date à une réforme future. Les orientations générales sur les effets de seuil ne fournissent pas de nouveau barème applicable ici.")

article('L131-1', '''
Sous réserve du II bis de l'article L. 136-5, l'organisme débiteur précompte, lors de leur versement, les cotisations et contributions sociales dues sur les avantages de retraite et d'invalidité, les indemnités journalières, les allocations de chômage et de préretraite, ainsi que sur les autres revenus mentionnés aux articles L. 131-2 et L. 136-1-2.
''', "Réécriture à droit constant : l'organisme tenu au précompte, le moment du prélèvement et la réserve légale sont explicités dans une phrase à la voix active. Toutes les catégories de revenus restent couvertes.", "La réserve du II bis de L. 136-5 et les deux renvois d'assiette sont maintenus. La note source vise les périodes courant à compter du 1er septembre 2018. La baisse projetée de CSG sur certains salaires ne s'étend pas à ces revenus de remplacement.")

article('L131-2', '''
Les avantages et allocations suivants sont soumis à une cotisation d'assurance maladie, maternité, invalidité et décès :

1° Les avantages de retraite servis aux assurés du régime général lorsqu'ils ont été financés, en tout ou partie, par une contribution de l'employeur ou ont donné lieu à un rachat de cotisations, ainsi que les avantages de retraite versés au titre des articles L. 381-1, L. 381-2 et L. 742-1. Sont exclus les bonifications ou majorations pour enfants autres que les annuités supplémentaires, les pensions servies au titre d'une activité indépendante et les prestations de retraite, sous forme de rente ou de capital, issues d'un plan d'épargne retraite mentionné à l'article L. 224-1 du code monétaire et financier ou d'un sous-compte français du produit paneuropéen d'épargne-retraite individuelle mentionné à l'article L. 225-1 du même code, lorsque ces prestations correspondent à des versements mentionnés au 1° de l'article L. 224-2 de ce code n'ayant pas fait l'objet de l'option prévue au deuxième alinéa de son article L. 224-20 ;

2° Les allocations de chômage, les avantages attachés à la cessation d'activité et les aides à la reprise d'activité versés aux travailleurs involontairement privés d'emploi, que cette privation soit totale, partielle ou temporaire ;

3° Les avantages alloués aux assurés en préretraite ou en cessation anticipée d'activité en application de dispositions réglementaires ou conventionnelles, d'une décision unilatérale de l'employeur ou de l'article 15 de l'ordonnance n° 82-108 du 30 janvier 1982 relative aux contrats de solidarité des collectivités locales.

Un décret fixe le taux de la cotisation ainsi que les conditions dans lesquelles les titulaires de ces avantages en sont exonérés en fonction de leurs ressources.

Le prélèvement ne peut ramener le montant net des avantages mentionnés aux 2° et 3° en dessous du seuil fixé par décret.
''', "Réécriture à droit constant : le champ de chaque catégorie est rendu plus lisible et les exclusions du 1° sont isolées dans une seconde phrase du même alinéa. Les modalités d'exonération et le plancher de revenu net sont conservés sans création de taux.", "Les 1° à 3°, la distinction entre annuités supplémentaires et autres majorations pour enfants, les conditions propres au PER et au sous-compte paneuropéen ainsi que l'option visée à L. 224-20 sont conservés. Le plancher net reste réservé aux 2° et 3°. La note source prévoit une entrée en vigueur par décret au plus tard le 1er septembre 2023. Aucun nouveau compte de capitalisation n'est assimilé ici aux produits existants.")

article('L131-3', '''
Les cotisations d'assurance maladie sur les avantages de retraite mentionnés au 1° de l'article L. 131-2, servis au titre d'une activité professionnelle déterminée, sont dues au régime d'assurance maladie correspondant à cette activité. Cette affectation s'applique même lorsque les droits aux prestations d'assurance maladie sont ouverts au titre d'un autre régime.

Pour les avantages mentionnés aux 2° et 3° de l'article L. 131-2, les cotisations d'assurance maladie sont dues au régime dont l'intéressé relevait à la date d'attribution du revenu de remplacement ou de l'allocation.
''', "Réécriture à droit constant : le régime créancier est identifié pour les pensions puis pour les autres revenus de remplacement. La règle d'affectation demeure indépendante du régime qui ouvre actuellement les droits aux prestations.", "Les renvois respectifs aux 1°, 2° et 3° de L. 131-2 ainsi que la date d'attribution déterminant le régime compétent sont maintenus. La note source vise les périodes courant à compter du 1er septembre 2018. Aucune modification des taux ni des droits à prestations.")

article('L131-6', '''
I. - Les cotisations de sécurité sociale des travailleurs indépendants non agricoles qui ne relèvent pas du dispositif prévu à l'article L. 613-7 sont calculées sur l'assiette définie à l'article L. 136-3. Les sommes qui leur sont versées et qui sont mentionnées aux articles L. 3312-4, L. 3324-5 et L. 3332-27 du code du travail sont toutefois déduites de cette assiette.

L'assiette comprend également les revenus de remplacement qui leur sont versés dans les cas suivants, dès lors que ces revenus sont sans lien avec une affection de longue durée au sens des 3° et 4° de l'article L. 160-14 du présent code :

1° Les revenus versés à l'occasion de la maladie, de la maternité, de la paternité et de l'accueil de l'enfant au titre des contrats mentionnés aux deux derniers alinéas du I de l'article 154 bis du code général des impôts ;

2° Les revenus versés par les organismes de sécurité sociale.

II. - Pour permettre l'établissement des comptes des travailleurs indépendants dont le bénéfice est déterminé en application des articles 38 et 93 A du code général des impôts, les organismes mentionnés aux articles L. 213-1 et L. 752-4 du présent code leur communiquent, à l'issue de la déclaration des éléments énumérés à l'article L. 136-3 et au I du présent article, le montant des cotisations et contributions sociales dues selon les règles fixées à l'article L. 136-3 et au I du présent article. Avec le concours des organismes mentionnés aux articles L. 641-2, L. 641-5 et L. 651-1, ils mettent en place un téléservice permettant d'effectuer ce calcul à tout moment.
''', "Réécriture à droit constant : l'assiette, les déductions et les revenus de remplacement inclus sont distingués ; les obligations de communication et de mise à disposition du téléservice sont formulées avec un débiteur explicite. Le régime des indépendants n'est pas assimilé au régime salarial réformé.", "La note source rend ces règles applicables aux périodes courant à compter du 1er janvier 2025, malgré une date de version au 28 décembre 2023. Les exclusions L. 613-7 et affections de longue durée ainsi que tous les renvois fiscaux et sociaux sont maintenus. Ni la CSG salariale à 6,6 % ni le transfert de cotisations des salariés privés ne sont étendus aux indépendants.")

article('L131-6-1', '''
Par dérogation à l'article L. 131-6-2 et au premier alinéa de l'article L. 6331-51 du code du travail, un travailleur indépendant non agricole qui ne relève pas de l'article L. 613-7 du présent code peut demander qu'aucune cotisation ni contribution, provisionnelle ou définitive, ne lui soit exigée pendant les douze premiers mois suivant le début de son activité non salariée.

À sa demande, les cotisations définitives dues pour cette période peuvent être payées par fractions annuelles sur une durée maximale de cinq ans. Chaque fraction annuelle doit représenter au moins 20 % du montant total des cotisations dues. Cet étalement n'entraîne aucune majoration de retard.

Le travailleur ne peut bénéficier de ces dispositions, au titre d'une création ou d'une reprise d'entreprise, qu'une seule fois par période de cinq ans.

Une modification des conditions dans lesquelles une entreprise exerce son activité ne permet pas de bénéficier du présent article.
''', "Réécriture à droit constant : le bénéficiaire, la demande de report, les bornes de l'étalement et les situations exclues sont explicités. La discordance grammaticale du premier alinéa source est résolue sans modification du champ.", "Sont maintenus : douze mois sans exigibilité sur demande, cinq ans au maximum pour les seules cotisations définitives, fraction annuelle minimale de 20 %, absence de majoration et unicité par période de cinq ans. La note source vise les périodes courant à compter du 1er janvier 2015. Le report ne constitue pas une exonération et n'est pas étendu au dispositif L. 613-7.")

article('L131-6-1-1', '''
Par dérogation à l'article L. 131-6-2 du présent code et au premier alinéa de l'article L. 6331-51 du code du travail, bénéficient d'un report des cotisations ou contributions, provisionnelles ou définitives, les travailleurs indépendants non agricoles qui ne relèvent pas de l'article L. 613-7 du présent code et les travailleurs indépendants affiliés au régime mentionné au 3° de l'article L. 722-8 du code rural et de la pêche maritime. Ce report couvre toute la période pendant laquelle ils perçoivent une indemnité journalière mentionnée soit aux 2° des I et III de l'article L. 623-1 du présent code, soit aux articles L. 732-10 et L. 732-10-1 du code rural et de la pêche maritime.

Les cotisations ou contributions reportées en application du premier alinéa peuvent faire l'objet d'un plan de paiement échelonné d'une durée maximale de douze mois. En cas de circonstances exceptionnelles, le directeur de l'Union de recouvrement des cotisations de sécurité sociale et d'allocations familiales, de la Caisse générale de sécurité sociale ou de la caisse de mutualité sociale agricole peut porter cette durée à vingt-quatre mois.

Le report n'entraîne aucune majoration ni pénalité de retard.
''', "Réécriture à droit constant : les bénéficiaires et la période couverte sont présentés en deux phrases du même alinéa ; la durée ordinaire du plan et sa prolongation exceptionnelle sont distinguées. Les trois autorités compétentes sont conservées.", "Le régime agricole expressément visé reste inclus dans ce seul dispositif existant. Les durées de douze et vingt-quatre mois ainsi que l'absence de majoration et de pénalité sont maintenues. La note source fixe au 1er janvier 2020 l'application aux indépendants mentionnés à L. 640-1, sans fournir de date générale nouvelle pour les autres bénéficiaires.")

article('L131-6-2', '''
Les travailleurs indépendants non agricoles qui ne relèvent pas de l'article L. 613-7 doivent leurs cotisations chaque année. Un décret fixe le taux de chacune de ces cotisations.

Les cotisations provisionnelles sont calculées sur l'assiette prévue à l'article L. 131-6 pour l'avant-dernière année. Pour les deux premières années d'activité, elles sont calculées sur une assiette forfaitaire fixée par décret après consultation des conseils d'administration des organismes de sécurité sociale concernés. Lorsque les éléments énumérés au I de l'article L. 131-6 et à l'article L. 136-3 sont définitivement connus pour la dernière année écoulée, les cotisations provisionnelles sont recalculées sur l'assiette résultant de ces éléments en application du I de l'article L. 131-6 et de l'article L. 136-3. Ce recalcul ne s'applique pas aux cotisations dues pour la première année d'activité.

Lorsque les éléments énumérés au I de l'article L. 131-6 et à l'article L. 136-3 sont définitivement connus pour l'année au titre de laquelle les cotisations sont dues, celles-ci sont régularisées sur l'assiette résultant de ces éléments en application du I de l'article L. 131-6 et de l'article L. 136-3.

Par dérogation au deuxième alinéa, le cotisant peut demander que ses cotisations provisionnelles soient calculées sur l'assiette qu'il estime pour l'année en cours.

Si les données nécessaires au calcul n'ont pas été transmises, les cotisations sont calculées dans les conditions prévues à l'article L. 242-12-1.
''', "Réécriture à droit constant : les étapes du calcul provisionnel, du recalcul et de la régularisation sont distinguées. L'exception de première année et l'option pour une assiette estimée restent dans leurs alinéas respectifs ; la faute matérielle « pour de l'année » est supprimée.", "Les cinq alinéas sont conservés afin de maintenir le renvoi au deuxième alinéa. L'avant-dernière année reste la base initiale, la dernière année connue sert au recalcul et l'année de cotisation à la régularisation. La note source prévoit une application aux périodes courant à compter du 1er janvier 2025. Les taux demeurent réglementaires ; aucune baisse salariale n'est transposée ici.")

article('L131-6-4', '''
I. - Les personnes qui créent ou reprennent une activité professionnelle, ou qui entreprennent l'exercice d'une autre profession non salariée, bénéficient d'une exonération des cotisations d'assurance maladie, maternité, veuvage, vieillesse, invalidité et décès et d'allocations familiales dues au titre de leur activité. Elles doivent exercer soit à titre indépendant en relevant de l'article L. 611-1 du présent code ou de l'article L. 722-4 du code rural et de la pêche maritime, soit sous la forme d'une société dont elles exercent effectivement le contrôle. Cette condition de contrôle s'applique notamment lorsque la création ou la reprise prend la forme d'une société mentionnée aux 11°, 12° ou 23° de l'article L. 311-3 du présent code ou aux 8° ou 9° de l'article L. 722-20 du code rural et de la pêche maritime.

Le premier alinéa du présent article s'applique aux personnes appartenant à l'une des catégories mentionnées à l'article L. 5141-1 du code du travail, à l'exclusion de celles mentionnées à l'article L. 642-4-2 du présent code, ainsi qu'aux personnes qui créent ou reprennent une entreprise implantée dans une commune relevant de l'une des zones mentionnées à l'article 44 quindecies A du code général des impôts.

II. - L'exonération mentionnée au I est accordée pour douze mois.

Lorsque l'assiette des cotisations mentionnées au I ne dépasse pas les trois quarts du plafond mentionné à l'article L. 241-3 du présent code, un décret fixe le montant de l'exonération, dans la limite de 25 % de ces cotisations. Au-delà de ce seuil d'assiette, ce montant décroît linéairement jusqu'à devenir nul lorsque l'assiette atteint le plafond annuel de la sécurité sociale.

L'exonération prévue à l'alinéa précédent porte sur :

1° Les cotisations à la charge de l'employeur et du salarié afférentes à la fraction des rémunérations versées au cours de la période d'exonération, lorsque les bénéficiaires relèvent d'un régime de salariés ;

2° Les cotisations dues au titre de l'activité exercée pendant la période d'exonération, lorsque les bénéficiaires relèvent d'un régime de non-salariés.

Les personnes mentionnées au I demandent l'exonération à l'organisme mentionné à l'article L. 213-1 lors de la création de leur activité.

Les conjoints collaborateurs des travailleurs indépendants qui ne relèvent pas du dispositif mentionné à l'article L. 613-7 et qui bénéficient de l'exonération prévue au présent article peuvent également en bénéficier. Sont toutefois exclus les conjoints collaborateurs des assurés relevant du titre V du livre VI qui ont choisi le calcul de leurs cotisations selon les modalités du 3° de l'article L. 662-1. Pour calculer l'exonération du conjoint collaborateur, l'assiette retenue est la fraction de l'assiette du chef d'entreprise, prévue à l'article L. 131-6, qui lui est attribuée. Cette fraction est déduite de l'assiette servant au calcul de l'exonération des cotisations du chef d'entreprise.

III. - L'exonération mentionnée au I ne peut être cumulée avec un autre dispositif de réduction ou d'abattement applicable à ces cotisations, ni avec celui prévu au 37° de l'article L. 311-3. Restent toutefois cumulables les dispositifs prévus aux articles L. 613-1 et L. 621-3 du présent code et à l'article L. 731-13 du code rural et de la pêche maritime.

IV. - Une personne qui a cessé de bénéficier de l'exonération mentionnée au I au titre d'une activité antérieure ne peut en bénéficier à nouveau pendant les trois années suivant cette cessation.
''', "Réécriture à droit constant : les conditions d'activité et de contrôle, les bornes de l'exonération, les règles du conjoint collaborateur et les cumuls sont explicités sans déplacer les subdivisions I à IV. Le plafond de 25 % et la dégressivité linéaire sont conservés.", "La version source s'applique aux périodes d'activité courant à compter du 1er janvier 2026 selon sa note ; L. 131-6-5 conserve expressément l'ancienne rédaction pour les chefs d'exploitation ou d'entreprise agricole qu'il vise. Durée de douze mois, seuil de trois quarts du PASS, plafond de 25 %, extinction à un PASS et délai de trois ans inchangés. L'orientation de continuité des allègements ne justifie ni la suppression de cette exonération ni l'extension automatique du nouvel allègement employeur à ce dispositif ; ses règles de cumul devront être coordonnées si ce nouvel allègement entre dans le champ des mêmes cotisations.")

article('L131-6-5', '''
Par dérogation à l'article L. 131-6-4, les chefs d'exploitation ou d'entreprise agricole qui relèvent du régime de protection sociale agricole mentionné à l'article L. 722-1 du code rural et de la pêche maritime conservent le bénéfice de l'article L. 131-6-4 du présent code dans sa rédaction antérieure à la loi n° 2025-1403 du 30 décembre 2025 de financement de la sécurité sociale pour 2026.
''', "Réécriture à droit constant : la règle de maintien de la rédaction antérieure est formulée directement autour de ses bénéficiaires. La dérogation agricole et la loi qui détermine la version conservée sont intégralement maintenues.", "La note source indique une entrée en vigueur immédiate résultant de la formule exécutoire de la loi du 30 décembre 2025. Le maintien de l'ancien L. 131-6-4 est une règle historique toujours applicable à ce champ, non une date de réforme future. La nouvelle rédaction de L. 131-6-4 ne lui est pas substituée.")

article('L131-7', '''
I. - Toute réduction ou exonération de cotisations de sécurité sociale instituée à compter de la date d'entrée en vigueur de la loi n° 94-637 du 25 juillet 1994 relative à la sécurité sociale est intégralement compensée aux régimes concernés par le budget de l'État pendant toute sa durée d'application.

Cette compensation ne remet pas en cause celles qui étaient appliquées à la date d'entrée en vigueur de cette loi.

La règle du premier alinéa s'applique également aux mesures suivantes :

1° Toute réduction ou exonération d'une contribution affectée à ces régimes, aux organismes qui concourent à leur financement ou à l'amortissement de leur endettement, instituée à compter de la publication de la loi n° 2004-810 du 13 août 2004 relative à l'assurance maladie ;

2° Toute réduction ou tout abattement de l'assiette de ces cotisations et contributions institué à compter de la publication de la loi n° 2004-810 du 13 août 2004 précitée.

À compter de la publication de la loi n° 2004-810 du 13 août 2004 précitée, tout transfert de charges entre l'État et les régimes et organismes mentionnés au 1° fait l'objet d'une compensation intégrale entre le budget de l'État et ces régimes ou organismes.

II. - Le I ne s'applique pas :

1° Aux réductions et exonérations prévues au 5° bis du III de l'article L. 136-1-1, au III bis de l'article L. 136-8, aux huitième, avant-dernier et dernier alinéas de l'article L. 137-15, à l'article L. 241-13, au premier alinéa du II de l'article L. 242-1, à l'article L. 613-1 et à l'article L. 621-3, dans sa rédaction résultant de la loi n° 2025-199 du 28 février 2025 de financement de la sécurité sociale pour 2025 ;

2° À la réduction de la contribution mentionnée à l'article L. 137-30 résultant de l'abattement d'assiette prévu à l'article L. 137-2.

III. - L'entrée en vigueur de chaque tranche de baisse de la contribution sociale sur les salaires du secteur privé prévue à l'article L. 136-8, d'allègement supplémentaire de cotisations patronales calculé au taux de 3 % sur la rémunération brute retenue dans la limite d'un plafond annuel de la sécurité sociale, ou de suppression de la contribution sociale de solidarité mentionnée à l'article L. 137-30, est subordonnée au vote d'un financement pérenne et d'une compensation explicite des régimes et organismes affectés. Ces dispositions sont adoptées en loi de finances ou en loi de financement de la sécurité sociale, selon leurs domaines respectifs. À défaut de ce financement, la tranche n'entre pas en vigueur.

Par dérogation au II, l'allègement supplémentaire de cotisations patronales mentionné au premier alinéa du présent III donne lieu à la compensation intégrale prévue au I. Son imputation est limitée aux cotisations imputables restant dues après application des autres allègements.

La loi de financement de la sécurité sociale qui finance la suppression de la contribution sociale de solidarité fixe au 1er janvier d'une année l'extinction des faits générateurs de cette contribution. Elle assure une compensation durable à l'assurance vieillesse. Les contributions dues au titre de faits générateurs antérieurs restent soumises à leurs règles de calcul, de recouvrement, de contrôle, de majoration, de remboursement et de recours.

Chaque palier de transfert de cotisations vieillesse existantes vers la capitalisation collective individualisée prévu à l'article L. 241-3 est également subordonné au vote d'un financement pérenne couvrant les recettes retirées à la répartition, les abondements de solidarité et les frais de transition. Un rendement attendu des placements ne peut être retenu comme une recette disponible pour payer les pensions actuelles. À défaut de financement, le palier est différé.

Les économies retenues pour financer les mesures du présent III doivent être nettes et récurrentes. Une même fraction d'économie ne peut être comptabilisée plus d'une fois pour financer des baisses de prélèvements ou la transition des retraites. Les recettes attendues d'une croissance future ne sont pas retenues pour équilibrer leur financement initial.
''', "Les I et II sont réécrits à droit constant, avec conservation des exceptions et de l'ordre des alinéas. Réforme de fond au nouveau III : financement préalable des baisses de CSG salariale privée, de l'allègement employeur et de l'extinction de la C3S ; compensation de l'allègement supplémentaire malgré l'exception existante ; financement de chaque palier de capitalisation sans double emploi des économies ni rendement anticipé. Aucune année d'extinction ni économie budgétaire n'est inventée.", "Le renvoi source du II, 2° à L. 137-2 paraît incohérent : aucun article portant ce numéro n'a été trouvé dans le corpus public fourni, tandis que l'abattement C3S figure à L. 137-32. Le renvoi est conservé et doit faire l'objet d'une correction coordonnée explicite. Le III est ajouté après tous les alinéas existants. L'allègement supplémentaire doit recevoir ses règles opérationnelles dans L. 241-13, avec coordination du cumul dans L. 131-6-4, des cotisations imputables et des dispositions réglementaires : ce III règle son financement et ne suffit pas à ouvrir le droit. La baisse salariale relève de L. 136-8 et sa déductibilité du CGI, article 154 quinquies ; elle est distincte du III bis de L. 136-8 relatif aux pensions. L'extinction C3S exige les coordinations L. 137-30 à L. 137-38 et D. 137-30 à D. 137-36 déjà retenues ; le financement vieillesse doit rester distinct des autres baisses. Le transfert renvoie au L. 241-3 proposé dans coordination.json et à son seul champ initial de salariés du régime général employés par une personne de droit privé ; ses autres préalables ne sont pas réputés remplis. La note source vise les périodes d'emploi à compter du 1er janvier 2026, sans fixer de date à ces nouvelles mesures. Une disposition nouvelle non codifiée de loi de financement de la sécurité sociale doit fixer l'année d'extinction C3S et les ressources de sa compensation ; les autres lois financières compétentes doivent encore arrêter les financements, sans montants présumés. Le statut, la tenue et la conservation des actifs du nouveau compte de capitalisation collective appellent des dispositions législatives nouvelles de raccordement au code monétaire et financier, hors des cinq codes réécrits ; aucun numéro d'article nouveau ni assimilation automatique à un PER existant n'est inventé ici.")

article('L131-8', '''
Les organismes de sécurité sociale et les fonds mentionnés au présent article reçoivent le produit des impôts et taxes suivants selon les règles d'affectation ci-après :

1° Le produit de la taxe sur les salaires mentionnée à l'article 231 du code général des impôts, après déduction des frais d'assiette et de recouvrement déterminés selon le III de l'article 1647 du même code, est versé :

- À la branche mentionnée au 3° de l'article L. 200-2 du présent code, à hauteur de 58,35 % ;

- À la branche mentionnée au 4° du même article, à hauteur de 10,74 % ;

- À la branche mentionnée au 1° du même article, à hauteur de 24,77 % ;

- À la branche mentionnée au 5° du même article, à hauteur de 6,14 % ;

2° Le produit des taxes sur l'affectation des véhicules de tourisme à des fins économiques prévues au 1° de l'article L. 421-94 du code des impositions sur les biens et services est affecté :

a) À la branche mentionnée au 1° de l'article L. 200-2 du présent code, à hauteur de 24,10 % ;

b) À la branche mentionnée au 3° du même article L. 200-2, à hauteur de 75,90 % ;

3° Le produit des contributions mentionnées aux 1° et 3° du I et aux II, III et III bis de l'article L. 136-8 du présent code est versé :

a) À la Caisse nationale des allocations familiales, pour la part correspondant aux taux suivants :

- 0,95 % pour les contributions mentionnées au 1° des I et II et au III bis du même article L. 136-8 ;

- 0,68 % pour la contribution mentionnée au 3° du I du même article L. 136-8 ;

- 0,3 % pour les revenus mentionnés au 2° du II du même article L. 136-8 ;

b) Aux régimes obligatoires d'assurance maladie, pour la contribution sur les revenus d'activité, en proportion des contributions sur ces revenus acquittées par les personnes affiliées à chaque régime. Pour la contribution sur les autres revenus, le produit est versé à la Caisse nationale de l'assurance maladie ou, lorsqu'un régime n'est pas intégré financièrement au sens de l'article L. 134-4, à ce régime. Un décret fixe les conditions de ces affectations, qui portent sur les parts correspondant aux taux suivants :

- 4,25 % pour la contribution mentionnée au 1° du I de l'article L. 136-8 ;

- 5,30 % pour la contribution mentionnée au 3° du même I ;

- 2,72 % pour les revenus mentionnés au 1° du II du même article L. 136-8 ;

- 2,53 % pour les revenus mentionnés au 2° du même II ;

- 1,27 % pour les revenus mentionnés au III du même article L. 136-8 ;

- 0,18 % pour les revenus mentionnés au III bis du même article L. 136-8 ;

c) À la Caisse d'amortissement de la dette sociale instituée par l'ordonnance n° 96-50 du 24 janvier 1996 relative au remboursement de la dette sociale, pour la part correspondant au taux de 0,45 %. Pour la contribution mentionnée au 3° du I de l'article L. 136-8 du présent code, ce taux est toutefois fixé à 0,22 % ;

d) À l'organisme mentionné au premier alinéa de l'article L. 5427-1 du code du travail, pour la contribution mentionnée au 1° du I de l'article L. 136-8 du présent code et pour la part correspondant au taux de 1,47 % ;

e) À la branche mentionnée au 3° de l'article L. 200-2, pour la contribution sur les revenus de remplacement mentionnée au 2° du II et du III bis de l'article L. 136-8, pour la part correspondant au taux de 2,94 % ;

f) À la Caisse nationale de solidarité pour l'autonomie, pour les contributions mentionnées au 1° du I, aux 1° et 2° du II, aux III et III bis de l'article L. 136-8, pour la part correspondant au taux de 2,08 % ;

3° bis Le produit des contributions mentionnées au 2° du I de l'article L. 136-8 est versé :

a) À la branche mentionnée au 3° de l'article L. 200-2, pour la part correspondant au taux de 6,67 % ;

b) À la Caisse d'amortissement de la dette sociale, pour la part correspondant au taux de 0,45 % ;

c) À la Caisse nationale de solidarité pour l'autonomie, pour la part correspondant au taux de 3,48 % ;

3° ter Le produit de la contribution mentionnée au III de l'article L. 136-7-1 est réparti comme suit :

a) 18 % à la branche mentionnée au 4° de l'article L. 200-2 ;

b) 82 % à la branche mentionnée au 1° de l'article L. 200-2 ;

3° quater Le produit des contributions mentionnées au IV de l'article L. 136-8 est versé :

a) À la branche mentionnée au 3° de l'article L. 200-2, pour la part correspondant au taux de 6,67 % ;

b) À la Caisse d'amortissement de la dette sociale, pour la part correspondant au taux de 0,45 % ;

c) À la Caisse nationale de solidarité pour l'autonomie, pour la part correspondant au taux de 2,08 % ;

4° La fraction du produit de la taxe mentionnée au b du II de l'article 1001 du code général des impôts est affectée à la branche mentionnée au 3° de l'article L. 200-2 ;

4° bis Le prélèvement mentionné au b du II de l'article 1001 du code général des impôts est affecté à la branche mentionnée au 5° de l'article L. 200-2 du présent code ;

5° Le produit des contributions mentionnées aux articles L. 137-14 et L. 137-18 est versé :

a) À la branche mentionnée au 3° de l'article L. 200-2, à hauteur de 93,98 % ;

b) À la branche mentionnée au 1° du même article L. 200-2, à hauteur de 6,02 % ;

5° bis Le surplus du produit des prélèvements mentionné au second alinéa de l'article L. 137-24 est versé :

a) À la branche mentionnée au 4° de l'article L. 200-2, à hauteur de 66 % ;

b) À la branche mentionnée au 1° du même article L. 200-2, à hauteur de 34 % ;

6° Le produit du droit de licence sur la rémunération des débitants de tabacs mentionné à l'article 568 du code général des impôts est versé à la branche mentionnée au 1° de l'article L. 200-2 ;

7° Une fraction de 99,50 % du produit de l'accise sur les tabacs mentionnée à l'article L. 314-1 du code des impositions sur les biens et services, perçue en métropole et diminuée du produit perçu en Corse, est versée à la branche mentionnée au 1° de l'article L. 200-2 du présent code ;

8° Le produit de la taxe mentionnée au I de l'article L. 862-4, perçue au titre des contrats mentionnés au II bis du même article L. 862-4, est affecté au fonds mentionné à l'article L. 862-1.

Le produit de la taxe mentionnée au premier alinéa du présent 8°, perçue au titre des contrats mentionnés au II de l'article L. 862-4, est affecté à la Caisse nationale de l'assurance maladie pour financer :

a) Le fonds mentionné à l'article L. 862-1, à hauteur de la différence entre ses charges et ses autres produits ;

b) Le fonds mentionné à l'article L. 815-26, à hauteur de ses charges ;

c) Les charges de la branche mentionnée au 1° de l'article L. 200-2, à hauteur du solde du produit après les affectations prévues aux a et b du présent 8° ;

9° Une fraction de 29,05 % de la taxe sur la valeur ajoutée brute budgétaire, après déduction des remboursements et restitutions effectués pour l'année en cours par les comptables assignataires, est affectée aux bénéficiaires suivants. Cette fraction est minorée de 4,1 milliards d'euros en 2026 :

a) À la branche mentionnée au 1° de l'article L. 200-2, à concurrence de 20,77 points ;

b) À l'Agence centrale des organismes de sécurité sociale, au titre de ses missions prévues aux 7° et 7° bis de l'article L. 225-1-1, à concurrence de 8,28 points. Le montant correspondant à cette affectation est minoré de 4,1 milliards d'euros en 2026.

L'Agence centrale des organismes de sécurité sociale centralise le produit des taxes et impôts mentionnés au présent article et le répartit entre leurs affectataires. Elle applique les fractions prévues par le présent article dans leur valeur en vigueur à la date du fait générateur de chaque taxe ou impôt.

Par dérogation au 3°, lorsque le taux de 6,6 % prévu à l'article L. 136-8 s'applique aux rémunérations des salariés du secteur privé, le produit de la contribution prélevée sur ces seules rémunérations est réparti entre les affectataires mentionnés aux a à d et f du 3°, au prorata des parts correspondant aux taux que ces dispositions prévoient pour la contribution mentionnée au 1° du I de l'article L. 136-8. La compensation financée dans les conditions du III de l'article L. 131-7 complète, pour chaque affectataire, ce produit jusqu'au montant qui lui serait revenu, sur la même assiette, en l'absence de la baisse du taux de 9,2 % à 6,6 %. Cette règle s'applique à compter de l'entrée en vigueur financée de la baisse et ne modifie pas la répartition du produit des contributions sur les autres revenus.
''', "Réécriture à droit constant des affectations : les destinataires, fractions et assiettes sont présentés en phrases plus directes, avec maintien de toutes les subdivisions et de leurs alinéas. Réforme de fond limitée au dernier alinéa ajouté : coordination de la CSG salariale privée à 6,6 %, répartition du produit effectivement encaissé selon les proportions existantes et compensation de la perte pour chaque affectataire. Aucun taux d'affectation chiffré nouveau ni montant budgétaire n'est créé.", "Les cinq parts applicables à la contribution d'activité du 1° du I de L. 136-8 totalisent 9,2 points : 0,95 + 4,25 + 0,45 + 1,47 + 2,08. Le nouvel alinéa évite de répartir 9,2 points sur une recette de 6,6 points : les parts existantes servent de clé proportionnelle, puis une compensation financée complète chaque destinataire. Cette coordination inclut l'organisme d'assurance chômage du d, sans étendre la baisse aux pensions déjà taxées à 6,6 %, aux remplacements, aux indépendants ou aux capitaux. Le III de L. 131-7 est créé dans le présent lot ; la disposition salariale de L. 136-8 et les lois financières doivent être cohérentes avec cette entrée en vigueur. Le renvoi source du e du 3° au « 2° du II et du III bis » est ambigu : le 2° du III bis de L. 136-8 décrit un seuil de ressources, non une catégorie autonome de revenus ; il est conservé et signalé pour coordination. Toutes les autres fractions sont conservées, notamment 29,05 points de TVA = 20,77 + 8,28 ; la minoration de 4,1 milliards d'euros en 2026 n'est appliquée qu'une fois au total et imputée à la seule part du b du 9°. Les distinctions II/II bis de L. 862-4, le produit Corse retranché et la date du fait générateur restent inchangés. La note source fixe au 1er février 2026 l'application de la version issue de la loi du 19 février 2026 ; ce n'est pas la date de la baisse projetée.")

article('L131-9', '''
Des taux particuliers de cotisations d'assurance maladie, maternité, invalidité et décès à la charge des assurés s'appliquent aux personnes qui ne remplissent pas les conditions de résidence de l'article L. 136-1 et dont les frais de santé sont obligatoirement pris en charge en application de l'article L. 160-1. La disposition qui étendait ces taux aux personnes dont les frais de santé sont pris en charge en application de l'article L. 160-1, exonérées en tout ou partie d'impôts directs par une convention ou un accord international au titre des revenus d'activité définis aux articles L. 131-6 et L. 242-1 et des sommes entrant dans les assiettes définies aux articles L. 131-2, L. 131-6 et L. 242-1, et qui ne sont pas assujetties à la contribution mentionnée à l'article L. 136-1, a été déclarée contraire à la Constitution par l'article 3 de la décision n° 2012-659 DC du Conseil constitutionnel du 13 décembre 2012. Ces taux particuliers s'appliquent également aux redevances mentionnées aux IV et V de l'article L. 136-6 versées aux personnes qui ne remplissent pas la condition de résidence fiscale du I de ce même article.
''', "Réécriture à droit constant des champs des taux particuliers, en tenant compte de la note constitutionnelle fournie avec la source. La deuxième phrase est rendue explicitement historique et censurée, tout en conservant l'intégralité de la catégorie qu'elle décrivait ; elle n'est pas rétablie comme obligation. Il ne s'agit pas d'une réforme de taux.", "Incohérence préexistante : le corps source énonce toujours sa deuxième phrase comme une règle applicable, alors que sa note (1) la dit contraire à la Constitution par l'article 3 de la décision n° 2012-659 DC du 13 décembre 2012. La proposition signale cette censure à l'emplacement de la phrase concernée et ne la corrige pas silencieusement par une suppression. La consolidation et la portée de cette censure doivent être contrôlées avant adoption ; aucune réintroduction de la disposition censurée n'est proposée. Les conditions de résidence de L. 136-1 et de résidence fiscale du I de L. 136-6 restent distinctes. La seconde note source vise le calcul des cotisations et contributions des indépendants hors L. 613-7 pour les périodes courant à compter du 1er janvier 2025 ; elle ne vaut pas date générale de réforme de cet article.")

article('L132-1', '''
Les organismes d'assurance maladie prennent en charge la totalité des dépenses exposées à l'occasion des interruptions volontaires de grossesse pratiquées dans les conditions prévues au troisième alinéa de l'article L. 2212-7 du code de la santé publique.

Un décret précise, si nécessaire, les modalités d'application du présent article, notamment les conditions qui garantissent l'anonymat des personnes mentionnées à l'alinéa précédent dans les procédures de prise en charge.
''', "Réécriture à droit constant : les organismes payeurs sont placés en sujet et l'objet du décret est formulé directement. La couverture intégrale des dépenses et la garantie d'anonymat sont maintenues.", "Le renvoi au troisième alinéa de L. 2212-7 du code de la santé publique et les deux alinéas sont conservés. Aucune mesure de policy.json ne modifie cette prise en charge ; aucune restriction de dépenses ni condition supplémentaire n'est ajoutée.")

article('L133-1', '''
I. - Lorsqu'un procès-verbal de travail dissimulé est établi par les agents chargés du contrôle mentionnés au premier alinéa de l'article L. 243-7 du présent code ou à l'article L. 724-7 du code rural et de la pêche maritime, ou lorsqu'un tel procès-verbal est transmis, en application de l'article L. 8271-6-4 du code du travail, aux organismes de recouvrement mentionnés aux articles L. 213-1 et L. 752-1 du présent code et à l'article L. 723-3 du code rural et de la pêche maritime, l'agent chargé du contrôle remet un document à la personne contrôlée pour permettre à l'organisme de recouvrement de mettre en œuvre la procédure prévue au II. Ce document constate la situation et évalue le montant des cotisations et contributions éludées, des majorations prévues à l'article L. 243-7-7 du présent code et, le cas échéant, des majorations et pénalités afférentes. Il évalue aussi le montant des réductions ou exonérations de cotisations ou contributions sociales dont le débiteur a pu bénéficier et qui sont annulées en application du deuxième alinéa de l'article L. 133-4-2.

Le document indique les dispositions légales applicables à l'infraction et à la procédure du présent article. Il mentionne notamment le II ainsi que les voies et délais de recours applicables. L'agent chargé du contrôle le signe.

II. - Après la remise du document mentionné au I, la personne contrôlée produit les éléments établissant qu'elle dispose de garanties suffisantes pour couvrir les montants évalués, dans les conditions précisées par décret en Conseil d'État. À défaut, le directeur de l'organisme de recouvrement peut prendre une ou plusieurs des mesures conservatoires mentionnées aux articles L. 521-1 à L. 533-1 du code des procédures civiles d'exécution, dans la limite des montants mentionnés au I du présent article, sans demander l'autorisation du juge prévue au premier alinéa de l'article L. 511-1 du même code.

À tout moment de la procédure, la personne contrôlée peut demander au directeur de l'organisme la mainlevée des mesures conservatoires en lui apportant des garanties suffisantes de paiement.

III. - La décision du directeur de l'organisme peut être contestée selon les règles de saisine en urgence du juge de l'exécution prévues par le code des procédures civiles d'exécution. Le juge statue dans un délai maximal de quinze jours. Il peut ordonner la mainlevée de la mesure conservatoire, notamment si ses conditions de mise en œuvre ne sont pas respectées ou si les garanties produites par la personne contrôlée lui paraissent suffisantes. Le recours n'est pas suspensif.
''', "Réécriture à droit constant : les deux modes de saisine du recouvrement, le contenu du document, les garanties et les pouvoirs du directeur puis du juge sont énoncés en phrases plus courtes. Les subdivisions I à III, le plafond des mesures et le recours non suspensif sont conservés.", "La source porte l'état ABROGE_DIFF et une fin de validité au 1er janvier 2027 : la proposition réécrit la version assignée sans supprimer cette limite temporelle ni prétendre la reconduire. La note source vise les contrôles engagés à compter du 1er janvier 2020 pour la modification citée. Le renvoi au deuxième alinéa de L. 133-4-2 correspond dans le corpus fourni au II relatif à l'annulation ; il est conservé. Le délai de quinze jours, les garanties de paiement et l'absence d'effet suspensif restent inchangés.")

article('L133-3', '''
Pour leurs créances et dettes envers les cotisants, les assurés ou les tiers, les organismes de sécurité sociale peuvent différer ou abandonner la mise en recouvrement ou la mise en paiement, lorsque les sommes sont inférieures aux montants et dans les conditions fixés par décret.

Le même décret précise les modalités d'admission en non-valeur des créances de ces organismes.
''', "Réécriture à droit constant : le pouvoir de différer ou d'abandonner le recouvrement ou le paiement est rattaché directement aux organismes et à ses limites réglementaires. La distinction avec l'admission en non-valeur est maintenue dans le second alinéa.", "Aucun seuil chiffré n'est créé. Les trois catégories de personnes concernées, les créances et les dettes et les deux opérations restent couvertes. La note source fixe l'entrée en vigueur au 1er janvier 2020.")

article('L133-4', '''
I. - A. - Les règles de recouvrement ci-après s'appliquent en cas de non-respect des règles de tarification, de distribution ou de facturation concernant :

1° Les actes, prestations et produits inscrits sur les listes mentionnées aux articles L. 162-1-7, L. 162-17, L. 165-1, L. 162-22-7, L. 162-22-7-3 et L. 162-23-6, ou relevant des articles L. 162-16-5-1, L. 162-16-5-2, L. 162-17-2-1, L. 162-18-1, L. 162-22-3, L. 162-22-19, L. 162-23-1, L. 162-62 et L. 165-1-5, ainsi que les activités de télésurveillance médicale inscrites sur la liste mentionnée à l'article L. 162-52 ;

2° Les frais de transports mentionnés aux articles L. 160-8 et L. 160-9-1.

L'organisme de prise en charge recouvre l'indu auprès du professionnel, du distributeur ou de l'établissement à l'origine du non-respect de ces règles, que le paiement ait été fait à l'assuré, à un autre professionnel de santé, à un distributeur ou à un établissement. Lorsque le non-respect constaté constitue une fraude du professionnel, du distributeur ou de l'établissement, l'organisme d'assurance maladie recouvre également auprès de celui-ci, en contrepartie de ses frais de gestion, une indemnité égale à 10 % des sommes réclamées au titre des remboursements effectués à tort. Cette indemnité est recouvrée selon les mêmes conditions que les indus du présent article.

B. - Les mêmes règles s'appliquent lorsqu'un acte non effectué ou des prestations et produits non délivrés sont facturés en vue de leur remboursement par les organismes d'assurance maladie. Elles s'appliquent aussi lorsque les actes sont effectués, ou les prestations et produits délivrés, alors que le professionnel est interdit d'exercer son activité libérale dans les conditions prévues au III de l'article L. 641-9 du code de commerce.

II. - Lorsque le non-respect de ces règles est révélé par l'analyse d'une partie de l'activité du professionnel, du distributeur ou de l'établissement, l'indu mentionné au A du I peut être fixé forfaitairement par extrapolation à tout ou partie de l'activité prise en charge par l'assurance maladie. Cette fixation intervient à l'issue d'une procédure contradictoire entre l'organisme d'assurance maladie chargé du recouvrement et le professionnel, le distributeur ou l'établissement concerné.

Si le professionnel, le distributeur ou l'établissement accepte par écrit la somme fixée en application du premier alinéa du présent II, ce montant est opposable aux deux parties.

III. - Lorsque le professionnel ou l'établissement auquel l'indu est notifié est également débiteur envers l'assuré ou son organisme complémentaire, l'organisme de prise en charge peut récupérer la totalité de l'indu. Il restitue à l'assuré et, le cas échéant, à son organisme complémentaire les sommes qu'ils ont versées à tort.

Lorsque le recouvrement porte sur une activité d'hospitalisation à domicile facturée par un établissement de santé mentionné à l'article L. 6125-2 du code de la santé publique, l'organisme de prise en charge minore l'indu notifié d'une somme égale à un pourcentage des prestations facturées par l'établissement. Un arrêté des ministres chargés de la santé et de la sécurité sociale fixe ce pourcentage.

L'action en recouvrement se prescrit par trois ans à compter du paiement de la somme indue, sauf en cas de fraude. Elle débute par l'envoi au professionnel ou à l'établissement d'une notification l'invitant à payer le montant réclamé ou, le cas échéant, à présenter ses observations dans un délai de deux mois. La notification est envoyée par tout moyen permettant de prouver sa date de réception.

À l'expiration de ces deux mois, l'organisme de prise en charge peut récupérer le montant par retenue sur les versements de toute nature à venir si le professionnel ou l'établissement n'a ni payé ni présenté d'observations, et sous réserve qu'il ne conteste pas le caractère indu des sommes.

En cas de rejet total ou partiel des observations, le directeur de l'organisme d'assurance maladie adresse à l'intéressé, par lettre recommandée, une mise en demeure de payer dans un délai d'un mois. Cette mise en demeure ne peut porter que sur des sommes figurant dans la notification.

Si la mise en demeure reste sans effet, le directeur de l'organisme peut délivrer une contrainte. En l'absence d'opposition du débiteur devant le tribunal judiciaire spécialement désigné en application de l'article L. 211-16 du code de l'organisation judiciaire, cette contrainte produit tous les effets d'un jugement et ouvre notamment le bénéfice de l'hypothèque judiciaire. Les sommes réclamées qui ne sont pas réglées aux dates d'exigibilité indiquées dans la mise en demeure sont majorées de 10 %. Cette majoration peut faire l'objet d'une remise.

IV. - Un décret en Conseil d'État précise les modalités d'application du présent article.
''', "Réécriture à droit constant : les faits déclencheurs, les personnes redevables, l'extrapolation contradictoire puis les étapes du recouvrement sont exprimés en phrases plus courtes. Toutes les subdivisions I A et B, II à IV et tous les alinéas sont maintenus ; l'indemnité de gestion pour fraude reste distincte de la majoration pour défaut de paiement.", "Les seize renvois du 1° du A et les deux renvois de transport sont conservés, ainsi que l'interdiction d'exercice du III de L. 641-9 du code de commerce et le régime spécifique d'hospitalisation à domicile. Prescription de trois ans sauf fraude, observations sous deux mois, mise en demeure sous un mois, deux prélèvements distincts de 10 %, caractère écrit de l'accord et possibilité de remise maintenus. La source vise les distributeurs aux I et II, mais seulement les professionnels et établissements dans plusieurs règles du III ; cette différence de champ préexistante est conservée, sans extension silencieuse. La fixation forfaitaire reste limitée à l'indu du A du I. Aucun pourcentage de minoration de l'hospitalisation à domicile n'est inventé.")

article('L133-4-1', '''
Lorsqu'une prestation a été versée à tort, l'organisme qui gère un régime obligatoire ou volontaire d'assurance maladie ou d'accidents du travail et de maladies professionnelles récupère l'indu auprès de l'assuré, sauf dans les cas mentionnés à l'article L. 133-4 et dans les autres cas où la récupération peut être effectuée auprès d'un professionnel de santé. Sous réserve des quatrième à neuvième alinéas, cet indu peut être récupéré par un ou plusieurs versements ou par retenue sur les prestations à venir, en fonction de la situation sociale du ménage, y compris lorsqu'il résulte de la dispense d'avance des frais. Si le versement indu résulte d'une fraude de l'assuré, l'organisme d'assurance maladie recouvre aussi auprès de celui-ci, en contrepartie de ses frais de gestion, une indemnité égale à 10 % des sommes réclamées au titre des remboursements effectués à tort. Cette indemnité est recouvrée selon les mêmes conditions que les indus du présent article.

Lorsqu'il y a lieu et s'il peut l'identifier, l'organisme mentionné au premier alinéa informe l'organisme d'assurance maladie complémentaire de l'assuré de l'engagement de cette procédure.

Si l'indu notifié ne peut être recouvré sur les prestations mentionnées au premier alinéa, il peut, sous réserve des quatrième à neuvième alinéas, être récupéré par retenue sur les prestations mentionnées à l'article L. 168-8, aux titres IV et V du livre III, à l'article L. 511-1 et aux titres Ier à IV du livre VIII du présent code, à l'article L. 821-1 du code de la construction et de l'habitation et à l'article L. 262-46 du code de l'action sociale et des familles. Cette retenue est effectuée par l'organisme gestionnaire de ces prestations, avec son accord, si l'assuré ne choisit pas de rembourser en un ou plusieurs versements dans un délai fixé par décret qui ne peut dépasser douze mois. Après cet accord, le recouvrement ne peut être effectué que si l'assuré n'est débiteur d'aucun indu sur ces mêmes prestations. Les modalités de recouvrement sont celles applicables aux prestations sur lesquelles les retenues sont faites. Un décret fixe les modalités d'application et le traitement comptable de ces opérations.

Avant d'exercer le recours mentionné à l'article L. 142-4, l'assuré peut demander, par des observations écrites ou orales, la rectification des informations le concernant qui ont une incidence sur le montant de l'indu. Il présente sa demande dans un délai déterminé à compter de la notification de l'indu et la justifie par tous moyens en sa possession.

Sans préjudice du droit de l'assuré d'exercer le recours mentionné à l'article L. 142-4, l'indu ne peut être mis en recouvrement, dans les conditions du présent article, avant les échéances suivantes :

1° Si l'assuré n'a pas exercé son droit de rectification à l'expiration du délai mentionné au quatrième alinéa, l'expiration de ce délai. Sans préjudice de cette règle, toute demande de rectification présentée après ce délai est réputée exercée dans les conditions du recours préalable mentionné à l'article L. 142-4 ;

2° Si l'assuré a exercé ce droit de rectification :

a) L'expiration d'un délai déterminé suivant celle du délai valant décision implicite de rejet ;

b) Ou la notification à l'assuré de la décision du directeur, lorsque cette notification intervient avant l'expiration du délai valant décision implicite de rejet mentionné à l'alinéa précédent.

Un décret en Conseil d'État fixe les éléments suivants :

1° Le délai mentionné au quatrième alinéa ;

2° Les délais mentionnés au a du 2° ;

3° Les mentions de la notification de l'indu, qui doivent obligatoirement comprendre le délai mentionné au quatrième alinéa ainsi que les voies et délais du recours préalable mentionné à l'article L. 142-4.
''', "Réécriture à droit constant : les conditions de récupération sur l'assuré et sur d'autres prestations sont dissociées en phrases explicites, puis le droit de rectification et les dates les plus précoces du recouvrement sont clarifiés. Les treize alinéas et les repères 1°, 2°, a), b) sont conservés pour préserver les renvois internes.", "Les réserves aux quatrième à neuvième alinéas continuent de viser exactement la procédure de rectification et ses suites. Sont maintenus l'indemnité de 10 % pour fraude, le délai réglementaire maximal de douze mois pour le remboursement choisi, l'accord de l'organisme gestionnaire, l'absence d'autre indu sur les mêmes prestations, la prise en compte de la situation sociale du ménage et tous les renvois intercodes. Les deux délais successifs du a du 2° ne sont pas confondus ; la décision explicite du b ne permet le recouvrement à sa notification que si elle précède l'expiration du délai de rejet implicite. Aucune extension du gel projeté des pensions à ces prestations de maladie, familiales, de logement ou de solidarité n'est effectuée.")

assert len(sources) == 19
assert len(drafts) == 19
assert {a['number'] for a in sources} == set(drafts)
answer = []
for source in sources:
    item = {key: source[key] for key in ('code_id', 'source_id', 'source_sha256', 'number')}
    item.update(drafts[source['number']])
    answer.append(item)
Path('answer.json').write_text(json.dumps(answer, ensure_ascii=False, indent=2) + '\n')
print(f'{len(answer)} articles écrits dans answer.json')
