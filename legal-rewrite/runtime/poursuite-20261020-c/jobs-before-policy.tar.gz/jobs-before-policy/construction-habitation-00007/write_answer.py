import json
from pathlib import Path

sources = json.loads(Path('source.json').read_text())
drafts = {}


def add(number, paragraphs, reason, review_notes):
    drafts[number] = {
        'proposed_xml': ''.join('<p>' + text + '</p>' for text in paragraphs),
        'reason': reason,
        'review_notes': review_notes,
    }


add('L200-9', [
    "Avant le commencement de tout travail de construction, l'assemblée générale d'une société régie par le présent titre et ayant pour objet la construction d'un immeuble doit approuver les conditions techniques et financières d'exécution des travaux. Elle doit également fixer les bases de répartition, entre les locaux à édifier, des différents éléments du prix de revient global, afin de déterminer le prix de chaque local. Avant le commencement de tout travail de construction, la société doit aussi justifier d'une garantie lui permettant de disposer des fonds nécessaires à l'achèvement de l'immeuble. Un décret en Conseil d'État définit la nature et les modalités de cette garantie.",
], "Réécriture à droit constant : les décisions de l'assemblée générale sur l'exécution et la répartition du prix sont distinguées de l'obligation de garantie qui incombe à la société. Les deux obligations restent préalables aux travaux. Aucune réforme de fond n'est appliquée à ce régime d'habitat participatif.",
    "L'alinéa unique, le champ des sociétés concernées et le renvoi au décret en Conseil d'État sont conservés. Le regroupement administratif prévu par policy.json ne dispense ni de l'approbation interne ni de la garantie d'achèvement.")

add('L200-9-1', [
    "I. – Les personnes suivantes peuvent conclure, au profit d'un tiers, une convention d'occupation temporaire du logement à titre de résidence principale :",
    "1° L'associé bénéficiant de la dérogation mentionnée au dernier alinéa des articles L. 201-2 et L. 202-2 ;",
    "2° Les héritiers ou légataires d'un associé décédé, dans les limites de la durée mentionnée au I de l'article L. 201-9 et à l'article L. 202-9-1.",
    "La convention d'occupation temporaire mentionnée au premier alinéa du présent I est soumise à la loi n° 89-462 du 6 juillet 1989 tendant à améliorer les rapports locatifs et portant modification de la loi n° 86-1290 du 23 décembre 1986, notamment à son article 11.",
    "Un décret en Conseil d'État fixe les conditions qui régissent cette convention d'occupation temporaire.",
    "II. – À l'expiration de la dérogation mentionnée au dernier alinéa des articles L. 201-2 et L. 202-2, l'associé doit soit occuper à nouveau le logement à titre de résidence principale, soit céder ses parts sociales, soit se retirer de la société. S'il ne remplit aucune de ces obligations, l'assemblée générale des associés prononce son exclusion de la société.",
], "Réécriture à droit constant : les bénéficiaires de la convention et les trois obligations alternatives à l'expiration de la dérogation sont explicités. Les subdivisions, les renvois et l'exclusion par l'assemblée générale sont maintenus. Aucune réforme de fond n'est introduite.",
    "L'application de la loi n° 89-462, notamment de son article 11, est conservée. La durée propre aux héritiers est renvoyée sans modification au I de L. 201-9 et à L. 202-9-1 ; ce dernier renvoi a été vérifié dans le corpus public. La voie de rénovation locative de vingt-quatre mois prévue par policy.json relève notamment de l'article 6 de la loi n° 89-462 et de ses textes d'application : elle exige une disposition hors des cinq codes définissant son champ, le contrôle des travaux, la compensation énergétique et la transition. Elle n'est pas assimilée à cette occupation temporaire ni appliquée aux conventions existantes.")

add('L200-10', [
    "L'assemblée générale des associés adopte une charte qui fixe les règles de fonctionnement de l'immeuble. Cette charte précise notamment les règles d'utilisation des lieux de vie collective mentionnés au 4° de l'article L. 201-2 et au 3° de l'article L. 202-2.",
    "Les locataires ou occupants qui n'ont pas la qualité d'associé doivent signer cette charte avant d'entrer dans les lieux. La charte est annexée à leur contrat de bail ou à la convention d'occupation temporaire mentionnée à l'article L. 200-9-1.",
    "Le futur locataire auquel est proposée l'attribution d'un logement locatif social relevant d'une société d'habitat participatif reçoit une copie des statuts de la société. Il reçoit également tout document que la société a souhaité annexer à ses statuts et qui concerne la participation des futurs habitants et sociétaires à la vie de la société d'habitat participatif. Le refus ou le défaut d'attestation de transmission de ce document vaut refus, par le futur locataire, de la proposition d'attribution du logement. Les conditions particulières du bail que le locataire signe ultérieurement sont annexées à ces documents.",
], "Réécriture à droit constant : l'adoption de la charte, sa signature et la remise des documents au candidat à un logement social sont présentées avec des sujets explicites. Les conséquences relatives à l'attribution et l'annexion des conditions du bail sont conservées dans le troisième alinéa. Aucune réforme de fond n'est appliquée.",
    "Incohérence préexistante : le 4° de L. 201-2 vise la gestion, l'entretien et l'amélioration des immeubles, tandis que les lieux de vie collective figurent au 5°. Le renvoi au 4° est conservé, sans correction silencieuse ; une coordination législative expresse de L. 200-10 serait nécessaire. Le renvoi au 3° de L. 202-2 est cohérent. La formule « refus ou défaut d'attestation de transmission de ce document » reste ambiguë sur l'objet du refus et sur le document visé au singulier après une énumération : cette ambiguïté est conservée et doit être clarifiée expressément si le fond est modifié.")

add('L200-11', [
    "Un décret en Conseil d'État précise les modalités d'application des dispositions du présent titre.",
], "Réécriture à droit constant de la disposition d'application : la formulation précise que les modalités portent sur les dispositions du titre et conserve le décret en Conseil d'État comme sujet explicite. Aucune réforme de fond.",
    "Le renvoi concerne l'ensemble du titre préliminaire relatif aux sociétés d'habitat participatif ; aucune habilitation nouvelle ni date d'entrée en vigueur n'est ajoutée.")

add('L201-1', [
    "Les sociétés coopératives d'habitants ont un capital variable. Sous réserve des dispositions du présent chapitre, elles sont régies par le chapitre Ier du titre III du livre II du code de commerce et par les titres Ier, II, II ter, III et IV de la loi n° 47-1775 du 10 septembre 1947 portant statut de la coopération. Elles peuvent être valablement constituées sous chacune des différentes formes prévues par la loi.",
], "Réécriture à droit constant : le caractère variable du capital est énoncé séparément des textes régissant la société. La réserve du présent chapitre et toutes les références à la loi de 1947 sont maintenues. Aucune réforme de fond.",
    "Les titres Ier, II, II ter, III et IV de la loi n° 47-1775 et le chapitre Ier du titre III du livre II du code de commerce sont repris sans extension. Le texte source sans balise est présenté en un seul alinéa balisé.")

add('L201-2', [
    "Les sociétés coopératives d'habitants ont pour objet de procurer à leurs associés personnes physiques la jouissance d'un logement à titre de résidence principale et de contribuer au développement de leur vie collective, dans les conditions du présent article. À cette fin, elles peuvent :",
    "1° Acquérir un ou plusieurs terrains ou des droits réels permettant de construire ;",
    "2° Construire ou acquérir des immeubles à usage principal d'habitation destinés à leurs associés ;",
    "3° Attribuer à leurs associés personnes physiques la jouissance de ces logements par le contrat coopératif mentionné à l'article L. 201-8 ;",
    "4° Assurer la gestion, l'entretien et l'amélioration des immeubles mentionnés au 2° du présent article ;",
    "5° Assurer l'entretien et l'animation de lieux de vie collective ;",
    "6° Fournir des services à leurs associés et, à titre accessoire, à des tiers non associés.",
    "Un décret en Conseil d'État fixe les conditions dans lesquelles il peut être dérogé à l'obligation d'établir sa résidence principale dans l'immeuble de la société coopérative régie par l'article L. 201-1. Il détermine notamment la durée maximale de cette dérogation.",
], "Réécriture à droit constant : la dénomination des sociétés remplace le pronom initial et les six activités autorisées restent identifiées par leur numéro. Le renvoi au décret est scindé en deux phrases, sans changer le champ de la dérogation. Aucune réforme de fond.",
    "Les numéros 1° à 6° et la position du dernier alinéa sont maintenus, notamment pour les renvois de L. 200-9-1, L. 201-3 et L. 201-8. L. 200-10 vise déjà le 4° pour les lieux de vie collective, alors qu'ils relèvent du 5° : cette incohérence doit être traitée dans L. 200-10, sans déplacer ici les subdivisions.")

add('L201-3', [
    "Les statuts peuvent autoriser la coopérative d'habitants à fournir à des tiers non associés les services mentionnés au 6° de l'article L. 201-2, dans les conditions fixées par décret en Conseil d'État. La coopérative tient, pour ces opérations, une comptabilité spéciale permettant de déterminer le résultat de cette activité.",
    "Le chiffre d'affaires de cette activité ne peut dépasser un pourcentage du capital social ou du chiffre d'affaires de la société. Ce pourcentage est fixé par décret en Conseil d'État.",
], "Réécriture à droit constant : l'autorisation statutaire et l'obligation comptable sont attribuées explicitement à la coopérative. Le plafond réglementaire est exposé dans deux phrases en conservant ses deux bases alternatives. Aucune réforme de fond.",
    "Le renvoi au 6° de L. 201-2, la comptabilité spéciale et l'alternative entre capital social et chiffre d'affaires sont conservés. Aucun pourcentage n'est inventé ; sa fixation demeure réglementaire.")

add('L201-4', [
    "Les statuts doivent interdire la cession ou le remboursement des parts sociales avant l'attribution des logements en jouissance. Les conditions dans lesquelles il peut être dérogé à ce délai sont fixées par décret en Conseil d'État.",
], "Réécriture à droit constant : le contenu obligatoire des statuts est exprimé directement comme une interdiction, avec maintien de la faculté de dérogation réglementaire. Aucune réforme de fond.",
    "Le terme du délai reste l'attribution en jouissance des logements, sans substitution par l'entrée matérielle dans les lieux. L'articulation avec les règles spéciales des parts en industrie de L. 201-13 est conservée sans extension de l'interdiction.")

add('L201-5', [
    "I. – Le prix de cession des parts sociales des sociétés coopératives ne peut dépasser leur montant nominal, augmenté d'une majoration qui tient compte de l'indice de référence des loyers et reste dans la limite du plafond prévu par les statuts.",
    "Toute cession de parts sociales qui méconnaît cette clause est nulle.",
    "Un associé coopérateur peut se retirer de la société après avoir obtenu l'autorisation de l'assemblée générale des associés.",
    "Toutefois, lorsque l'associé qui cède ses parts ou se retire présente un nouvel associé, l'autorisation ne peut être refusée que pour un motif sérieux et légitime. L'assemblée générale n'est pas obligée d'accepter la personne ainsi proposée. Elle peut autoriser le retrait ou la cession en agréant une autre personne, sans avoir à motiver sa décision. En cas de refus injustifié, le juge peut autoriser le retrait ou la cession s'il est saisi dans le délai d'un mois à compter de la notification du refus.",
    "II. – En cas de retrait, le prix de remboursement des parts sociales des sociétés coopératives ne peut dépasser leur montant nominal, augmenté d'une majoration dont les statuts fixent le plafond. Ce plafond ne peut excéder l'évolution de l'indice de référence des loyers. Le montant du remboursement ne peut dépasser le prix maximal de cession défini au premier alinéa du I du présent article.",
    "III. – L'assemblée générale ne peut exclure un associé que pour un motif sérieux et légitime. Le prix de remboursement des parts sociales de l'associé exclu ne peut dépasser leur montant nominal, augmenté d'une majoration. Cette majoration doit respecter le plafond prévu par les statuts et ne peut excéder l'évolution de l'indice de référence des loyers. L'associé exclu peut exercer un recours devant le juge, qu'il doit saisir dans le délai d'un mois à compter du jour où il a reçu notification de la décision d'exclusion.",
    "IV. – L'associé démissionnaire, exclu ou qui cède ses parts sociales n'a pas à supporter la quote-part des pertes afférentes aux amortissements de l'ensemble immobilier.",
    "La société rembourse à l'associé démissionnaire ou exclu les sommes qu'il a versées pour libérer ses parts sociales, après déduction des charges et frais que sa démission ou son exclusion a occasionnés à la société. Les statuts peuvent prévoir une évaluation forfaitaire de ces charges et frais, dans les limites fixées par décret en Conseil d'État.",
], "Réécriture à droit constant : les plafonds de cession, de remboursement en cas de retrait et de remboursement en cas d'exclusion sont distingués ; les recours, l'agrément d'une autre personne et les déductions sont formulés avec des sujets explicites. Les I à IV et leurs alinéas sont conservés. Aucune réforme de fond.",
    "Les deux délais d'un mois et leurs points de départ distincts sont maintenus. Au I, la majoration tient compte de l'indice de référence des loyers ; au II, le texte plafonne expressément le plafond statutaire par l'évolution de cet indice ; au III, il borne la majoration : ces formulations différentes ne sont pas uniformisées. Le renvoi au premier alinéa du I reste exact. L'exemption des pertes d'amortissement concerne aussi le cédant, tandis que le dernier alinéa de remboursement vise seulement le démissionnaire et l'exclu.")

add('L201-6', [
    "La société coopérative d'habitants doit constituer des provisions destinées à couvrir les gros travaux d'entretien et de réparation, la vacance des logements et les impayés de redevance. Un décret en Conseil d'État fixe les conditions de constitution de ces provisions.",
], "Réécriture à droit constant : l'obligation de provisionnement est exprimée directement et ses trois objets sont repris avant la règle d'application réglementaire. Aucune réforme de fond.",
    "Les provisions pour travaux, vacance et impayés restent distinctement visées. Aucun montant ni taux de provision n'est ajouté.")

add('L201-7', [
    "Les associés doivent participer aux charges des services collectifs et des éléments d'équipement commun. Avant toute entrée dans les lieux, l'assemblée générale des associés adopte un règlement qui fixe notamment les modalités de répartition de ces charges entre les associés. Ce règlement est annexé au contrat coopératif mentionné à l'article L. 201-8.",
], "Réécriture à droit constant : l'obligation des associés et la décision préalable de l'assemblée générale sont formulées directement, dans le même alinéa. L'annexion au contrat coopératif reste obligatoire. Aucune réforme de fond.",
    "Le règlement doit toujours être adopté avant toute entrée dans les lieux. Le texte n'importe pas les clés de répartition propres à L. 202-7 dans le régime des coopératives d'habitants.")

add('L201-8', [
    "La société coopérative d'habitants et chaque associé coopérateur concluent un contrat coopératif avant que cet associé entre en jouissance du logement. Ce contrat lui confère un droit de jouissance sur un logement et comporte notamment les mentions suivantes :",
    "1° La désignation et la description du logement dont l'associé coopérateur a la jouissance ainsi que des espaces destinés à l'usage commun des associés coopérateurs ;",
    "2° Les modalités d'utilisation des espaces mentionnés au 1° ;",
    "3° La date à laquelle l'associé entre en jouissance ;",
    "4° L'absence de maintien de plein droit dans les lieux prévue à l'article L. 201-9 ;",
    "5° Une estimation de la quote-part des charges mentionnées à l'article L. 201-7 que l'associé coopérateur doit payer au titre de la première année d'exécution du contrat ;",
    "6° Le montant de la redevance due par l'associé coopérateur, la périodicité de son versement et, le cas échéant, ses modalités de révision. À ce titre, le contrat coopératif précise :",
    "a) Le montant de la partie de la redevance qui correspond à la jouissance du logement, dénommée fraction locative ;",
    "b) Le montant de la partie de la redevance qui correspond à l'acquisition de parts sociales, dénommée fraction acquisitive.",
    "Lorsque le contrat coopératif est signé avant l'entrée en jouissance, aucun versement de redevance ne peut être exigé tant que la jouissance n'est pas effective.",
], "Réécriture à droit constant : les parties au contrat sont désignées comme sujets et la liste des mentions est rendue plus directe. Les 1° à 6°, les a et b, ainsi que l'interdiction de percevoir la redevance avant la jouissance effective sont conservés. Aucune réforme de fond.",
    "Le caractère non exhaustif des mentions, l'estimation limitée à la première année, la révision éventuelle et la distinction des fractions locative et acquisitive sont maintenus. L. 201-9, II, conserve la cessation du droit de jouissance à la perte de la qualité d'associé ; aucune transformation du contrat coopératif en bail ordinaire n'est proposée.")

add('L201-9', [
    "I. – Lorsqu'un associé coopérateur décède, ses héritiers ou légataires peuvent signer un contrat coopératif dans un délai de deux ans à compter de l'acceptation de la succession ou de la donation.",
    "",
    "",
    "II. – Quelle qu'en soit la cause, la perte de la qualité d'associé coopérateur met fin au contrat coopératif mentionné à l'article L. 201-8 et entraîne de plein droit la perte du droit de jouissance.",
], "Réécriture à droit constant : le délai ouvert aux héritiers ou légataires et la conséquence automatique de la perte de la qualité d'associé sont énoncés dans des phrases directes. Les I et II sont conservés, sans réforme de fond ni modification du point de départ du délai.",
    "Incohérence ou ambiguïté préexistante : après le décès, le texte fait courir les deux ans à compter de l'acceptation de « la succession ou de la donation ». Le terme donation est maintenu et nécessite un contrôle législatif, sans substitution silencieuse par une autre notion successorale. L. 202-9-1, vérifié dans le corpus public, comporte la même formule. Les deux paragraphes vides de la source sont conservés entre I et II ; ils ne contiennent aucune règle. Le renvoi de L. 200-9-1 au I reste inchangé.")

add('L201-10', [
    "La société coopérative d'habitants doit faire examiner périodiquement sa situation technique et financière ainsi que sa gestion. Cet examen, dénommé révision coopérative, est effectué dans les conditions fixées par décret en Conseil d'État.",
], "Réécriture à droit constant : l'obligation d'examen et la dénomination de révision coopérative sont énoncées dans deux phrases. Les trois objets de l'examen et le renvoi réglementaire sont conservés. Aucune réforme de fond.",
    "La périodicité demeure celle résultant des textes d'application : aucune fréquence nouvelle n'est fixée. Le contrôle technique, le contrôle financier et l'examen de la gestion restent tous requis.")

add('L201-11', [
    "Par dérogation à l'article 19 de la loi n° 47-1775 du 10 septembre 1947 précitée, en cas de dissolution, l'assemblée générale décide de la dévolution de l'actif net qui subsiste après extinction du passif et remboursement du capital effectivement versé, sous réserve de l'application des articles 16 et 18 de la même loi. Cette dévolution bénéficie à d'autres coopératives d'habitants régies par le présent code, à une union qui les fédère ou à tout organisme d'intérêt général destiné à aider à leur financement initial ou à garantir l'achèvement de la production de logement.",
], "Réécriture à droit constant : l'assemblée générale est désignée comme l'auteur de la décision et les bénéficiaires sont présentés dans une phrase distincte. L'ordre de liquidation, la dérogation et les réserves légales sont conservés dans un seul alinéa. Aucune réforme de fond.",
    "Les références aux articles 19, 16 et 18 de la loi n° 47-1775 sont maintenues. Elles s'articulent avec les exclusions expresses de certains alinéas des articles 16 et 18 à L. 201-12 ; la réserve générale n'est pas étendue aux dispositions ainsi exclues. Le financement initial et la garantie d'achèvement restent des finalités alternatives pour l'organisme d'intérêt général.")

add('L201-12', [
    "Les sociétés régies par le présent chapitre ne sont pas soumises aux deux derniers alinéas de l'article 16, à l'article 17 ni au deuxième alinéa de l'article 18 de la loi n° 47-1775 du 10 septembre 1947 précitée.",
], "Réécriture à droit constant : les sociétés concernées sont placées en sujet, puis les exclusions sont énumérées dans leur ordre d'origine. Aucune réforme de fond.",
    "L'exclusion de l'article 17 demeure intégrale ; celles des articles 16 et 18 restent limitées respectivement aux deux derniers alinéas et au deuxième alinéa. Les renvois par rang d'alinéa sont conservés et devront être coordonnés si la loi de 1947 est restructurée.")

add('L201-13', [
    "Les coopérateurs peuvent souscrire des parts sociales en industrie correspondant à un apport travail pendant la phase de construction ou de rénovation du projet immobilier, ou lors de travaux de réhabilitation du bâti. Cette souscription est notamment soumise à un encadrement technique adapté et à un nombre minimal d'heures. L'assemblée générale fixe le nombre d'heures constitutif de ces parts par un vote unanime des coopérateurs. Ces parts doivent être intégralement libérées avant la fin des travaux concernés et leur montant est plafonné à celui de l'apport initial demandé aux coopérateurs. Elles concourent à la formation du capital social. Elles peuvent alors être cédées ou remboursées après un délai de deux ans à compter de leur libération totale, après déduction d'un montant réparti correspondant aux coûts spécifiques engendrés par cet apport travail.",
    "Un décret en Conseil d'État définit l'apport travail, ses conditions d'application et le nombre minimal d'heures requis.",
], "Réécriture à droit constant : les phases de travaux, les conditions de souscription, le vote unanime, la libération et la cessibilité sont exposés dans des phrases distinctes tout en gardant le premier alinéa. Le second alinéa conserve l'ensemble des objets du décret. Aucune réforme de fond.",
    "Le délai de deux ans court toujours de la libération totale, non de la fin des travaux. L'unanimité, le plafond de l'apport initial et la déduction des coûts spécifiques sont maintenus. La source ne précise pas dans la formule « montant, réparti » entre qui ces coûts sont répartis : la proposition ne crée pas de clé. La participation des parts en industrie à la formation du capital est conservée comme règle spéciale expresse ; elle n'est pas effacée par assimilation au régime général des apports en industrie.")

add('L202-1', [
    "Les sociétés d'attribution et d'autopromotion ont un capital variable. Sous réserve des dispositions du présent chapitre, elles sont régies par le chapitre Ier du titre III du livre II du code de commerce. Elles peuvent être valablement constituées sous chacune des différentes formes prévues par la loi.",
], "Réécriture à droit constant : le capital variable, les règles applicables et les formes de constitution sont exposés dans trois phrases. La réserve des dispositions spéciales du chapitre est maintenue. Aucune réforme de fond.",
    "Le seul renvoi général demeure celui au chapitre Ier du titre III du livre II du code de commerce. Les dispositions de la loi de 1947 propres aux coopératives d'habitants ne sont pas importées dans ce chapitre.")

add('L202-2', [
    "Les sociétés d'attribution et d'autopromotion ont pour objet d'attribuer à leurs associés personnes physiques la propriété ou la jouissance d'un logement à titre de résidence principale, ainsi que d'entretenir et d'animer les lieux de vie collective qui y sont attachés. À cette fin, elles peuvent :",
    "",
    "1° Acquérir un ou plusieurs terrains ou des droits réels permettant de construire ;",
    "2° Acquérir ou construire des immeubles à usage d'habitation pour les diviser en fractions destinées à être attribuées aux associés en propriété ou en jouissance à titre de résidence principale ;",
    "3° Assurer la gestion, l'entretien et l'amélioration des immeubles leur appartenant et des lieux de vie collective qu'ils comportent ;",
    "4° Fournir des services à leurs associés et, à titre accessoire, à des tiers non associés, dans les conditions fixées par décret en Conseil d'État. La société tient une comptabilité séparée pour ces opérations.",
    "Le chiffre d'affaires de ces opérations ne peut dépasser un pourcentage du capital social ou du chiffre d'affaires de la société. Ce pourcentage est fixé par décret en Conseil d'État.",
    "Dès la constitution de la société, les statuts doivent choisir entre l'attribution des logements en jouissance et leur attribution en propriété.",
    "Un décret en Conseil d'État fixe les conditions dans lesquelles il peut être dérogé à l'obligation d'établir sa résidence principale dans l'immeuble de la société régie par l'article L. 202-1. Il détermine notamment la durée maximale de cette dérogation.",
], "Réécriture à droit constant : la société est nommée dès l'introduction ; les activités autorisées, la comptabilité séparée et le choix statutaire sont formulés directement. Les 1° à 4° et les alinéas finaux sont maintenus. Aucune réforme de fond.",
    "Le 3° continue de viser les lieux de vie collective, conformément aux renvois de L. 200-10 et L. 202-7. Le dernier alinéa reste celui visé par L. 200-9-1. Le plafond de chiffre d'affaires conserve ses deux bases alternatives, sans taux nouveau. Le paragraphe vide après l'introduction est conservé ; les simples sauts de ligne décoratifs sont supprimés. L'option statutaire reste obligatoire dès la constitution et la durée maximale de la dérogation reste réglementaire.")

add('L202-3', [
    "Un état descriptif de division, annexé aux statuts, délimite les lots et les différentes parties de l'immeuble en distinguant les parties communes de celles à usage privatif. S'il y a lieu, il fixe la quote-part des parties communes attachée à chaque lot. Les statuts répartissent en groupes les droits composant le capital social et affectent à chaque groupe l'un des lots définis par cet état descriptif, en vue de son attribution au titulaire du groupe concerné.",
    "En cas d'attribution en propriété, un règlement précise la destination des parties réservées à l'usage privatif des associés. S'il y a lieu, il précise également celle des parties communes affectées à l'usage de tous les associés ou de plusieurs d'entre eux.",
    "Lorsque l'attribution en propriété d'une ou plusieurs fractions de l'immeuble entraîne l'application de la loi n° 65-557 du 10 juillet 1965 fixant le statut de la copropriété des immeubles bâtis, le règlement doit être établi conformément à cette loi et annexé aux statuts de la société.",
    "En cas d'attribution en jouissance, un règlement en jouissance délimite les différentes parties de l'immeuble en distinguant les parties communes de celles à usage privatif. Il précise la destination des parties à usage privatif et, s'il y a lieu, celle des parties communes affectées à l'usage de tous les associés ou de plusieurs d'entre eux. Ce règlement est annexé aux statuts.",
    "L'état descriptif de division, les règlements mentionnés au présent article et les dispositions des statuts qui leur correspondent doivent être adoptés avant le commencement de tout travail de construction.",
], "Réécriture à droit constant : la constitution des lots, l'affectation des groupes de droits et les deux régimes de règlement sont présentés avec des phrases plus courtes. Les cinq alinéas et l'adoption préalable aux travaux sont conservés. Aucune réforme de fond.",
    "La soumission à la loi n° 65-557 reste conditionnée par les effets de l'attribution en propriété d'une ou plusieurs fractions. L'état descriptif et les règlements demeurent annexés aux statuts selon leurs règles respectives ; le règlement en jouissance conserve son objet distinct du règlement applicable en propriété.")

add('L202-4', [
    "Chaque associé doit répondre aux appels de fonds nécessaires à la construction de l'immeuble, à proportion de ses droits dans le capital.",
], "Réécriture à droit constant : l'obligation collective est formulée au singulier pour préciser la contribution de chaque associé. L'objet des appels de fonds et la proportionnalité aux droits dans le capital sont maintenus. Aucune réforme de fond.",
    "La règle reste limitée aux appels de fonds nécessités par la construction. Les sanctions de L. 202-5 et la valorisation des droits prévue à L. 202-6 ne sont ni modifiées ni déplacées.")

add('L202-5', [
    "L'associé qui ne remplit pas ses obligations envers la société au titre de l'article L. 202-4 ne peut prétendre ni à l'entrée en jouissance de la fraction de l'immeuble à laquelle il a vocation, ni au maintien dans cette jouissance, ni à l'attribution de cette fraction en propriété.",
    "Les droits sociaux de l'associé défaillant peuvent être mis en vente publique un mois après une sommation de payer restée sans effet. La vente doit être autorisée par l'assemblée générale à la majorité des deux tiers des droits sociaux. Sur deuxième convocation, la majorité requise est celle des deux tiers des droits sociaux dont les titulaires sont présents ou représentés. Malgré toute disposition contraire des statuts, les parts ou actions des associés dont la mise en vente des droits sociaux est inscrite à l'ordre du jour de l'assemblée sont exclues du calcul des majorités requises.",
    "La mise en vente publique doit être notifiée à l'associé défaillant et publiée sur un support habilité à recevoir des annonces légales du lieu du siège social. Si cet associé détient plusieurs groupes de droits sociaux donnant vocation à des parties différentes de l'immeuble, chaque groupe peut être vendu séparément.",
    "La vente est réalisée pour le compte et aux risques de l'associé défaillant. Celui-ci reste tenu envers la société des appels de fonds mis en recouvrement avant la vente. Le produit de l'adjudication est affecté par privilège au paiement des sommes que cet associé doit à la société. Ce privilège prime toutes les sûretés réelles conventionnelles qui grèvent ses droits sociaux. Lorsque les parts ou actions vendues en application du présent article ont été nanties, les créanciers nantis ne peuvent opposer leur droit de rétention ni à la société ni à l'adjudicataire des droits sociaux.",
], "Réécriture à droit constant : les effets de la défaillance, le délai préalable, les deux majorités et les suites de l'adjudication sont exposés dans des phrases plus courtes. Les quatre alinéas et toutes les garanties de notification, publicité et priorité sont maintenus. Aucune réforme de fond.",
    "Le délai d'un mois après sommation, les deux majorités des deux tiers et l'exclusion des parts ou actions de tous les associés concernés à l'ordre du jour sont conservés. La priorité reste limitée aux sûretés réelles conventionnelles ; elle n'est pas généralisée. L. 202-7 rend déjà cet article applicable aux obligations de charges. Il s'agit ici de la vente de droits sociaux, non d'une procédure générale d'expulsion ou de traitement des impayés locatifs. La réforme de ces dernières procédures exige notamment des dispositions relatives à l'article 24 de la loi n° 89-462 et aux textes de procédure civile et d'exécution, hors des cinq codes, avec transition propre.")

add('L202-6', [
    "Les droits de chaque associé dans le capital social doivent être proportionnels au rapport entre la valeur des biens auxquels il a vocation et la valeur de l'ensemble. Ces valeurs sont déterminées d'après la consistance, la superficie, la situation et les possibilités d'utilisation des biens, appréciées au jour de leur affectation à des groupes de droits sociaux déterminés.",
], "Réécriture à droit constant : la règle de proportionnalité et les critères de valeur sont distingués dans deux phrases, au sein du même alinéa. La date d'appréciation reste celle de l'affectation aux groupes de droits sociaux. Aucune réforme de fond.",
    "Les quatre critères de valeur sont tous maintenus, y compris les possibilités d'utilisation. Ils ne sont pas confondus avec les trois critères des valeurs relatives de répartition des charges du deuxième alinéa de L. 202-7. Aucune réévaluation à une autre date n'est créée.")

add('L202-7', [
    "Les associés doivent participer aux charges des services collectifs et des éléments d'équipement communs. Leur participation dépend de l'utilité relative de ces services et équipements pour chaque lot mentionné à l'article L. 202-3.",
    "Les associés doivent également participer aux charges de conservation, d'entretien et d'administration des parties communes et des espaces communs. Cette participation est proportionnelle aux valeurs relatives des parties privatives comprises dans leurs lots. Ces valeurs sont déterminées d'après la consistance, la superficie et la situation des lots.",
    "Le règlement de copropriété ou le règlement en jouissance prévus à l'article L. 202-3 fixent la quote-part de chaque lot pour chacune des catégories de charges. À défaut, ils indiquent les bases de répartition pour une ou plusieurs catégories de charges.",
    "L'article L. 202-5 s'applique à l'exécution des obligations des associés envers la société qui résultent du présent article.",
    "Un associé peut demander au juge de réviser, pour l'avenir, la répartition des charges prévues au présent article lorsque, dans l'une ou l'autre des catégories de charges, la part de son lot dépasse de plus d'un quart celle qui résulterait d'une répartition conforme au premier alinéa du présent article, ou lorsque la part d'un autre lot est inférieure de plus d'un quart à celle qui résulterait de cette même répartition. Si l'action est fondée, le juge établit une nouvelle répartition.",
    "Pour les décisions relatives à la gestion ou à l'entretien de l'immeuble, chaque associé dispose, malgré toute disposition contraire, d'un nombre de voix proportionnel à sa participation aux dépenses entraînées par l'exécution de la décision. Lorsque le règlement de copropriété ou le règlement en jouissance prévu à l'article L. 202-3 met à la charge de certains associés seulement les dépenses d'entretien d'une partie de l'immeuble ou les dépenses d'entretien et de fonctionnement d'un élément d'équipement, seuls ces associés votent sur les décisions relatives à ces dépenses. Chacun dispose alors d'un nombre de voix proportionnel à sa participation à ces dépenses.",
    "L'assemblée générale des associés adopte une charte qui fixe les règles de fonctionnement de l'immeuble, notamment les règles d'utilisation des lieux de vie collective mentionnés au 3° de l'article L. 202-2.",
    "Les locataires qui n'ont pas la qualité d'associé doivent signer cette charte avant d'entrer dans les lieux. La charte est annexée à leur contrat de bail.",
], "Réécriture à droit constant : les deux catégories de charges et leurs clés propres sont distinguées ; les conditions du recours judiciaire et les règles de vote sont décomposées en phrases plus lisibles. Les huit alinéas, le seuil strict de plus d'un quart et la charte sont maintenus. Aucune réforme de fond.",
    "Incohérence préexistante à contrôler : le cinquième alinéa renvoie au seul premier alinéa pour comparer les quotes-parts dans l'une ou l'autre des catégories de charges, alors que la seconde relève du deuxième alinéa. Ce renvoi est conservé sans correction silencieuse. La révision reste prospective. Le vote particulier vise les seuls associés supportant les dépenses concernées. Les deux derniers alinéas recoupent L. 200-10, qui vise aussi les occupants non associés et les conventions temporaires : aucun des deux champs n'est réduit ni fusionné.")

assert len(sources) == 24
assert len(drafts) == 24
assert {a['number'] for a in sources} == set(drafts)
answer = []
for source in sources:
    item = {key: source[key] for key in ('code_id', 'source_id', 'source_sha256', 'number')}
    item.update(drafts[source['number']])
    item['status'] = 'rewrite_draft'
    answer.append(item)
Path('answer.json').write_text(json.dumps(answer, ensure_ascii=False, indent=2) + '\n')
print('answer.json :', len(answer), 'articles')
