import json
from pathlib import Path

sources = json.loads(Path('source.json').read_text())
references = json.loads(Path('reference-targets.json').read_text())
drafts = {}

def put(number, text, reason, notes, benefit=None, removed=None, repeal=None):
    paragraphs = [p.strip() for p in text.strip().split('\n\n') if p.strip()]
    item = dict(proposed_xml='\n'.join('<p>'+p+'</p>' for p in paragraphs), reason=reason, review_notes=notes)
    if benefit:
        item['benefit_review'] = benefit
    if removed:
        item.update(change_type='normative_reduction', reform_policy_id='editorial_direction_2026_10_19', removed_provisions=removed)
    if repeal:
        item.update(change_type='full_repeal', repeal_policy_id='editorial_direction_2026_10_19', repeal_scope=repeal)
    drafts[number] = item

put('200 quindecies', '''
I. – Les contribuables domiciliés en France au sens de l'article 4 B bénéficient d'un crédit d'impôt pour les opérations forestières mentionnées au II qu'ils réalisent jusqu'au 31 décembre 2027.

II. – Le crédit d'impôt s'applique :

1° Au prix d'acquisition de terrains en nature de bois et forêts ou de terrains nus à boiser, sans condition minimale de superficie de l'unité de gestion après l'acquisition.

Pour les terrains acquis en nature de bois et forêts, le contribuable s'engage à les conserver pendant quinze ans et à leur appliquer, pendant cette durée, un plan simple de gestion agréé par le centre régional de la propriété forestière. Si aucun plan n'est agréé lors de l'acquisition, il s'engage à en faire agréer un dans les trois ans suivant l'acquisition, puis à l'appliquer pendant quinze ans. Jusqu'à l'agrément, il applique à la forêt le régime d'exploitation normale prévu par le décret du 28 juin 1930 relatif aux conditions d'application de l'article 15 de la loi de finances du 16 avril 1930. Pour les terrains acquis nus, il s'engage à les reboiser dans les trois ans, puis à les conserver pendant quinze ans et à leur appliquer, pendant cette même durée, un plan simple de gestion agréé.

Lorsque la superficie des terrains boisés possédés et acquis ne satisfait pas aux minima des articles L. 122-4 et L. 312-1 du code forestier permettant l'agrément et l'application d'un plan simple de gestion, le propriétaire applique un autre document de gestion durable prévu à l'article L. 122-3 du même code. Il le fait dans les mêmes conditions que celles du deuxième alinéa du présent 1° applicables lorsqu'un plan simple de gestion peut être mis en œuvre ;

2° Aux souscriptions ou acquisitions en numéraire de parts d'intérêt de groupements forestiers qui s'engagent à appliquer pendant quinze ans un plan simple de gestion agréé ou un règlement type de gestion approuvé par le centre régional de la propriété forestière. Si aucun de ces documents n'est agréé ou approuvé lors de la souscription, le groupement s'engage à en faire agréer ou approuver un dans les trois ans suivant la souscription et à l'appliquer pendant quinze ans. Dans l'attente, il applique à la forêt le régime d'exploitation normale prévu par le décret du 28 juin 1930 précité. Le souscripteur ou l'acquéreur s'engage à conserver les parts jusqu'au 31 décembre de la huitième année suivant la date de la souscription ;

3° Aux souscriptions en numéraire au capital initial ou aux augmentations de capital des sociétés d'épargne forestière définies à l'article L. 214-121 du code monétaire et financier, ainsi qu'aux acquisitions en numéraire de leurs parts, lorsque la société et le souscripteur ou l'acquéreur prennent les engagements du 2° du présent II ;

4° Aux dépenses de travaux forestiers réalisés dans une propriété présentant l'une des garanties de gestion durable des articles L. 124-1 et L. 124-3 du code forestier ou, si le propriétaire a fait approuver un programme de coupes et de travaux par le Centre national de la propriété forestière, bénéficiant de la présomption de garanties de l'article L. 124-2 du même code. Les deux conditions suivantes doivent être remplies :

a) Le contribuable s'engage à conserver la propriété jusqu'au 31 décembre de la huitième année suivant celle des travaux et, pendant la même durée, à appliquer l'une des garanties des articles L. 124-1 et L. 124-3 de ce code ou, si le Centre national de la propriété forestière a approuvé un programme de coupes et de travaux, à respecter les conditions de l'article L. 124-2 permettant de bénéficier de la présomption prévue par cet article ;

b) Les plantations utilisent des graines et plants forestiers conformes aux prescriptions des arrêtés régionaux relatifs aux aides de l'État à l'investissement forestier pris conformément à la partie réglementaire du même code ;

5° Aux dépenses de travaux forestiers payées par un groupement forestier ou une société d'épargne forestière dont le contribuable est membre, ou par un groupement d'intérêt économique et environnemental forestier défini aux articles L. 332-7 et L. 332-8 du même code dont il est membre directement ou par l'intermédiaire d'un groupement forestier ou d'une société d'épargne forestière. La propriété du groupement forestier ou de la société sur laquelle les travaux sont réalisés doit présenter l'une des garanties des articles L. 124-1 et L. 124-3 du même code et les trois conditions suivantes doivent être remplies :

a) Le contribuable s'engage à conserver ses parts jusqu'au 31 décembre de la quatrième année suivant celle des travaux. Le cas échéant, le contribuable, le groupement forestier ou la société d'épargne forestière s'engage à rester membre du groupement d'intérêt économique et environnemental forestier pendant cette période ;

b) Le contribuable, le groupement ou la société s'engage à conserver les parcelles ayant fait l'objet des travaux ouvrant droit au crédit jusqu'au 31 décembre de la huitième année suivant celle des travaux et à appliquer pendant cette durée l'une des garanties des articles L. 124-1 et L. 124-3 du même code ;

c) Les plantations utilisent des graines et plants forestiers conformes aux prescriptions des arrêtés régionaux relatifs aux aides de l'État à l'investissement forestier pris conformément à la partie réglementaire du même code ;

6° À la cotisation versée à un assureur par le contribuable, un groupement forestier ou une société d'épargne forestière dont il est membre pour un contrat couvrant notamment le risque de tempête ou d'incendie et répondant aux conditions fixées par décret.

Un décret précise les conditions et modalités d'application du présent II. Les engagements peuvent être exprimés dans la déclaration sur laquelle le crédit est demandé, sans acte fiscal d'engagement distinct. Une décision d'agrément ou d'approbation déjà légalement accessible à l'administration n'est pas produite une seconde fois. Ces simplifications ne dispensent pas de la gestion durable requise ni de l'agrément ou de l'approbation du document qui la définit.

III. – A. – Pour les dépenses des 1° à 3° du II, le crédit est calculé sur les bases suivantes :

1° Le prix d'acquisition défini au 1° du II. Pour des terrains situés dans un massif de montagne défini à l'article 5 de la loi n° 85-30 du 9 janvier 1985 relative au développement et à la protection de la montagne, ce prix est augmenté de celui des acquisitions de terrains en nature de bois et forêts ou de terrains nus à boiser réalisées pendant les trois années précédentes pour constituer l'unité de gestion, si l'acquéreur prend pour ces terrains les engagements du 1° du II du présent article ;

2° Le prix d'acquisition ou de souscription défini au 2° du II ;

3° 60 % du prix d'acquisition ou de souscription défini au 3° du II.

B. – Pour les dépenses des 4° et 5° du II, le crédit est calculé sur les bases suivantes :

1° Les dépenses payées mentionnées au 4° du II ;

2° La fraction des dépenses payées mentionnées au 5° du II correspondant aux droits du contribuable dans le groupement ou la société.

C. – Pour les dépenses du 6° du II, le crédit est calculé sur la cotisation d'assurance payée par le contribuable ou sur la fraction de celle payée par le groupement forestier ou la société d'épargne forestière correspondant aux droits du contribuable dans ces organismes.

Les dépenses des 4° et 5° du II et la cotisation du 6° du même II n'ouvrent pas droit au crédit lorsqu'elles sont payées avec des sommes prélevées sur un compte d'investissement forestier et d'assurance prévu au chapitre II du titre V du livre III du code forestier.

IV. – A. – Les prix et fractions de prix mentionnés au A du III sont retenus ensemble dans la limite de 6 250 € pour une personne célibataire, veuve ou divorcée et de 12 500 € pour un couple marié ou des partenaires de pacte civil de solidarité soumis à imposition commune.

B. – Les dépenses et fractions de dépenses mentionnées au B du III sont retenues ensemble dans les mêmes limites de 6 250 € et 12 500 €, selon la situation familiale définie au A. Leur fraction excédentaire est retenue, dans la même limite :

1° Au titre des quatre années suivant celle du paiement des travaux ;

2° Au titre des huit années suivant celle du paiement des travaux en cas de sinistre forestier auquel le premier alinéa de l'article 1398 s'applique.

C. – Les dépenses du C du III sont retenues dans la limite de 15 € par hectare assuré et, globalement, de 6 250 € pour une personne célibataire, veuve ou divorcée et de 12 500 € pour un couple marié ou des partenaires de pacte civil de solidarité soumis à imposition commune. Le contribuable justifie, sur demande, que sa propriété en nature de bois et forêts est assurée contre le risque de tempête ou d'incendie, au moyen du contrat et des pièces ordinaires de l'assureur ou de tout autre élément probant. Aucune attestation fiscale d'assurance distincte n'est exigée et les pièces déjà légalement accessibles à l'administration ne sont pas demandées une seconde fois.

V. – Les aides publiques reçues pour les acquisitions et souscriptions des 1° à 3° du II, les travaux des 4° et 5° du même II et la cotisation du 6° de ce II sont déduites des bases de calcul du crédit relatives aux mêmes dépenses.

Cette déduction précède l'application des plafonds du IV.

VI. – A. – Le taux du crédit est de 25 %.

B. – Il est porté à 76 % pour la cotisation mentionnée au 6° du II.

VII. – Le crédit s'impute sur l'impôt dû :

1° Pour l'année d'acquisition des terrains du 1° du II et d'acquisition ou de souscription des parts des 2° et 3° du même II ;

2° Pour l'année de paiement des dépenses des 4° et 5° du II. Il peut s'imputer sur l'impôt des quatre années suivantes ou des huit années suivantes en cas de sinistre forestier, dans les conditions des 1° et 2° du B du IV ;

3° Pour l'année de paiement de la cotisation d'assurance du 6° du II.

La part du crédit excédant l'impôt dû pour l'année concernée est restituée.

VIII. – Le crédit est repris au titre de l'année où le contribuable, le groupement ou la société d'épargne forestière cesse de respecter un engagement du II. Il est également repris en cas de dissolution du groupement ou de la société, ou de méconnaissance par celle-ci des articles L. 214-121 et L. 214-123 à L. 214-125 du code monétaire et financier.

Toutefois, aucune reprise n'est effectuée dans les cas suivants :

1° Licenciement, invalidité relevant de la deuxième ou de la troisième catégorie de l'article L. 341-4 du code de la sécurité sociale, ou décès du contribuable ou d'un époux ou partenaire de pacte civil de solidarité soumis à imposition commune. La dispense liée au licenciement bénéficie aussi à la rupture à l'initiative de l'employeur d'un contrat de travail unique conclu à compter de l'entrée en vigueur de la loi instituant ce contrat, y compris pendant l'essai, sans condition d'ancienneté, d'indemnité ordinaire ou d'exécution effective du préavis ;

2° Apport par le contribuable à un groupement forestier ou à une société d'épargne forestière des terrains ayant ouvert droit au crédit, sans durée minimale préalable de détention, s'il s'engage à conserver les parts reçues en contrepartie pendant la durée de détention des terrains restant à courir à la date de l'apport ;

3° Donation des terrains ou parts ayant ouvert droit au crédit, si les donataires reprennent les engagements du donateur pour la durée restant à courir à la date de la donation.

IX. – Le crédit mentionné au I est subordonné au respect du règlement (UE) 2023/2831 de la Commission du 13 décembre 2023 relatif à l'application des articles 107 et 108 du traité sur le fonctionnement de l'Union européenne aux aides de minimis.

La suppression de la superficie minimale s'applique aux acquisitions réalisées à compter de l'entrée en vigueur de la présente réforme. La suppression du délai de détention préalable à l'apport s'applique aux apports réalisés à compter de cette date, y compris pour des acquisitions antérieures éligibles. Les simplifications de justification s'appliquent aux formalités accomplies à compter de cette date, sans dossier déjà déposé à refaire. Les droits, reprises pour manquement aux conditions maintenues, restitutions, prescriptions et recours antérieurs demeurent régis par les règles qui leur sont applicables. Ces dispositions ne rouvrent aucun délai de réclamation expiré et ne modifient pas la date du 31 décembre 2027 prévue au I.
''',
"Réécriture intégrale des neuf subdivisions et de leurs conditions. Réforme de fond : suppression du seuil d'acquisition de quatre hectares, du délai de deux ans avant apport et des pièces fiscales distinctes redondantes ; la dispense de reprise après licenciement couvre les ruptures patronales du contrat unique. À droit constant, conservation des taux, plafonds, reports, garanties de gestion durable, reprises et régime européen.",
"Les durées de quinze ans, huitième et quatrième années et les délais de trois ans sont maintenus pour assurer la gestion forestière durable et la continuité de l'investissement aidé ; les agréments des documents forestiers conservent leur fonction environnementale. Le seuil de quatre hectares et l'attente de deux ans n'ajoutaient pas de garantie de gestion à ces engagements. Conserver la règle source visant l'année de souscription pour la conservation des parts, même en cas d'acquisition : ambiguïté préexistante à coordonner, sans correction implicite. Adapter les décrets du II et les formulaires à la suppression des pièces distinctes. La note source sur les aides octroyées depuis le 1er janvier 2024 reste applicable ; elle ne date pas cette réforme. Les renvois forestiers, monétaires et de sécurité sociale déjà présents ne sont pas des renvois au contrat privé. L1234-3 et les règlements de calcul ne figurent pas dans les cibles fournies : aucun nouveau renvoi n'est créé vers eux.",
"Sont conservés les six objets du crédit : terrains, parts de groupements, parts de sociétés d'épargne forestière, travaux directs ou mutualisés et assurance. Restent le cumul des acquisitions de montagne sur trois ans, la base de 60 %, les plafonds de 6 250/12 500 €, les 15 € par hectare, les reports de quatre/huit ans, les taux de 25/76 % et la restitution. La faculté d'utiliser un autre document de gestion durable lorsque les minima forestiers ne permettent pas un plan simple et l'éligibilité des travaux sous présomption de garantie de L124-2 avec programme approuvé restent applicables ; l'agrément de ce programme ne s'étend pas aux garanties autonomes de L124-1 et L124-3. Les dispenses de reprise pour licenciement, invalidité et décès, pour apport avec conservation des parts et pour donation avec reprise des engagements restent ouvertes aux situations futures éligibles. L'apport devient possible sans attendre deux ans ; les petites unités deviennent admissibles. Le crédit n'est pas une taxe de succession et sa dispense pour décès subsiste. Les contraintes de minimis et l'exclusion des mêmes dépenses financées par le compte forestier restent à leur objet.",
[
"Suppression de la superficie minimale de quatre hectares de l'unité de gestion conditionnant l'avantage à l'acquisition.",
"Suppression des deux années de détention préalables à un apport de terrains bénéficiant de la dispense de reprise.",
"Suppression de l'attestation fiscale d'assurance distincte et de la production répétée des décisions déjà accessibles ; engagements fiscaux sans acte séparé."
])

put('200 sexdecies', '''
I. – A. – Lorsqu'elles ne sont pas prises en compte pour évaluer les revenus d'une catégorie, les sommes versées par un contribuable domicilié en France au sens de l'article 4 B pour son premier abonnement ouvrent droit à un crédit d'impôt sur le revenu dans les conditions suivantes. Sont éligibles les versements effectués jusqu'au 31 décembre 2022 ainsi que ceux effectués à compter de l'entrée en vigueur de la présente réforme. L'abonnement doit porter sur un journal, une publication paraissant au moins une fois par trimestre ou un service de presse en ligne reconnu en application de l'article 1er de la loi n° 86-897 du 1er août 1986 portant réforme du régime juridique de la presse. Le journal ou la publication doit présenter le caractère de presse d'information politique et générale au sens de l'article 4 de la loi n° 47-585 du 2 avril 1947 relative au statut des entreprises de groupage et de distribution des journaux et publications périodiques ; le service en ligne doit présenter ce caractère au sens du décret pris pour l'application de l'article 1er de la loi n° 86-897 précitée. Pour les versements effectués jusqu'au 31 décembre 2022, la durée minimale d'abonnement demeure de douze mois ; aucune durée minimale n'est requise pour les versements effectués à compter de l'entrée en vigueur de la présente réforme.

Un abonnement en ligne n'ouvre pas droit au crédit s'il est inclus dans un service de diffusion numérique groupée de services de presse en ligne ou de versions numérisées de journaux ou publications périodiques ne présentant pas tous le caractère de presse d'information politique ou générale, ou s'il est associé à un autre service.

B. – Le revenu du foyer fiscal défini au IV de l'article 1417, pour l'avant-dernière année précédant celle du premier abonnement, ne doit pas dépasser 24 000 € pour une part de quotient familial. Cette limite est augmentée de 25 % par demi-part supplémentaire.

II. – Le crédit est égal à 30 % des dépenses du I effectivement supportées par le contribuable.

Il n'est accordé qu'une fois à un même foyer fiscal. Un foyer qui en a déjà bénéficié au titre des versements effectués jusqu'au 31 décembre 2022 ne peut en bénéficier une seconde fois au titre de la réouverture du dispositif.

Il s'impute sur l'impôt sur le revenu après les réductions des articles 199 quater F à 200 bis, les crédits d'impôt et les prélèvements ou retenues non libératoires. L'excédent sur l'impôt dû est restitué.

III. – Le contribuable établit, sur demande de l'administration, le montant et la date des versements, l'identité et l'adresse du bénéficiaire et de l'organisme de presse, ainsi que l'éligibilité de la publication ou du service et de l'abonnement. Il peut utiliser les factures, le contrat d'abonnement, les preuves de paiement ou tout autre élément probant. Aucun reçu conforme à un modèle administratif ni attestation fiscale distincte n'est exigé. Une information déjà légalement et effectivement disponible n'est pas demandée une seconde fois.

IV. – Le crédit est repris au titre de l'année au cours de laquelle une condition maintenue du présent article cesse d'être respectée. Pour les versements effectués jusqu'au 31 décembre 2022, la fin de l'abonnement avant douze mois entraîne également une reprise au titre de l'année de cet événement. Pour les versements effectués à compter de l'entrée en vigueur de la présente réforme, la seule fin de l'abonnement ne justifie pas de reprise, sans préjudice de la rectification du crédit en cas de remboursement des dépenses qui en constituent la base.

La réouverture du crédit et la suppression de la durée minimale s'appliquent exclusivement aux versements effectués à compter de l'entrée en vigueur de la présente réforme. Les versements effectués après le 31 décembre 2022 et avant cette entrée en vigueur ne deviennent pas éligibles. La simplification des preuves s'applique aux demandes et contrôles postérieurs à cette entrée en vigueur, y compris pour les versements antérieurs éligibles. Les droits à restitution, prescriptions et recours antérieurs sont conservés, sans réouverture des délais expirés.
''',
"Réécriture intégrale avec réouverture prospective explicite du crédit existant, sans nouvelle échéance ni nouveau taux, et suppression pour ce nouveau champ de l'engagement minimal de douze mois. Suppression du reçu fiscal à modèle imposé. Les caractéristiques de la presse éligible, la condition de revenu, le taux de 30 %, l'unicité par foyer et la restitution sont conservés.",
"La source ferme les versements au 31 décembre 2022 : la réouverture constitue une réforme de fond assumée au titre de l'allègement des conditions d'accès, et non une description du droit actuel. Aucun versement de l'intervalle fermé n'est rétroactivement admis. Les douze mois et reprises anciens restent applicables aux versements antérieurs. Coordonner le formulaire et les dispositions d'application du reçu, sans créer de déclaration de remplacement ; documenter séparément le coût public sans rendement ou financement inventé.",
"Le crédit de 30 % du premier abonnement, son caractère restituable, la limite de revenu de 24 000 € par part majorée de 25 % par demi-part et son exclusion des revenus déjà déduits sont maintenus. La réouverture vise les premiers abonnements futurs, sans deuxième avantage pour un foyer déjà bénéficiaire et sans fermer les créances anciennes. La durée de douze mois est retirée uniquement du nouveau champ ; les preuves ordinaires remplacent l'exclusivité du reçu administratif, sans priver un ancien reçu de valeur probante.",
[
"Suppression pour les nouveaux versements de la clôture définitive du crédit au 31 décembre 2022, avec réouverture seulement à l'entrée en vigueur de la réforme.",
"Suppression de la durée minimale d'abonnement de douze mois et de la reprise pour simple résiliation dans le nouveau champ.",
"Suppression du reçu fiscal obligatoirement conforme à un modèle administratif comme moyen exclusif de preuve."
])

put('200-0 A', '''
Le présent article est abrogé pour l'imposition des revenus de l'année au cours de laquelle la présente réforme entre en vigueur et des années suivantes. Les plafonnements globaux de 10 000 € et de 18 000 € et les calculs de fractions destinés à leur application cessent de limiter les avantages fiscaux, y compris leurs reports imputables au titre de ces années.

Les exonérations, déductions, amortissements, réductions et crédits d'impôt restent applicables selon les conditions, limites propres, règles de cumul, d'imputation, de report et de restitution de chaque dispositif. La présente abrogation ne supprime aucun de ces avantages et n'institue ni remboursement ni report supplémentaire. Elle ne modifie pas les limites issues du droit de l'Union européenne.

Les impositions relatives aux revenus des années antérieures, leurs dégrèvements, restitutions, prescriptions et recours restent régis par les dispositions applicables à ces années. Aucun remboursement rétroactif général ni réouverture d'un délai de réclamation expiré ne résulte de la présente abrogation.
''',
"Abrogation prospective réelle de la limitation transversale des avantages fiscaux, et non suppression des dispositifs qui en étaient exclus. Les calculs à 34 %, 44 % et 30 % destinés exclusivement au plafond global disparaissent dans son nouveau champ ; les plafonds et conditions propres à chaque avantage subsistent.",
"Coordonner les renvois à 200-0 A dans les annexes et les instructions de liquidation pour qu'aucun formulaire ne maintienne un plafond global futur. Conserver les règles des années antérieures et les règles propres d'aides d'État et de non-cumul. Les six cibles requises ont été lues en droit en vigueur et en proposition ; cette dernière n'est pas le droit actuel. Aucun nouveau taux d'IR ni rendement de cette suppression n'est posé.",
"L'abrogation retire une limitation de l'IR, sans abroger les dispositifs favorables. Elle préserve chacun des avantages dont le 2 b) excluait déjà le plafonnement : 199 quater C (cotisations syndicales), 199 quater F, 199 septies, 199 terdecies-0 A bis, 199 terdecies-0 A ter, 199 terdecies-0 B (intérêts de reprise), 199 quindecies, 199 octodecies, 199 tervicies (restauration immobilière), 199 tervicies A, 200, 200 bis, 200 quater A, 200 decies A, 200 undecies (remplacement agricole), 238 bis et les 2 à 4 du I de 197. Chacun conserve ses conditions, imputations, éventuelles restitutions et reports propres ; aucune exclusion ne devient un nouveau plafonnement. La même préservation vaut pour tous les crédits du 1° du II de la section 5 du chapitre Ier du titre et pour le crédit d'impôt étranger ou la décote conventionnelle en tenant lieu. Les déductions des h et l du 1° du I de 31 et de 31 bis, auparavant comprises dans le calcul, ne sont plus globalement plafonnées. Les réductions de 199 undecies A, B, C, de 199 unvicies et du XII de 199 novovicies ne sont plus bornées par les 18 000 € ; leurs taux et limites propres sont conservés. Les fractions favorables de prise en compte à 34 % ou 44 % pour 199 undecies B et 30 % pour 199 undecies C restent applicables aux anciennes années ; elles deviennent sans objet pour les années sans plafond global, sans réduction de l'avantage brut. Les montants acquis une année antérieure et reportés bénéficient de l'absence de plafond global dans l'année nouvelle d'imputation, sous réserve de leurs règles de report. Tous ces avantages restent ouverts aux opérations futures recevables dans leur calendrier propre ; aucune date historique d'éligibilité n'est prolongée et aucun remboursement ou report nouveau n'est créé.",
repeal="Suppression des plafonds globaux annuels de 10 000 € et 18 000 €, de leurs assiettes transversales, calculs de fractions et formalités exclusivement nécessaires à leur liquidation pour les années nouvelles.")

put('200 A', '''
1. Pour les personnes physiques fiscalement domiciliées en France au sens de l'article 4 B, l'impôt sur le revenu dû au titre des revenus, gains nets, profits, distributions, plus-values et créances énumérés aux 1° et 2° du A est calculé en appliquant à leur assiette imposable le taux forfaitaire prévu au B.

A. – L'imposition forfaitaire s'applique :

1° Aux revenus de capitaux mobiliers mentionnés au VII de la première sous-section de la section II du présent chapitre. Sont exclus les revenus expressément exonérés en vertu des articles 125-0 A, 155 B, 157 et 163 quinquies B à 163 quinquies C bis, les produits des bons ou contrats de capitalisation ou placements de même nature mentionnés au 6° de l'article 120 et au 1° du I de l'article 125-0 A attachés à des primes versées jusqu'au 26 septembre 2017, ainsi que les revenus retenus pour déterminer le bénéfice imposable d'une entreprise industrielle, commerciale, artisanale ou agricole ou d'une profession non commerciale. L'imposition forfaitaire s'applique aussi aux produits du 5 de l'article 13 qui relèvent des revenus de capitaux mobiliers.

Pour calculer l'impôt, les revenus du premier alinéa du présent 1° sont retenus pour leur montant brut, sous réserve des articles 124 C, 125-00 A et 125-0 A, lorsqu'ils sont applicables.

Les revenus de source étrangère mentionnés au même premier alinéa sont également retenus pour leur montant brut. L'impôt retenu à la source s'impute sur l'imposition forfaitaire dans la limite du crédit d'impôt qu'il ouvre, selon les conventions internationales.

Pour les deuxième et troisième alinéas du présent 1°, aucune multiplication par 1,25 du montant brut des revenus de la nature de ceux mentionnés au 2° du 7 de l'article 158 n'est appliquée ;

2° Aux gains nets, profits, distributions, plus-values et créances des 1° à 6° du 6 bis de l'article 158, déterminés selon ces dispositions. Les abattements des 1 ter et 1 quater de l'article 150-0 D ne s'appliquent toutefois pas pour établir l'imposition forfaitaire du premier alinéa du présent 1.

B. – 1° Le taux forfaitaire du premier alinéa du présent 1 est de 12,8 % ;

2° Par dérogation au 1° du présent B, lorsque les conditions du b du 2 du II de l'article 125-0 A sont remplies, le taux prévu à ce b s'applique aux produits des bons ou contrats de capitalisation et placements de même nature mentionnés au I de l'article 125-0 A et au II de l'article 125 D, attachés à des primes versées à compter du 27 septembre 2017 :

a) À la totalité de ces produits lorsque le montant des primes versées sur le bon, contrat ou placement concerné et sur les autres bons, contrats ou placements détenus par leur bénéficiaire, qui n'ont pas déjà fait l'objet d'un remboursement en capital au 31 décembre de l'année précédant le fait générateur d'imposition des produits, ne dépasse pas 150 000 €. Si la propriété d'un bon ou contrat est démembrée, les primes versées sur celui-ci ne sont retenues que pour le seuil applicable à l'usufruitier ;

b) Lorsque le montant des primes déterminé au a dépasse 150 000 €, à la seule fraction des produits calculée en multipliant leur montant total par le rapport suivant :

– Au numérateur, 150 000 €, diminués, le cas échéant, des primes versées avant le 27 septembre 2017 qui n'ont pas déjà fait l'objet d'un remboursement en capital au 31 décembre de l'année précédant le fait générateur d'imposition des produits ;

– Au dénominateur, les primes versées à compter du 27 septembre 2017 qui n'ont pas déjà fait l'objet d'un remboursement en capital au 31 décembre de l'année précédant le fait générateur d'imposition des produits.

La fraction des produits du premier alinéa du présent 2° qui ne bénéficie pas du taux prévu à cet alinéa est imposée au taux du 1° du présent B ;

3° Si les conditions du b du 2 du II de l'article 125-0 A ne sont pas remplies, les produits du 2° du présent B attachés à des primes versées à compter du 27 septembre 2017 sont imposés au taux du 1° du présent B.

2. Par dérogation au 1, le contribuable peut opter expressément pour inclure l'ensemble des revenus, gains nets, profits, plus-values et créances de ce 1 dans l'assiette du revenu net global défini à l'article 158. L'option reste globale pour l'année concernée. Elle peut être exercée dans la déclaration prévue à l'article 170 ou dans une déclaration rectificative ou une réclamation présentée dans le délai de réclamation applicable à cette imposition. Elle peut être retirée dans ce même délai, pour l'ensemble de ces revenus et gains de l'année. Aucun choix distinct par revenu, gain ou établissement payeur n'est admis.

2 bis. – Abrogé.

2 ter. – a. Les plus-values mentionnées au I de l'article 150-0 B ter sont soumises à l'impôt sur le revenu au taux déterminé comme suit :

1° Pour les apports réalisés du 14 novembre au 31 décembre 2012, le taux est déterminé selon le A du IV de l'article 10 de la loi n° 2012-1509 du 29 décembre 2012 de finances pour 2013 ;

2° Pour les apports réalisés du 1er janvier 2013 au 31 décembre 2017, le taux est le rapport entre :

– Au numérateur, la différence entre, d'une part, l'impôt qui aurait résulté, pour l'année de l'apport, de l'application de l'article 197 à la somme de toutes les plus-values mentionnées au premier alinéa du présent 2° réalisées cette année et des revenus imposés cette même année selon l'article 197 et, d'autre part, l'impôt dû pour cette même année selon cet article ;

– Au dénominateur, l'ensemble des plus-values du premier alinéa du présent 2° retenues au deuxième alinéa de ce 2°.

Pour calculer ce taux, les plus-values sont, le cas échéant, diminuées du seul abattement du 1 de l'article 150-0 D dans sa rédaction en vigueur jusqu'au 31 décembre 2017 ;

3° Pour les apports réalisés à compter du 1er janvier 2018, le taux est de 12,8 %. Si le contribuable exerce l'option globale du 2, le taux est toutefois déterminé selon les modalités du 2° du présent a, en tenant compte, le cas échéant, du seul abattement des 1 ter ou 1 quater de l'article 150-0 D.

Les plus-values du premier alinéa du présent a auxquelles l'article 244 bis B s'applique sont imposées selon les conditions et le taux de cet article dans sa rédaction applicable à la date de l'apport.

b. Les plus-values du premier alinéa du a du présent 2 ter, retenues avant l'abattement mentionné aux 2° ou 3° de ce a, sont également soumises, le cas échéant, à la contribution de l'article 223 sexies. Le taux de cette contribution est le rapport entre les deux termes suivants :

1° Au numérateur, la différence entre, d'une part, la contribution qui aurait résulté, pour l'année de l'apport, de l'application de l'article 223 sexies au revenu fiscal de référence défini par ce même article, augmenté de toutes les plus-values du premier alinéa du présent b réalisées la même année et, d'autre part, la contribution due, le cas échéant, selon cet article 223 sexies ;

2° Au dénominateur, l'ensemble des plus-values du premier alinéa du présent b retenues au 1° du présent b.

3. L'avantage salarial du I de l'article 80 quaterdecies entre dans l'assiette du revenu net global défini à l'article 158 après un abattement de 50 % ou, le cas échéant, après l'abattement fixe du 1 du I de l'article 150-0 D ter puis, pour le surplus, l'abattement de 50 %. L'abattement fixe s'applique en priorité au gain net du V de l'article 80 quaterdecies et, pour son éventuel surplus, à l'avantage salarial précité.

4. – Abrogé.

5. Le gain net du 2 du II de l'article 150-0 A est imposé dans les conditions du 1 ou du 2 du présent article.

6. – Abrogé.

6 bis. – Abrogé.

7. – Abrogé.

La suppression de la multiplication par 1,25 s'applique aux revenus dont le fait générateur d'imposition intervient à compter de l'entrée en vigueur de la présente réforme. L'assouplissement de l'option du 2 s'applique aux options, retraits et réclamations présentés à compter de cette date pour des impositions dont le délai de réclamation n'est pas expiré. Il ne rouvre aucun délai expiré et ne remet pas en cause les décisions juridictionnelles irrévocables. Les autres créances, restitutions, prescriptions et recours relatifs aux périodes antérieures demeurent régis par leurs règles applicables.
''',
"Réécriture complète des assiettes, taux et formules, y compris les trois générations d'apports. Réforme de fond : retrait de la majoration d'assiette de 25 % et de la forclusion de l'option globale à la date limite déclarative ; possibilité de corriger ou retirer cette option dans le délai ordinaire de réclamation. Le PFU personnel, ses exclusions, taux favorables et abattements propres restent distincts de l'IS à la distribution.",
"Les taux 12,8 % et abattement de 50 %, le seuil de 150 000 €, les dates 26/27 septembre 2017 et 2012/2013/2018 ainsi que les numérateurs/dénominateurs sont conservés. La suppression de 1,25 ne supprime ni l'imposition du revenu réel ni les contrôles et sanctions de fraude. Coordonner la liquidation avec l'article 158 et les textes déclaratifs ; vérifier aussi le régime contentieux hors CGI dans le livre des procédures fiscales pour l'option et sa révocation, sans prétendre l'avoir réécrit. La contribution personnelle de 223 sexies n'est pas une contribution additionnelle d'IS et reste dans son champ. Le renvoi à 150-0 B ter vise un report personnel, non une taxation annuelle de la société ; ses délais propres de réinvestissement ne sont pas transposés aux bénéfices conservés soumis au nouvel IS. Aucun taux salarial de CSG n'est appliqué aux capitaux et aucun prélèvement sur capital dénoué par décès n'est créé.",
"Restent exclus du forfait les revenus exonérés par 125-0 A, 155 B, 157 et 163 quinquies B à C bis, les produits anciens visés et les revenus professionnels. Les règles favorables des articles 124 C, 125-00 A, 125-0 A, le crédit conventionnel d'impôt étranger, le taux spécial d'assurance-vie avec seuil de 150 000 € et attribution à l'usufruitier sont préservés. L'option globale au barème devient rectifiable ; les abattements historiques sur apports et les abattements salarial de 50 % et fixe restent applicables aux situations futures recevables et reports anciens, dans leurs champs respectifs. Le retrait de la majoration 1,25 réduit une assiette sans diminuer un avantage. La fiscalité personnelle subsiste indépendamment du report d'IS et du minimum international.",
[
"Suppression de la multiplication par 1,25 de certains revenus de capitaux mobiliers pour le calcul de l'imposition forfaitaire.",
"Suppression de la forclusion de l'option globale au barème à la date limite de déclaration et ouverture de sa rectification ou révocation dans le délai de réclamation."
])

put('200 B', '''
Les plus-values réalisées dans les conditions des articles 150 U à 150 UC sont imposées au taux forfaitaire de 19 %. Toutefois, les taux du III bis de l'article 244 bis A s'appliquent lorsque ces plus-values sont dues par des associés de sociétés ou groupements relevant des articles 8 à 8 ter ou par des porteurs de parts de fonds de placement immobilier mentionnés à l'article 239 nonies, et que ces associés ou porteurs ne sont pas fiscalement domiciliés en France ou ont leur siège social hors de France.
''',
"Réécriture à droit constant : identification explicite des associés et porteurs auxquels s'appliquent les taux du III bis de 244 bis A. Aucune formalité, autorisation ou contribution accessoire n'existe dans cet article à retirer ; maintien du taux personnel qui rend opératoire le régime général de plus-values immobilières et de son régime distinct de non-résidents.",
"Taux de 19 % conservé, sans addition ni taux intermédiaire. Le renvoi à 150 U maintient ses exonérations ; le 7° de son II comporte déjà une proposition de coordination supprimant le seul engagement lié aux quotas SRU. Le renvoi complémentaire à 150 UB/UC et celui à 244 bis A restent ceux de la source ; leurs textes ne figurent pas dans reference-targets.json et aucune nouvelle disposition n'en est inférée. Aucun droit sur une transmission par décès n'est établi : seules les cessions à titre onéreux sont ici concernées.")

put('200 C', '''
Les plus-values réalisées dans les conditions de l'article 150 VH bis sont imposées au taux forfaitaire de 12,8 %.

Par dérogation, le contribuable peut opter expressément pour inclure l'ensemble de ces plus-values de l'année dans l'assiette du revenu net global défini à l'article 158. L'option est exercée dans la déclaration prévue à l'article 170, dans une déclaration rectificative ou dans une réclamation présentée dans le délai de réclamation applicable à l'imposition. Le contribuable peut la retirer dans ce même délai pour l'ensemble des plus-values concernées. Aucun choix par cession n'est admis.

La suppression de l'irrévocabilité et de la date limite spéciale de l'option s'applique aux options, retraits et réclamations présentés à compter de l'entrée en vigueur de la présente réforme, pour les cessions réalisées à compter du 1er janvier 2023 dont l'imposition peut encore faire l'objet d'une réclamation. Les droits, restitutions, prescriptions et recours antérieurs sont conservés ; aucun délai expiré n'est rouvert et les décisions juridictionnelles irrévocables ne sont pas remises en cause.
''',
"Réécriture avec suppression effective de l'irrévocabilité de l'option et de sa forclusion à la date limite déclarative. Maintien du taux de 12,8 % et de l'option globale propre aux plus-values d'actifs numériques, distincte de celle de 200 A.",
"La date du 1er janvier 2023 provient de la note source et délimite les cessions concernées ; elle n'est pas une date de promulgation de la réforme. Coordonner les formulaires et, hors du lot, le droit contentieux du livre des procédures fiscales pour donner effet à la révocation. Aucun contenu nouveau n'est attribué à 150 VH bis ou 158, dont le renvoi existe déjà ; l'option ne devient pas un choix par opération.",
"L'option au revenu net global permet de bénéficier du barème lorsqu'il est plus favorable que le taux de 12,8 % : elle est maintenue pour toutes les plus-values annuelles éligibles et devient révocable dans le délai de réclamation. Les conditions et exclusions de l'assiette de 150 VH bis restent applicables ; aucun bénéfice ancien ni droit à restitution n'est supprimé. L'option reste autonome par rapport au PFU de 200 A et ne modifie pas les prélèvements sociaux par assimilation à la CSG salariale.",
[
"Suppression de l'irrévocabilité de l'option annuelle au revenu net global pour les plus-values d'actifs numériques.",
"Suppression de l'échéance impérative de l'option à la date limite de déclaration, avec exercice possible dans le délai ordinaire de réclamation."
])

put('201', '''
1. Lors de la cession ou de la cessation totale ou partielle d'une entreprise industrielle, commerciale, artisanale, minière ou agricole, les bénéfices réalisés qui n'ont pas encore été imposés sont compris dans l'assiette de l'impôt sur le revenu de l'année de la cession ou de la cessation. Pour une exploitation agricole relevant de l'article 64 bis, sont également comprises les créances acquises non encore recouvrées. L'impôt est établi et acquitté selon les règles de droit commun ; la cession ou la cessation ne donne pas lieu à une imposition immédiate distincte calculée au dernier taux d'acompte.

Aucun avis fiscal distinct de cession ou de cessation n'est exigé sur le fondement du présent article. L'administration réutilise les informations exactes et à jour qui lui ont déjà été légalement communiquées, notamment au titre des formalités de l'entreprise, dans le respect des secrets protégés. Les informations nécessaires à l'établissement de l'impôt qui manquent encore sont portées sur la déclaration de résultat ou de revenus déjà requise, sans déclaration de remplacement.

Les délais spéciaux de quarante-cinq jours et leurs points de départ propres à cet avis sont supprimés.

2. – Abrogé.

3. Les contribuables soumis à un régime réel déclarent leur bénéfice réel dans le délai de droit commun applicable à la déclaration annuelle de résultat. Aucun résumé distinct du compte de résultat n'est joint lorsque les documents comptables déjà déclarés ou légalement accessibles à l'administration contiennent les mêmes informations.

Le bénéfice réel est déterminé selon les articles 39 duodecies et suivants.

L'administration peut demander les justifications nécessaires à l'établissement de ce bénéfice qui ne lui sont pas déjà légalement et effectivement accessibles. Le contribuable dispose de trente jours à compter de la réception de cette demande pour les fournir. L'absence d'avis ou de dépôt spécial supprimé par le présent article ne peut entraîner une évaluation d'office. Les procédures de contrôle et d'imposition d'office prévues par le droit commun pour le défaut d'une déclaration maintenue ou de réponse à une demande régulière restent applicables avec leurs garanties.

3 bis. Les contribuables relevant des articles 50-0 et 64 bis qui cessent leur activité en cours d'année souscrivent la déclaration prévue, respectivement, au 3 de l'article 50-0 ou au III de l'article 64 bis, dans son délai annuel de droit commun. Aucune déclaration anticipée dans les soixante jours ni seconde déclaration des mêmes informations n'est exigée sur le fondement du présent article.

4. Le présent article s'applique aussi au décès de l'exploitant. Les ayants droit produisent les renseignements nécessaires à l'établissement de l'impôt sur les revenus professionnels du défunt dans le délai déclaratif de droit commun, qui ne peut expirer avant six mois à compter du décès. Ils ne fournissent pas de nouveau les informations déjà légalement et effectivement accessibles à l'administration. Ces obligations concernent l'impôt sur les revenus de l'exploitation et n'instituent aucun droit sur la transmission par décès.

Les nouvelles règles d'établissement de l'impôt et de déclaration s'appliquent aux cessions, cessations et décès survenant à compter de l'entrée en vigueur de la présente réforme. Pour les événements antérieurs, les impositions, imputations, restitutions, prescriptions et recours restent soumis à leurs règles antérieures ; les informations déjà régulièrement déclarées n'ont pas à être déclarées de nouveau. L'application des dispositions répressives plus douces aux sanctions non définitives demeure réservée.
''',
"Réforme de fond : suppression de l'imposition immédiate distincte au taux d'acompte, de l'avis fiscal à quarante-cinq jours et des déclarations anticipées à soixante jours. Réécriture de l'assiette à droit constant, y compris les créances micro-BA ; déclaration dans le circuit annuel existant et réemploi des comptes. Le délai protecteur de six mois au décès et le contrôle fiscal utile restent maintenus.",
"Coordonner 202 et 203 du présent lot, les procédures et le recouvrement hors CGI ainsi que les renvois réglementaires à l'avis de quarante-cinq jours ou au dépôt de soixante jours. Adapter les acomptes 204 A dans leur champ, sans supprimer l'impôt annuel ni prétendre que le taux d'acompte est le taux définitif. La déclaration annuelle 64 bis III reste directement portée sur 170 ; ne pas créer une liasse micro-BA. L'impôt sur les bénéfices du défunt n'est pas un prélèvement équivalent sur le capital transmis : l'assiette de revenus est préservée, sans droits de succession. La source ne prévoit pas ici un contrat de travail et ne peut porter le barème de rupture du contrat unique.",
removed=[
"Suppression de l'établissement immédiat d'une imposition distincte au dernier taux d'acompte à l'occasion d'une cession, cessation ou d'un décès nouveau.",
"Suppression de l'avis fiscal distinct sous quarante-cinq jours et de ses trois points de départ spéciaux, sans avis de remplacement.",
"Suppression du dépôt anticipé sous soixante jours pour les régimes réels et micro-BIC/BA et du résumé comptable redondant.",
"Suppression de l'évaluation d'office fondée sur la seule absence d'un avis ou d'un dépôt spécial désormais supprimé."
])

put('201 ter', '''
En cas de cession ou de cessation d'entreprise, les provisions prévues aux articles 39 bis à 39 bis B qui n'ont pas encore été employées sont comprises dans le bénéfice de l'année de la cession ou de la cessation, selon l'article 201. Elles ne donnent lieu à aucune imposition immédiate distincte.

Lorsque l'entreprise relève du régime d'impôt sur les sociétés à la distribution, cette prise en compte détermine le bénéfice fiscal de référence et ne rend pas, à elle seule, l'impôt ordinaire exigible sur des bénéfices conservés, y compris en trésorerie. Les faits générateurs propres à ce régime et aux régimes distincts demeurent applicables.

La suppression de l'imposition immédiate distincte s'applique aux cessions ou cessations survenant à compter de l'entrée en vigueur de la présente réforme. Les impositions, restitutions, prescriptions et recours afférents aux événements antérieurs restent soumis aux règles qui leur sont applicables.
''',
"Coordination de fond avec 201 : retrait de l'exigibilité immédiatement accélérée, tout en maintenant l'inclusion des seules provisions non utilisées dans le bénéfice de cessation. Clarification de la portée de calcul, sans rétablir l'IS annuel pour la presse relevant du régime à la distribution.",
"39 bis contient plusieurs régimes historiques et une provision spéciale pour indemnités de journalistes ou salariés de l'ancienne presse : aucune de ces déductions n'est supprimée. Le renvoi ne porte pas sur une indemnité ordinaire de nouveau contrat et ne lui impose aucun seuil d'un an. Les cibles 39 bis A et B ne sont pas fournies dans reference-targets.json ; leurs renvois préexistants sont conservés sans contenu inventé. Coordonner les renvois de cessation de l'IS et ses exceptions propres hors du lot ; l'absence de distribution ne suffit pas à effacer un fait générateur distinct légalement applicable.",
removed=["Suppression de l'imposition immédiate distincte des provisions de presse non encore utilisées lors des nouvelles cessions ou cessations, en coordination avec 201."])

put('202', '''
1. Lorsqu'un contribuable cesse d'exercer une profession non commerciale, les bénéfices tirés de cette profession qui n'ont pas encore été imposés, y compris les créances acquises non encore recouvrées, sont compris dans l'assiette de l'impôt sur le revenu de l'année de cessation. L'impôt est établi et acquitté dans les conditions de droit commun, sans imposition immédiate distincte au dernier taux retenu pour l'acompte du 2° du 2 de l'article 204 A.

Aucun avis fiscal distinct de cessation ni délai spécial de soixante jours pour cet avis n'est exigé sur le fondement du présent article. L'administration réutilise les informations exactes et à jour déjà légalement communiquées. Les seules informations nécessaires à l'établissement de l'impôt qui manquent ou doivent être rectifiées, notamment la date de cessation et, le cas échéant, les nom, prénoms et adresse du successeur, sont portées sur la déclaration de résultat ou de revenus déjà requise, sans déclaration de remplacement. Le réemploi respecte les secrets protégés.

La date de cessation est déterminée comme suit :

a. Pour une profession autre que l'exploitation d'une charge ou d'un office, il s'agit de la date de cessation effective ;

b. Pour une charge ou un office, il s'agit de la date de publication au Journal officiel de la nomination du nouveau titulaire ou de la date de cessation effective si elle est postérieure.

2. Le contribuable souscrit la déclaration prévue à l'article 97 ou au 2 de l'article 102 ter dans son délai annuel de droit commun, sans dépôt anticipé sous soixante jours ni dépôt en double des mêmes informations.

Le défaut de souscription de cette déclaration maintenue peut donner lieu à une imposition d'office dans les conditions et avec les garanties du droit commun. L'absence d'un avis ou d'un dépôt spécial supprimé par le présent article ne peut, à elle seule, justifier une telle imposition.

3. Les 1 et 2 s'appliquent aussi au décès du contribuable. Les ayants droit produisent les renseignements nécessaires à l'impôt sur les revenus professionnels du défunt dans le délai de droit commun, qui ne peut expirer avant six mois à compter du décès. Les renseignements déjà légalement et effectivement accessibles à l'administration ne sont pas fournis de nouveau. Ces dispositions ne créent aucun droit sur la transmission par décès.

4. Transféré sous l'article 1663 bis.

Le renvoi au 2 de l'article 102 ter s'applique à la détermination des résultats des années 1999 et suivantes.

Les nouvelles règles d'établissement de l'impôt et de déclaration s'appliquent aux cessations et décès survenant à compter de l'entrée en vigueur de la présente réforme. Les impositions et droits relatifs aux événements antérieurs, notamment les imputations, restitutions, prescriptions et recours, restent régis par leurs règles applicables. Aucun renseignement déjà régulièrement déclaré n'est déclaré de nouveau. L'application des dispositions répressives plus douces aux sanctions non définitives demeure réservée.
''',
"Réforme coordonnée à 201 : retrait de l'imposition immédiate au taux d'acompte, de l'avis de cessation distinct et du dépôt anticipé sous soixante jours. Réécriture conservant l'assiette, les dates de cessation propres aux offices et la déclaration ordinaire des régimes BNC, avec protection de six mois pour les ayants droit.",
"L'article 102 ter 2 exige une déclaration directe des recettes et plus/moins-values sur 170 : aucune déclaration de résultat supplémentaire n'est imposée au micro-BNC. L'article 97 reste la voie du régime contrôlé ; sa source n'est pas jointe aux cibles, mais le renvoi est préexistant. La note source concerne les revenus perçus ou réalisés depuis le 1er janvier 2019 et la mention historique les résultats depuis 1999 ; aucune de ces dates n'est celle de la réforme proposée. Coordonner les règlements, acomptes et procédures de cessation hors lot, ainsi que les renvois à 1663 bis. La créance acquise non encaissée n'est pas implicitement exonérée ; il s'agit d'IR professionnel et non de droits de succession.",
removed=[
"Suppression de l'imposition immédiate distincte au dernier taux d'acompte en cas de nouvelle cessation d'une profession non commerciale ou de décès.",
"Suppression de l'avis fiscal spécial de cessation sous soixante jours, sans communication distincte de remplacement.",
"Suppression du dépôt anticipé des déclarations BNC sous soixante jours et de l'imposition d'office fondée sur la seule absence des formalités supprimées."
])

put('202 ter', '''
I. – L'impôt sur le revenu est établi dans les conditions des articles 201 et 202 lorsque les sociétés ou organismes relevant du régime des sociétés de personnes défini aux articles 8 à 8 ter cessent totalement ou partiellement d'y être soumis ou changent leur activité réelle. Il en va de même lorsque les personnes morales mentionnées aux articles 238 ter, 239 quater A, 239 quater B, 239 quater C, 239 quater D, 239 septies et au I des articles 239 quater et 239 quinquies deviennent passibles de l'impôt sur les sociétés. Une modification du seul objet social, sans changement de l'activité réelle ni du régime fiscal, ne déclenche pas cette imposition.

En l'absence de création d'une personne morale nouvelle, les bénéfices en sursis, les plus-values latentes de l'actif social et les profits non encore imposés sur les stocks ne sont pas imposés à l'occasion du changement si leurs valeurs fiscales sont conservées et si leur imposition reste possible sous le nouveau régime. La seule adaptation des écritures à ce régime ne fait pas perdre cette dispense lorsqu'elle ne modifie pas ces valeurs fiscales ni la possibilité d'imposition ultérieure.

II. – Lorsqu'une société ou un organisme dont les revenus ne sont ni des bénéfices d'une entreprise industrielle, commerciale, artisanale ou minière, ni ceux d'une exploitation agricole ou d'une activité non commerciale, cesse totalement ou partiellement de relever d'un régime défini aux articles 8 à 8 ter, 238 ter, 239 quater A, 239 quater B, 239 quater C, 239 quater D, 239 septies ou au I des articles 239 quater et 239 quinquies, l'impôt sur le revenu est établi pour la période précédant immédiatement le changement. Il porte sur les revenus et plus-values non encore imposés à cette date, y compris les produits acquis non encore perçus et les plus-values latentes du patrimoine ou de l'actif social.

En l'absence de personne morale nouvelle, ces plus-values latentes ne sont toutefois pas imposées à l'occasion du changement si tous les éléments du patrimoine ou de l'actif sont inscrits au bilan d'ouverture de la première période ou du premier exercice d'assujettissement à l'impôt sur les sociétés. Ce bilan distingue leur valeur d'origine et les amortissements et provisions qui auraient été admis en déduction si la société ou l'organisme avait été soumis à cet impôt depuis sa création.

La société ou l'organisme souscrit les déclarations et documents qui demeurent légalement requis pour l'année concernée dans leurs délais de droit commun. Aucun dépôt supplémentaire de ces déclarations ou documents dans les soixante jours du changement de régime n'est exigé sur le fondement du présent article. Celui-ci ne crée pas de déclaration annuelle d'IS ordinaire sur les seuls bénéfices conservés.

III. – Les sociétés et organismes des I et II établissent le bilan d'ouverture de la première période ou du premier exercice auquel le changement de régime ou d'activité prend effet. Ce bilan est communiqué lors du premier dépôt de documents comptables déjà requis sous le régime nouveau, dans le délai de droit commun de ce dépôt, sans création d'une obligation annuelle d'IS sur les bénéfices conservés. Aucune production séparée dans les soixante jours n'est exigée. L'administration ne demande pas de nouveau un bilan ou une pièce exacte et à jour auquel elle a déjà légalement accès.

IV. – Un décret précise les modalités d'application du présent article, notamment afin qu'aucun produit ni charge ne soit omis ou pris en compte deux fois dans le revenu ou le bénéfice de la société ou de l'organisme.

Pour l'application des I et II, la possibilité d'imposer ultérieurement à la distribution, dans le régime d'impôt sur les sociétés qui la prévoit, satisfait à la condition de maintien d'une possibilité d'imposition. Aucune distribution n'est réputée résulter du seul changement de régime ou de l'inscription au bilan d'ouverture. Les bénéfices conservés, même en trésorerie, ne deviennent pas passibles d'un IS ordinaire annuel du seul fait du présent article. Les montants déjà compris dans une assiette imposée avant le changement sont identifiés dans la comptabilité existante afin de ne pas être soumis une seconde fois à cet IS lors de leur distribution. Les déficits, crédits, valeurs fiscales et reports suivent leurs règles propres, sans double utilisation ; la fiscalité personnelle des associés, le minimum international et les régimes distincts restent à leur champ.

La suppression du fait générateur lié au seul objet social et l'assouplissement relatif aux écritures s'appliquent aux changements intervenant à compter de l'entrée en vigueur de la présente réforme. La suppression des dépôts spéciaux et le réemploi des pièces s'appliquent aux formalités dont le délai n'est pas expiré à cette date et à celles afférentes aux changements ultérieurs ; aucun dépôt déjà effectué n'est à refaire. Les impositions, reports et dispenses relatifs aux périodes antérieures, leurs restitutions, prescriptions et recours restent protégés selon les règles applicables, sous réserve des dispositions répressives plus douces pour les sanctions non définitives.
''',
"Réécriture intégrale des quatre subdivisions. Réforme de fond : suppression de la cessation fiscale fondée sur le seul changement d'objet statutaire, du blocage absolu de toute adaptation comptable et des deux dépôts spéciaux à soixante jours. Les valeurs fiscales, bilans et possibilités d'imposition ultérieure restent contrôlables. Coordination expresse de l'IS à la distribution et de l'absence de double prise en compte des bénéfices déjà imposés.",
"Les dispenses des I et II ont des conditions différentes : maintien des valeurs et de la possibilité d'imposer au I, inscription de l'ensemble du patrimoine avec valeur d'origine et amortissements/provisions théoriques au II ; aucune fusion des deux n'est opérée. Coordonner, hors lot, CGI 206/209/219/221, les bilans d'ouverture et les réserves provenant d'un régime IR, sans créer de nouveau renvoi normatif à une cible absente. Aucun report estonien au titre du minimum international n'est présumé. L'imposition IR de clôture et l'absence d'IS sur les bénéfices conservés sont distinctes ; les reports ne sont pas annulés et une distribution réelle conserve son fait générateur propre. Les règles sur frais, salaires et délais du contrat unique sont sans application à ce changement de régime fiscal.",
removed=[
"Suppression du fait générateur de cessation fiscale tiré du seul changement de l'objet social sans changement d'activité réelle ou de régime fiscal.",
"Suppression de l'interdiction absolue de modifier les écritures comptables pour la dispense du I, sans abandon des valeurs fiscales ni de l'imposition ultérieure.",
"Suppression du dépôt spécial des déclarations et documents annuels dans les soixante jours au II.",
"Suppression du dépôt séparé du bilan d'ouverture dans les soixante jours au III et des productions répétées des mêmes pièces."
])

put('202 ter A', '''
Les plus-values ou moins-values visées au premier alinéa du II de l'article 202 ter qui sont comprises dans l'actif d'une société civile à objet strictement immobilier ne sont pas imposées lors de sa transformation en société de placement à prépondérance immobilière à capital variable lorsque ses parts sont détenues, en représentation de provisions mathématiques relatives aux engagements exprimés en unités de compte de contrats d'assurance sur la vie ou de capitalisation, par l'un des organismes suivants : une entreprise d'assurance ; un fonds de retraite professionnelle supplémentaire mentionné à l'article L. 381-1 du code des assurances ; une mutuelle ou union de retraite professionnelle supplémentaire mentionnée à l'article L. 214-1 du code de la mutualité ; ou une institution de retraite professionnelle supplémentaire mentionnée à l'article L. 942-1 du code de la sécurité sociale. Les plus-values ou moins-values de cession ultérieure de ces actifs sont calculées d'après leur valeur fiscale avant la transformation.

Ce régime s'applique aux transformations effectuées dans le délai de cinq ans à compter de la publication au Journal officiel de l'arrêté du ministre chargé de l'économie homologuant les dispositions du règlement général de l'Autorité des marchés financiers relatives aux organismes de placement collectif immobilier. Il s'applique également, sans nouvelle date limite, aux transformations répondant aux mêmes conditions effectuées à compter de l'entrée en vigueur de la présente réforme.

Cette extension ne modifie ni les valeurs fiscales ni les droits, impositions, restitutions, prescriptions et recours relatifs aux transformations antérieures. Elle ne rend pas éligible une transformation effectuée après l'expiration du délai historique de cinq ans et avant l'entrée en vigueur de la présente réforme. Aucun délai de réclamation expiré n'est rouvert.
''',
"Réécriture complète et extension prospective explicite de la neutralité fiscale aux transformations futures de même objet, par retrait de la fermeture historique de cinq ans pour le nouveau champ. Conservation exacte des organismes, de la représentation des unités de compte et du calcul des cessions à partir des valeurs fiscales antérieures.",
"Le délai de cinq ans de la source reste celui des transformations historiques : la publication de l'arrêté AMF n'est pas la date de la nouvelle réforme. Cette extension est une réforme de fond autorisée par la préservation et l'élargissement des allègements ; aucun coût public n'est chiffré. Les codes des assurances, de la mutualité et de la sécurité sociale sont visés pour définir les organismes, sans rapport avec le contrat de travail privé. Coordonner les règles des organismes de placement collectif immobilier et leur fiscalité propre hors du lot, sans supposer l'application à tous du nouvel IS ordinaire.",
removed=["Suppression, pour les transformations nouvelles répondant aux mêmes conditions, de la fermeture du régime de neutralité à l'expiration des cinq années suivant l'arrêté d'homologation."])

put('202 quater', '''
I. – Par dérogation à l'article 202, lorsqu'un contribuable relevant du 1 de cet article devient, pour exercer sa profession, associé d'une société mentionnée aux articles 8 et 8 ter ou d'une société d'exercice libéral mentionnée à l'article 40 de l'ordonnance n° 2023-77 du 8 février 2023 relative à l'exercice en société des professions libérales réglementées, le bénéfice imposable peut être déterminé sans les créances acquises au sens des 2 et 2 bis de l'article 38 et les dépenses engagées qui ne sont pas encore recouvrées ou payées à la date de cet événement, à condition qu'elles soient inscrites au bilan de la société. Aucune limitation aux trois mois précédant cet événement ne s'applique.

Ce régime s'applique, aux mêmes conditions, aux opérations du premier alinéa du I de l'article 151 octies A.

Par dérogation au I de l'article 202 ter, il s'applique aussi lorsqu'une société mentionnée aux articles 8 et 8 ter qui exerce une activité libérale cesse de relever de ce régime parce qu'elle opte pour celui des sociétés de capitaux dans les conditions du 1 de l'article 239.

II. – Lorsque le I s'applique, les créances et dettes concernées sont prises en compte pour déterminer le résultat de la société qui les recouvre ou les acquitte, au titre de l'exercice au cours duquel prend effet l'événement mentionné au I. Si son résultat est déterminé selon l'article 93, elles sont prises en compte au titre de l'année de leur encaissement ou de leur paiement. Un produit ou une charge déjà retenu pour déterminer un résultat imposable n'est pas retenu une seconde fois.

Pour une société relevant de l'impôt sur les sociétés à la distribution, ce rattachement détermine son résultat fiscal de référence sans rendre exigible, à lui seul, l'IS ordinaire sur des bénéfices conservés, y compris en trésorerie. Il ne modifie pas les faits générateurs du régime de distribution, la fiscalité personnelle des associés, le minimum international ni les régimes distincts.

III. – Les I et II s'appliquent sur option conjointe du contribuable mentionné au I et des sociétés mentionnées au II. L'option peut être exprimée dans les déclarations auxquelles ils sont déjà tenus, sans demande séparée ni attestation supplémentaire. Les informations nécessaires à la concordance des créances et dettes inscrites sont réutilisées lorsqu'elles sont déjà légalement et effectivement disponibles ; aucun état identique n'est déposé une seconde fois.

IV. – Abrogé.

La suppression de la limite de trois mois et les nouvelles règles de rattachement du II s'appliquent aux événements du I survenant à compter de l'entrée en vigueur de la présente réforme. Les simplifications de l'option s'appliquent aux formalités accomplies à compter de cette date, sans option antérieure à refaire. Les créances, dettes, options, reports, impositions, restitutions, prescriptions et recours relatifs aux événements antérieurs conservent leur régime, sans double prise en compte ni réouverture d'un délai expiré.
''',
"Réécriture des quatre subdivisions avec extension du mécanisme optionnel de neutralité à toutes les créances et dépenses non réglées transférées au bilan, sans limite d'ancienneté de trois mois. Suppression des supports d'option et états distincts redondants. Conservation de l'accord des deux parties et de la distinction entre comptabilité d'engagement et recettes/dépenses ; coordination explicite de l'exigibilité du nouvel IS.",
"L'article 38 2 et 2 bis définit la créance et son rattachement, non une obligation de paiement annuel d'IS ; sa proposition 12 le confirme. L'article 93 garde un rattachement BNC aux recettes/dépenses et ses déductions propres. Le rattachement du II est expressément réécrit pour retirer le point de départ devenu sans objet après suppression de la période de trois mois : exercice de l'événement pour l'engagement, année d'encaissement/paiement pour 93. Vérifier la concordance comptable d'ouverture et de clôture, sans produit ni charge oublié ou utilisé deux fois. 151 octies A, 239 et l'article 40 de l'ordonnance sont des renvois préexistants non fournis comme cibles ; aucun contenu nouveau n'en est inventé. La note source sur l'entrée en vigueur au 1er septembre 2024 demeure historique, sans dater la présente réforme. Les articles IS et les formulaires hors lot doivent suivre le fait générateur de distribution et préserver les déficits, crédits et réserves déjà taxées.",
"Le régime favorable conserve ses trois voies : passage du professionnel en société de personnes ou SEL, opérations de 151 octies A, et option d'une société libérale pour le régime des capitaux. Son bénéfice reste ouvert aux événements futurs et est élargi aux créances et dépenses plus anciennes que trois mois, avec inscription au bilan et option conjointe maintenues. Les créances et dettes restent prises en compte symétriquement, sans double emploi. Le rattachement de référence d'une société à l'IS ne rétablit pas l'impôt ordinaire sur ses bénéfices conservés et ne supprime aucun crédit ou déficit. Les anciennes options et les droits associés gardent leur régime.",
[
"Suppression de la limitation aux trois mois précédant le passage en société ou le changement de régime pour les créances et dépenses transférées bénéficiant de la neutralité.",
"Suppression du point de rattachement du résultat défini par le mois suivant cette ancienne période de trois mois, remplacé par l'exercice de l'événement pour la comptabilité d'engagement.",
"Suppression des demandes d'option conjointes sur support séparé et des doubles états de créances et dettes déjà disponibles, sans supprimer l'accord conjoint."
])

put('203', '''
Les impositions établies en application des articles 201 et 202 à l'occasion d'une cession, d'une cessation ou d'un décès s'imputent, le cas échéant, sur l'impôt sur le revenu calculé ultérieurement selon les articles 156 à 168. Cette imputation concerne l'impôt dû au titre de l'ensemble des bénéfices et revenus réalisés ou perçus pendant l'année de la cession, de la cessation ou du décès par les membres du foyer fiscal désignés aux 1 et 3 de l'article 6.

Cette imputation reste applicable aux impositions distinctes établies sous le régime antérieur à la suppression de leur établissement immédiat par les articles 201 et 202, même si l'imputation intervient après l'entrée en vigueur de cette suppression. Pour les événements soumis aux nouvelles règles de ces articles, aucune imposition distincte supplémentaire n'est créée par le présent article. Les droits à dégrèvement et restitution, prescriptions et recours restent régis par les règles qui leur sont applicables.
''',
"Réécriture à droit constant de la règle d'imputation évitant de payer deux fois l'IR des bénéfices de cessation, puis transition expresse coordonnée aux suppressions de 201 et 202. Aucun avantage d'imputation ancien n'est retiré du seul fait de la disparition des impositions distinctes pour l'avenir.",
"Correction rédactionnelle de la répétition source « ou de de décès », sans modification de champ. Le renvoi à 156 porte sur le revenu net annuel et ses déficits/charges, non sur la durée ou la rupture du contrat de travail ; les membres du foyer restent ceux des 1 et 3 de 6, sans extension aux personnes du 2. Les autres articles 157 à 168 ne sont pas fournis comme cibles ; leurs renvois restent préexistants, sans contenu inventé. Coordonner la liquidation et le recouvrement des anciennes impositions immédiates avec les changements de 201/202 et les délais de réclamation, sans prétendre supprimer l'IR professionnel au décès.")

assessments = {
    '200 quindecies': {
        'L1234-1': "La cible distingue le préavis des anciens contrats (ancienneté inférieure à six mois, six mois à deux ans, puis au moins deux ans) du préavis patronal de quinze jours calendaires des nouveaux contrats. Le VIII 1° proposé de 200 quindecies préserve la dispense fiscale même si le préavis est payé sans être exécuté ; il ne fixe aucun préavis et ne dispense d'aucune autorisation ou procédure collective. Le point de départ de notification de L1234-3 relève de la coordination travail, sans ajout d'un renvoi dont la cible n'est pas jointe.",
        'L1221-2': "La proposition cible impose la durée indéterminée aux nouveaux contrats privés et distingue la fin d'une mission ou formation de celle de l'emploi. La dispense de reprise de crédit est ouverte à leur rupture patronale future, y compris pendant l'essai, sans recréer de CDD ni traiter un terme de mission comme un licenciement. Les contrats anciens conservent leur transition et les autres causes favorables du VIII restent inchangées.",
        'L1234-9': "La cible proposée ouvre l'indemnité ordinaire après un an au terme effectif préavis inclus, à 0,20 mois par année totale et prorata des mois complets, plafond de six mois ; la source ouvre après huit mois hors faute grave. Aucun de ces seuils n'est une condition du VIII 1° fiscal : la dispense bénéficie aussi au salarié dont la rupture patronale n'ouvre pas d'indemnité ordinaire. Les indemnités spéciales et réparations restent distinctes et le préavis n'est pas une procédure collective complète."
    },
    '200-0 A': {
        '199 quater C': "Le crédit vise les cotisations syndicales représentatives de salariés et fonctionnaires ainsi que les associations de militaires, à 66 % dans la limite de 1 % du revenu retenu ; l'excédent est remboursé hors frais réels. Son exclusion favorable du plafond global n'est pas supprimée : le plafond est aboli pour tous les avantages futurs dans son champ. Les statuts de fonctionnaire et militaire ne sont pas convertis artificiellement en contrat privé.",
        '199 terdecies-0 B': "La cible conserve la réduction de 25 % des intérêts d'emprunts de reprise contractés jusqu'au 31 décembre 2011, plafonnés à 20 000/40 000 €, et ses dispenses de reprise. L'abrogation du plafond global ne ferme ni les intérêts futurs de ces emprunts ni l'exclusion antérieure ; elle ne rouvre pas leur période de souscription. La qualité de société à l'IS subsiste sous le régime à la distribution proposé, sans exigence d'impôt annuel effectivement payé.",
        '199 tervicies': "La réduction de restauration complète de 22/30 %, son plafond propre de 400 000 €, le report de trois ans et les dispenses pour invalidité, licenciement ou décès subsistent indépendamment du plafond global. La proposition cible étend la dispense aux ruptures patronales du contrat unique, sans condition d'ancienneté ni d'indemnité. La présente abrogation ne retire ni cette protection future ni les règles patrimoniales et de location maintenues.",
        '199 novovicies': "Le XII fixe les adaptations ultramarines, dont les taux de 23/29 % et leurs variantes 2023/2024 ; ce XII relevait du plafond global de 18 000 €. La suppression du plafond ne change ni ces taux, ni le bénéfice des opérations futures encore recevables au 5° du B du I jusqu'en 2027. Le XI B de la proposition étend la dispense de reprise au contrat unique sans indemnité ou préavis exécuté ; la neutralité du plafonnement reste indépendante de ces droits.",
        '200 undecies': "Le crédit de remplacement agricole garde ses taux 60 %, 80 % ou 50 %, plafonds de dix-sept ou douze jours, coût de quarante-deux minimums garantis et multiplication GAEC jusqu'à quatre associés. La cible proposée ouvre les remplacements futurs en contrat unique sans en limiter l'emploi aux jours aidés. L'abrogation de 200-0 A conserve son ancienne exclusion favorable et n'écarte pas les règles européennes de minimis.",
        '31': "Le 2 a) source vise les h et l du 1° du I : amortissement du h et déduction de 30 % du l, que la source qualifie globalement d'amortissement. Cette discordance de qualification est préexistante ; leur prise en compte au plafond est supprimée, sans suppression des déductions elles-mêmes ni extension implicite de leurs dates d'investissement. Les nouveaux i/j et les autres charges foncières gardent leur régime propre. Les dispenses liées au licenciement dans les régimes fonciers ne dépendent pas de l'indemnité ordinaire du contrat unique."
    },
    '200 A': {
        '150-0 B ter': "Le renvoi du 2 ter vise l'imposition personnelle à la fin du report d'apport, avec taux historiques 2012, 2013–2017 et 12,8 % depuis 2018. La cible distingue apport avec soulte jusqu'à 10 %, réinvestissement de 70 % sous trois ans, conservation et cas de donation ; ces règles ne deviennent pas des obligations de réinvestissement de tous les bénéfices d'une société au nouvel IS. L'option au barème reste globale et les dispenses du donataire ne sont subordonnées à aucun seuil d'indemnité ou préavis privé."
    },
    '200 B': {
        '150 U': "150 U soumet les cessions immobilières à titre onéreux à l'IR sous réserve de ses exonérations : résidence principale, certains remploi et non-résidents, seuil de 15 000 €, opérations sociales et partages notamment successoraux. 200 B ne modifie que la présentation du taux et ne taxe pas les biens exonérés. La proposition cible retire le seul quota SRU supplémentaire du II 7° ; ses autres exonérations et la dispense d'amende du II 9° restent autonomes. La coordination de cette dispense avec les ruptures patronales futures du contrat unique reste à expliciter dans la cible, sans condition d'un an ni assimilation de régimes publics."
    },
    '201': {
        '64 bis': "Le renvoi concerne le micro-BA, non un contrat de travail : moyenne des recettes sur trois ans, abattement de 87 % avec minimum de 305 €, déclaration directe au III et règles propres de plus-values. La nouvelle rédaction de 201 maintient l'inclusion des créances acquises non recouvrées à la cessation et retire seulement l'imposition distincte accélérée et le dépôt anticipé. Le circuit annuel du III de 64 bis reste utilisé sans liasse réelle nouvelle ni atteinte à ses exclusions et corrections évitant de taxer deux fois une créance."
    },
    '201 ter': {
        '39 bis': "Le renvoi couvre les provisions de presse historiques 1951–1996 et, au 2, celles destinées aux indemnités de journalistes ou salariés ayant perdu leur ancien emploi après les suspensions de 1944. Ce 2 maintient l'ancienneté de l'ancienne entreprise et n'est pas un barème de rupture des nouveaux contrats. 201 ter conserve le sort des provisions non employées lors de la cessation, mais supprime l'impôt distinct immédiatement accéléré ; il ne réduit aucune déduction ni n'impose le seuil d'un an du contrat unique à ces situations spéciales."
    },
    '202': {
        '102 ter': "Le 2 de 102 ter prévoit l'inscription des recettes et plus/moins-values sur la déclaration de 170 ; la cible fixe un seuil de 83 600 €, un abattement de 34 % et minimum de 305 €. Le renvoi de 202 2 reste celui de la déclaration micro-BNC, dont le dépôt anticipé sous soixante jours est supprimé sans imposer la déclaration contrôlée. Les règles sur recettes déjà comptées après sortie de 93 A demeurent et ne concernent ni notification de rupture ni ancienneté du contrat privé."
    },
    '202 quater': {
        '38': "Les 2 et 2 bis de 38 définissent l'actif net et le rattachement des créances de clientèle à la livraison, à l'achèvement ou à l'exécution de prestations particulières ; ils ne définissent pas une durée d'emploi. La limite de trois mois propre à 202 quater est supprimée sans modifier cette qualification de créance. La cible proposée 12 distingue résultat de référence et exigibilité de l'IS à la distribution : le II proposé de 202 quater suit cette distinction, avec continuité des valeurs et absence de double prise en compte.",
        '93': "Le renvoi du II vise le bénéfice BNC en recettes moins dépenses ; les créances et dettes transférées ne sont alors prises en compte qu'à l'encaissement ou au paiement, à la différence de l'exercice de l'événement en comptabilité d'engagement. Les déductions, options des auteurs et agents, et le régime spécial des fonctionnaires apportant leur concours scientifique sont conservés à leur champ : aucune règle de contrat unique ou d'ancienneté privée ne leur est attribuée par ce renvoi."
    },
    '203': {
        '156': "156 fixe le revenu net annuel du foyer, ses imputations de déficits et charges, notamment le I 3° foncier avec dispense de reconstitution en cas de licenciement, invalidité ou décès. 203 vise ce calcul global pour imputer les anciennes impositions de cessation, sans modifier les plafonds et reports de 156. L'emploi du mot contrat de travail au I 1° bis décrit une gestion confiée à un tiers et n'importe pas le barème de rupture. L'actualisation future de la dispense foncière pour les ruptures patronales du contrat unique doit être coordonnée dans 156, sans condition d'un an ou d'indemnité."
    }
}

answer = []
for src in sources:
    number = src['number']
    item = {key: src[key] for key in ('code_id', 'source_id', 'source_sha256', 'number')}
    item.update(drafts[number])
    item['status'] = 'rewrite_draft'
    required = references['requirements'].get(src['code_id']+'|'+src['source_id'], [])
    if required:
        item['reference_checks'] = []
        for key in required:
            target = references['targets'][key]
            item['reference_checks'].append({
                'target_key': key,
                'view_sha256': target['view_sha256'],
                'assessment': assessments[number][target['number']]
            })
    answer.append(item)

Path('answer.json').write_text(json.dumps(answer, ensure_ascii=False, indent=2)+'\n')
