import json
from pathlib import Path


drafts = {}


def add(number, xml, reason, notes):
    drafts[number] = {
        "proposed_xml": xml.strip(),
        "reason": reason,
        "review_notes": notes,
    }


add(
    "39-0 A bis",
    """
<p>La personne tenue de souscrire la déclaration prévue à l'article 87-0 A bis du code général des impôts y indique les éléments suivants :</p>
<p>1° Pour son identification :</p>
<p>a) Les numéros d'identification mentionnés à l'article R. 123-221 du code de commerce ;</p>
<p>b) Le code mentionné au 1° de l'article R. 123-223 du même code ;</p>
<p>2° Pour chaque bénéficiaire de revenu :</p>
<p>a) Les éléments d'identification mentionnés aux a, b, c et g du 3° du V de l'article R. 133-14 du code de la sécurité sociale et, le cas échéant, au e de ce même 3° ;</p>
<p>b) La dernière adresse connue de son domicile ;</p>
<p>c) Les dates de début et de fin de la période d'emploi du salarié ;</p>
<p>d) Le montant net annuel imposable à l'impôt sur le revenu ;</p>
<p>e) Le montant du prélèvement à la source, renseigné à 0 € ;</p>
<p>f) La date de versement du montant net imposable annuel.</p>
""",
    "Réécriture à droit constant : le déclarant est expressément désigné comme le sujet de l'obligation et les rubriques d'identification sont rattachées plus directement à la personne concernée. Les onze alinéas et toutes les rubriques sont conservés. Aucune réforme de taux ni extension de la retenue à la source n'est introduite.",
    "Le renvoi à l'article 87-0 A bis du CGI a été vérifié dans le corpus : il concerne une déclaration annuelle distincte de la déclaration mensuelle de l'article 87-0 A. La valeur de 0 € au e est conservée ; elle ne constitue pas un taux fiscal nul. L'identifiant du e du 3° du V de l'article R. 133-14 reste soumis à la condition « le cas échéant ». Aucune date nouvelle n'est ajoutée.",
)

add(
    "39 A",
    """
<p>Le déclarant porte les indications suivantes sur la déclaration prévue à l'article 88 du code général des impôts :</p>
<p>1° Pour son identification : ses nom et prénoms ou sa raison sociale, son adresse et, s'il s'agit d'une entreprise, son numéro SIRET ;</p>
<p>2° Pour chaque bénéficiaire d'une pension ou d'une rente viagère payée au cours de l'année précédente :</p>
<p>a) Ses éléments d'identification : nom de famille, le cas échéant nom de l'époux, prénoms, sexe, date et lieu de naissance et numéro d'allocataire. Le numéro d'inscription au répertoire national d'identification des personnes physiques est indiqué uniquement dans les déclarations des personnes ou organismes mentionnés au I de l'article R. 81 A-1 du livre des procédures fiscales ;</p>
<p>b) L'adresse de son domicile au 31 décembre de l'année du revenu ;</p>
<p>c) La nature des sommes versées et, si l'année normale d'échéance diffère de l'année du paiement, cette année normale d'échéance ;</p>
<p>d) Le montant versé, après déduction des cotisations aux assurances sociales. Pour les contribuables pensionnés au 31 décembre 1986 dont la pension a fait l'objet d'un premier versement mensuel en 1987, ce montant est remplacé par le montant des arrérages défini au e du 5 de l'article 158 du code général des impôts, sous réserve du 1 de l'article 204 du même code ;</p>
<p>e) Le montant de la retenue effectuée au titre de l'impôt sur le revenu en application de l'article 182 A du code général des impôts ;</p>
<p>f) Le cas échéant, la date du décès ;</p>
<p>3° Le total, pour l'ensemble des allocataires, des sommes mentionnées au 2°.</p>
""",
    "Réécriture à droit constant : les obligations du déclarant sont formulées directement et les deux restrictions longues relatives à l'identification et aux pensions anciennes sont réparties en phrases au sein de leurs alinéas d'origine. Toutes les rubriques et la totalisation sont maintenues. La réforme des retraites ne modifie pas cette déclaration de pensions et de rentes.",
    "Maintien de la restriction du numéro d'inscription au répertoire aux seuls déclarants visés par le LPF, de l'adresse au 31 décembre et du régime des pensionnés au 31 décembre 1986 avec premier versement mensuel en 1987. Les renvois aux articles 158, 182 A et 204 du CGI sont conservés. Le gel proposé d'une fraction des pensions ne s'applique pas aux obligations déclaratives ni aux rentes viagères par ce seul article.",
)

add(
    "39 B",
    """
<p>Les déclarants souscrivent les déclarations suivantes auprès de la direction départementale ou, le cas échéant, régionale des finances publiques du lieu du domicile de la personne ou du siège de l'établissement ou du bureau qui a assuré le paiement :</p>
<p>1° La déclaration prévue à l'article 87 du code général des impôts, lorsqu'elle porte sur des traitements, émoluments, salaires ou rétributions versés à des personnes qui ne relèvent pas du champ d'application de l'article L. 133-5-3 du code de la sécurité sociale ;</p>
<p>2° La déclaration prévue à l'article 88 du code général des impôts ;</p>
<p>3° La déclaration des indemnités journalières ou des allocations d'assurance et de solidarité mentionnées aux articles 80 quinquies ou 231 bis D du code général des impôts.</p>
<p>Les déclarants peuvent souscrire ces déclarations en communiquant un support informatique ou en envoyant des formulaires normalisés. L'administration en fixe les caractéristiques et le modèle.</p>
""",
    "Réécriture à droit constant : la règle de compétence territoriale a désormais un sujet explicite et les modalités de dépôt sont énoncées en deux phrases. Les trois catégories de déclarations, l'exclusion liée à l'article L. 133-5-3 et les deux supports sont conservés. Aucune nouvelle obligation dématérialisée n'est créée.",
    "La note source fixe l'application aux revenus perçus ou réalisés à compter du 1er janvier 2019, sur le fondement de l'article 6 du décret n° 2017-866 du 9 mai 2017 modifié par l'article 2 du décret n° 2017-1676 du 7 décembre 2017. Cette borne historique est conservée comme contexte d'application et ne sert pas de date à une réforme future. La compétence liée au payeur reste distincte de celle de l'article 39 F.",
)

add(
    "39 C",
    """
<p>La déclaration prévue à l'article 87-0 A du code général des impôts indique les éléments suivants :</p>
<p>1° Pour la personne tenue d'effectuer la retenue à la source :</p>
<p>a) Les numéros d'identification mentionnés à l'article R. 123-221 du code de commerce ;</p>
<p>b) Le numéro de la nomenclature d'activités française mentionné au 1° de l'article R. 123-223 du même code ;</p>
<p>2° Pour l'émetteur de la déclaration, s'il est distinct de la personne mentionnée à l'article 87-0 A du code général des impôts : son nom ou sa raison sociale et les numéros d'identification mentionnés à l'article R. 123-221 du code de commerce ;</p>
<p>3° Pour chaque bénéficiaire de revenu :</p>
<p>a) Les éléments d'identification mentionnés aux a, b, c, e et g du 3° du V de l'article R. 133-14 du code de la sécurité sociale ;</p>
<p>b) La dernière adresse connue de son domicile ;</p>
<p>c) La date du versement des sommes imposables ou de l'octroi des avantages imposables ;</p>
<p>d) Le montant net imposable à l'impôt sur le revenu des sommes et avantages mentionnés au c, calculé dans les conditions prévues à l'article 204 F du code général des impôts ;</p>
<p>e) Le taux de prélèvement à la source appliqué ;</p>
<p>f) Le montant du prélèvement à la source, arrondi à la deuxième décimale la plus proche ; la fraction de décimale égale à 0,005 est comptée pour 0,01 ;</p>
<p>g) L'identifiant du taux de prélèvement à la source mentionné au b du 2° de l'article 46 F ;</p>
<p>h) Le cas échéant, la date de fin de la relation contractuelle avec la personne mentionnée au 1° ;</p>
<p>4° Pour le télérèglement :</p>
<p>a) Les dates de début et de fin de la période au titre de laquelle la déclaration est déposée ;</p>
<p>b) Le numéro de compte bancaire international (IBAN) et le code d'identification des banques (BIC) du compte utilisé pour le versement ;</p>
<p>c) Le montant global du versement ;</p>
<p>d) Le numéro d'identification de l'établissement qui effectue le versement, mentionné au second alinéa de l'article R. 123-221 du code de commerce, s'il diffère du numéro d'identification mentionné au a du 1°.</p>
""",
    "Réécriture à droit constant : les rubriques du bénéficiaire et du télérèglement sont formulées plus directement, sans changement de leur ordre ni des données requises. La règle d'arrondi, la distinction entre émetteur et redevable et les conditions particulières sont intégralement conservées. Aucun taux nouveau n'est introduit.",
    "Incohérence préexistante conservée au g du 3° : dans le corpus fourni, le b du 2° de l'article 46 F désigne le taux applicable, tandis que son 1° désigne un identifiant du compte rendu ; il ne désigne pas expressément l'identifiant du taux. Vérifier conjointement les deux articles avant toute correction de ce renvoi. L'arrondi de 0,005 à 0,01, les références au second alinéa de R. 123-221 et au V de R. 133-14 sont maintenus. La note source relative au décret n° 2022-1014 du 19 juillet 2022 est historique et n'établit aucune entrée en vigueur de la réforme proposée. Le réemploi prévu au III de l'article 39 D proposé ne supprime aucune rubrique.",
)

add(
    "39 D",
    """
<p>I. – La déclaration prévue à l'article 87-0 A du code général des impôts est transmise au cours du mois qui suit celui du versement des sommes ou de l'octroi des avantages, aux échéances suivantes :</p>
<p>1° Pour les personnes qui relèvent du champ de l'article L. 133-5-3 du code de la sécurité sociale, aux dates résultant des I et II de l'article R. 133-14 du même code ;</p>
<p>2° Pour les personnes qui ne relèvent pas du champ de l'article L. 133-5-3 du code de la sécurité sociale, au plus tard à la date fixée par l'arrêté prévu au 2° de l'article 87 A du code général des impôts.</p>
<p>II. 1. – Les personnes qui relèvent du champ de l'article L. 133-5-3 du code de la sécurité sociale doivent déposer une déclaration tant qu'elles n'ont pas demandé la radiation de leur compte auprès de l'organisme de recouvrement des cotisations de sécurité sociale dont elles relèvent. Cette obligation s'applique même lorsqu'elles n'ont versé aucune somme ni accordé aucun avantage.</p>
<p>2. Les personnes qui ne relèvent pas du champ de l'article L. 133-5-3 du code de la sécurité sociale doivent déposer une déclaration tant qu'elles n'ont pas informé l'administration fiscale d'une radiation, d'une cessation d'activité ou de tout autre événement mettant fin à leur obligation déclarative. Cette obligation s'applique même lorsqu'elles n'ont versé aucune somme ni accordé aucun avantage au cours du mois précédant celui où la déclaration doit être transmise.</p>
<p>III. – Le déclarant dépose la déclaration sur le portail internet de l'organisme désigné par arrêté du ministre chargé du budget. La déclaration est transmise :</p>
<p>1° Pour les personnes qui relèvent du champ de l'article L. 133-5-3 du code de la sécurité sociale, aux organismes et dans les conditions mentionnés à l'article R. 133-13 du même code ;</p>
<p>2° Pour les personnes qui ne relèvent pas du champ de l'article L. 133-5-3 du code de la sécurité sociale, à l'administration fiscale, selon une norme technique approuvée par arrêté des ministres chargés du budget et de la sécurité sociale.</p>
<p>Pour préparer la déclaration, le portail réutilise les informations déjà légalement détenues par l'administration fiscale ou les organismes destinataires, lorsque leur réutilisation à cette fin est autorisée, et dispense le déclarant de les saisir à nouveau. Le déclarant peut consulter ces informations, en vérifier l'exactitude, les corriger et les compléter avant la transmission. Ce réemploi respecte les secrets protégés par la loi et ne fait pas obstacle aux demandes de rectification ou de mise à jour prévues à l'article 39 E.</p>
""",
    "Les échéances, les obligations de déclaration sans versement et les circuits de transmission sont réécrits à droit constant, en conservant leurs huit alinéas et subdivisions. Une réforme de fond est ajoutée à la fin du III pour appliquer la mesure « déclarer une fois » de policy.json : le portail existant réutilise les informations légalement disponibles et réutilisables, évite leur nouvelle saisie et permet au déclarant de les contrôler et de les corriger, dans le respect des secrets.",
    "L'ajout est placé après les deux branches du III : les alinéas antérieurs et leurs renvois ne sont pas déplacés. Coordonner les normes techniques de R. 133-13 et les arrêtés du III avec le réemploi ; aucune nouvelle habilitation d'accès à des données protégées n'est créée. Les rubriques de 39 C, les certificats et rectifications de 39 E et la compétence de 39 F demeurent applicables. La mensualité prescrite par l'article 87-0 A du CGI est maintenue. La note source du décret n° 2017-1676 fixe l'application historique au 1er janvier 2019 et non l'entrée en vigueur de ce nouvel alinéa. L'acte portant la réforme devra prévoir sa propre entrée en vigueur et l'adaptation du portail, sans date supposée ici.",
)

add(
    "39 E",
    """
<p>Dès réception d'une déclaration prévue à l'article 87-0 A du code général des impôts, les organismes mentionnés au III de l'article 39 D adressent à l'émetteur un certificat attestant la conformité de la déclaration à la norme d'échanges :</p>
<p>1° Mentionnée au III de l'article R. 133-13 du code de la sécurité sociale, pour les personnes qui relèvent du champ de l'article L. 133-5-3 du même code ;<br /><br />2° Mentionnée au 2° du III de l'article 39 D, pour les personnes qui ne relèvent pas du champ de l'article L. 133-5-3 du code de la sécurité sociale.</p>
<p>La délivrance de ce certificat n'empêche pas l'administration fiscale de demander à la personne tenue d'effectuer la retenue à la source de rectifier ou de mettre à jour les données inexactes ou incomplètes dans la déclaration du ou des mois suivants.</p>
""",
    "Réécriture à droit constant : l'objet du certificat est exprimé directement et la possibilité de demander des corrections est formulée dans une phrase plus courte. Les deux normes d'échanges, leurs champs respectifs et la correction dans le ou les mois suivants sont conservés, sans déplacement de l'alinéa final.",
    "La conformité à la norme d'échanges ne vaut pas validation fiscale des données. Le réemploi introduit au III de l'article 39 D proposé laisse subsister ces demandes de rectification et de mise à jour auprès de la personne tenue d'effectuer la retenue. La note source du décret n° 2017-1676 du 7 décembre 2017 conserve sa portée historique : revenus perçus ou réalisés à compter du 1er janvier 2019.",
)

add(
    "39 F",
    """
<p>Le déclarant transmet la déclaration prévue à l'article 87-0 A du code général des impôts au service des impôts des entreprises dont dépend le siège de l'établissement tenu d'opérer la retenue à la source prévue au 1° du 2 de l'article 204 A du même code.</p>
<p>Si la personne tenue d'effectuer cette retenue n'est pas établie en France, le service des impôts des entreprises étrangères est compétent pour cette déclaration.</p>
""",
    "Réécriture à droit constant : le déclarant est expressément chargé de la transmission au service compétent et le cas des personnes non établies en France reste énoncé séparément. Les deux alinéas et les critères de compétence sont maintenus. Aucun nouveau circuit de dépôt n'est créé.",
    "La compétence fiscale reste articulée avec le dépôt et la transmission par le portail de l'article 39 D ; le réemploi des données proposé à cet article ne la modifie pas. La note source prévoit l'application aux revenus perçus ou réalisés à compter du 1er janvier 2019 en vertu de l'article 6 du décret n° 2017-866, modifié par l'article 2 du décret n° 2017-1676. Les renvois à 87-0 A et au 1° du 2 de 204 A sont maintenus.",
)

add(
    "39 G",
    """
<p>Tout document mis à la disposition d'un contribuable qui indique le montant de revenus ayant fait l'objet du prélèvement prévu au 1° du 2 de l'article 204 A du code général des impôts doit également indiquer le montant de ce prélèvement.</p>
""",
    "Réécriture à droit constant : l'obligation d'afficher le prélèvement est énoncée directement pour chaque document concerné, sans modifier son champ ni le renvoi au CGI. Cet affichage ne crée aucun nouveau prélèvement.",
    "L'obligation reste limitée aux documents mentionnant des revenus soumis au prélèvement visé ; elle n'est pas étendue à l'ensemble des composantes du bulletin de paie. Le récapitulatif du coût employeur prévu par policy.json appelle ses dispositions propres dans le code du travail. La note source maintient l'application historique aux revenus perçus ou réalisés à compter du 1er janvier 2019, sans fixer la date d'une réforme future.",
)

add(
    "40 A",
    """
<p>I. - Les contribuables qui relèvent obligatoirement du régime de la déclaration contrôlée mentionné à l'article 96 du code général des impôts, ou qui ont opté pour ce régime, doivent produire chaque année, au plus tard le deuxième jour ouvré suivant le premier mai, une déclaration indiquant :</p>
<p>a) La nature de leur activité ;</p>
<p>b) Le cas échéant, la dénomination et l'adresse de la société ou du groupement au sein duquel ils exercent leur activité, ainsi que de la société civile de moyens dont ils font partie ;</p>
<p>c) La nature et le montant des services assurés régulièrement et rémunérés par des salaires ;</p>
<p>d) Le nombre total de salariés qu'ils emploient et le montant des salaires versés, après déduction des rémunérations payées à des apprentis ou à des personnes handicapées ;</p>
<p>e) Le nom et l'adresse du comptable ou du conseil dont ils utilisent, le cas échéant, les services ;</p>
<p>f) Le montant des plus-values nettes ;</p>
<p>g) Le tableau des immobilisations affectées à l'exercice de la profession et des amortissements correspondants ;</p>
<p>h) La nature et le montant des recettes retenues pour déterminer le résultat, ainsi que le montant des recettes nettes soumises à la contribution mentionnée à l'article 234 nonies du code général des impôts ;</p>
<p>i) La nature et le montant de leurs dépenses professionnelles ;</p>
<p>j) Le montant du bénéfice imposable ou du déficit ;</p>
<p>k) Le montant de la taxe sur la valeur ajoutée comprise dans les recettes ;</p>
<p>l) Pour les adhérents à une association agréée, le nom et l'adresse de cette association ;</p>
<p>m) Le calcul de la valeur ajoutée définie à l'article 1586 sexies du code général des impôts, selon le modèle établi par l'administration, lorsqu'ils sont soumis à l'obligation prévue au II de l'article 1586 octies du même code.</p>
<p>II. - Les personnes morales doivent également joindre :</p>
<p>1° La liste, établie selon le modèle fourni par l'administration, des personnes détenant au moins 10 % de leur capital. Pour chaque détenteur, cette liste précise le nombre de parts ou d'actions et le taux de détention. Pour les personnes morales, elle indique leur dénomination, leur adresse et leur numéro d'identification au répertoire national des établissements (numéro SIRET). Pour les personnes physiques, elle indique leurs nom, prénoms, adresse, date et lieu de naissance ;</p>
<p>2° La liste de leurs filiales et de leurs participations, établie selon le modèle fourni par l'administration. Pour chacune, cette liste précise le taux de détention et le numéro d'identification au répertoire national des établissements (numéro SIRET).</p>
<p>III. - Le contribuable adresse la déclaration et, le cas échéant, les listes mentionnées au II au service des impôts dont dépend le lieu d'exercice de la profession ou le principal établissement, en un seul exemplaire et au moyen des imprimés établis par l'administration.</p>
<p>Les personnes physiques qui exercent une activité professionnelle dans la Principauté de Monaco déposent leur déclaration auprès du service désigné par le ministre chargé du budget.</p>
<p>Pour préparer la déclaration et les listes prévues au présent article, l'administration met à la disposition du contribuable les informations qu'elle détient déjà légalement et dont la réutilisation à cette fin est autorisée. Le contribuable peut les consulter, les vérifier, les corriger et les compléter. Les informations ainsi réutilisées n'ont pas à être fournies une seconde fois au titre de la même déclaration, sauf lorsqu'une correction ou une mise à jour est nécessaire. Ce réemploi respecte les secrets protégés par la loi et ne dispense pas le contribuable de déclarer les informations manquantes.</p>
""",
    "Les rubriques de la déclaration contrôlée, les listes des personnes morales, l'échéance annuelle et les règles de compétence sont réécrites à droit constant ; les longues listes sont réparties en phrases dans leurs alinéas d'origine. Une réforme de fond est ajoutée au dernier alinéa du III pour appliquer le réemploi des données prévu par policy.json : les informations légalement disponibles et réutilisables sont mises à disposition, peuvent être corrigées et ne sont plus demandées en double pour la même déclaration.",
    "Les dix-neuf alinéas d'origine conservent leur place ; le réemploi est ajouté en vingtième alinéa. Maintien du deuxième jour ouvré suivant le premier mai, du seuil d'au moins 10 %, des exclusions de rémunérations au d et du service spécial pour Monaco. Les rubriques relatives aux associations agréées, à la contribution de l'article 234 nonies et à la valeur ajoutée des articles 1586 sexies et 1586 octies sont conservées : le projet n'autorise pas leur suppression générale. Coordonner les modèles de déclaration et de listes, ainsi que leurs modalités de mise à disposition, avec le nouvel alinéa ; il ne crée aucun droit d'accès à des données autrement protégées. Les renvois à 40 A, notamment dans 41-0 bis E, conservent leur objet. L'entrée en vigueur de cette mesure et l'adaptation des formulaires doivent être fixées par l'acte de réforme, sans date inventée.",
)

add(
    "41-0 bis",
    """
<p>Les membres des professions libérales et les titulaires de charges et offices qui réévaluent leurs immobilisations doivent joindre aux déclarations spéciales prévues à l'article 97 du code général des impôts un tableau des immobilisations et des amortissements. Ce tableau, établi sur un imprimé de l'administration, fait apparaître les augmentations de valeur des immobilisations résultant de la réévaluation ainsi que les suppléments de marge d'amortissements qu'elle dégage.</p>
""",
    "Réécriture à droit constant : la phrase unique est scindée en deux phrases qui identifient successivement l'obligation de joindre le tableau et son contenu. Le champ professionnel, le modèle administratif et les deux conséquences de la réévaluation sont maintenus dans le même alinéa.",
    "Le tableau demandé au contribuable demeure intégralement requis ; aucun tableau chiffré n'est contenu dans la source à reproduire. La notion de « suppléments de marge d'amortissements » est conservée sans lui substituer un nouveau mécanisme de déduction. Le renvoi à l'article 97 du CGI est maintenu. Les orientations générales sur l'investissement ne définissent ici aucune nouvelle règle de réévaluation ou d'amortissement.",
)

add(
    "41-0 bis A",
    """
<p>I. - Le contribuable adresse sa demande d'option prévue à l'article 93 A du code général des impôts, sur papier libre et en un seul exemplaire, au service des impôts dont dépend le lieu d'exercice de sa profession ou son principal établissement. Cette demande doit parvenir au service avant le 1er février de la première année au titre de laquelle l'impôt sur le revenu est établi selon l'article 93 A.</p>
<p>Toutefois, dans la situation prévue au troisième alinéa du I de l'article 93 A du code général des impôts, le délai est prolongé jusqu'à la date limite de dépôt de la déclaration prévue à l'article 97 du même code.</p>
<p>II. - Le contribuable renonce au bénéfice de l'article 93 A du code général des impôts selon les modalités prévues au premier alinéa du I du présent article.</p>
""",
    "Réécriture à droit constant : le contribuable devient le sujet de la demande et la présentation de celle-ci est séparée de son délai de réception. Les trois alinéas, l'exception de délai et la règle de renonciation sont conservés, sans réforme de l'option comptable.",
    "Le troisième alinéa du I de l'article 93 A a été vérifié dans le corpus : il concerne le commencement d'activité en cours d'année. La renonciation continue à renvoyer au seul premier alinéa du I de l'article réécrit, sans extension de l'exception du deuxième alinéa. Maintien du délai strictement antérieur au 1er février. La note source relative à la loi n° 2020-473 du 20 avril 2020, article 3-I-4°, est historique et ne fixe pas une nouvelle entrée en vigueur.",
)

add(
    "41-0 bis B",
    """
<p>I. - Pour l'application de l'article 93 A du code général des impôts, les recettes encaissées qui correspondent à des créances acquises au cours d'une année antérieure à celle de l'option, pour laquelle le bénéfice était déterminé selon l'article 93 du même code, sont ajoutées au bénéfice de l'année de leur encaissement. Les dépenses payées qui correspondent à des dépenses engagées au cours d'une telle année sont déduites du bénéfice de l'année de leur paiement. Les avances, acomptes ou provisions encaissés et les acomptes sur dépenses payés au cours d'une année antérieure à l'application de l'article 93 A, pour laquelle le bénéfice était déterminé selon l'article 93, sont déduits, lorsqu'il y a lieu, du montant des créances acquises ou des dépenses engagées correspondantes.</p>
<p>II. - Pour l'année au titre de laquelle le contribuable renonce à l'application de l'article 93 A du code général des impôts et, le cas échéant, pour les années suivantes, les dépenses payées qui correspondent à des dépenses engagées au cours d'une année antérieure à celle de la renonciation, pour laquelle le bénéfice était déterminé selon cet article, sont ajoutées au bénéfice imposable déterminé selon l'article 93 du même code. Les recettes encaissées au cours de ces mêmes années qui correspondent à des créances acquises au cours d'une telle année antérieure sont déduites de ce bénéfice. Les avances, acomptes ou provisions encaissés et les acomptes sur dépenses payés pendant la période d'application de l'article 93 A, qui ne correspondaient pas à des créances acquises ou à des dépenses engagées, sont ajoutés, selon le cas, au montant des recettes encaissées ou des dépenses payées au cours de l'année au titre de laquelle la renonciation prend effet.</p>
""",
    "Réécriture à droit constant : chaque mécanisme autrefois exprimé par « respectivement » est explicité, afin de distinguer l'ajout des recettes et la déduction des dépenses à l'entrée dans l'option, puis l'ajout des dépenses et la déduction des recettes à la sortie. Les deux alinéas I et II et les règles relatives aux avances, acomptes et provisions restent à leur place.",
    "Contrôler la lecture comptable avec les articles 93 et 93 A : au I, recettes ajoutées et dépenses déduites au moment de l'encaissement ou du paiement ; au II, dépenses ajoutées et recettes déduites pour éviter une seconde prise en compte. Les régularisations des avances restent conditionnées à leur rattachement et, au II, à l'absence de créance acquise ou de dépense engagée correspondante pendant l'option. Aucune année de transition, franchise ou nouvelle méthode d'imposition n'est créée.",
)

add(
    "41-0 bis C",
    """
<p>Pour la première année au titre de laquelle l'impôt est établi en application de l'article 93 A du code général des impôts, les contribuables joignent à la déclaration spéciale prévue à l'article 97 du même code un état des créances et des dettes au 31 décembre de l'année précédant celle au titre de laquelle l'option est exercée. Cet état est établi selon le modèle fixé par l'administration.</p>
<p>Chaque année, tant que l'option n'est pas dénoncée, les contribuables adressent à l'administration, selon les mêmes modalités, un état de ces créances et dettes actualisé au 31 décembre de l'année d'imposition. Ils l'accompagnent, lorsqu'il y a lieu, d'une note sur papier libre détaillant les corrections opérées en application de l'article 41-0 bis B. Cette note indique le nom et l'adresse des débiteurs ou des créanciers concernés, la date de l'opération à l'origine de la constatation de la créance ou de la dette, son montant ainsi que le montant sur lequel porte chaque correction.</p>
""",
    "Réécriture à droit constant : les contribuables sont expressément désignés comme responsables des états et de la note, et les phrases sont scindées sans déplacer les deux alinéas. L'état initial, son actualisation annuelle et tous les éléments justificatifs des corrections sont conservés.",
    "Maintien des deux dates de référence distinctes : 31 décembre de l'année précédant celle de l'option pour l'état initial, puis 31 décembre de l'année d'imposition pour chaque actualisation. L'état annuel porte sur ces mêmes créances et dettes ; la rédaction ne le transforme pas en un inventaire nouveau de toutes les créances et dettes nées sous l'option. Le modèle administratif et la note sur papier libre renvoyant à 41-0 bis B sont maintenus.",
)

add(
    "41-0 bis D",
    """
<p>L'application du premier alinéa de l'article 93 B du code général des impôts est subordonnée à une demande signée conjointement :</p>
<p>– en cas de transmission des titres, par l'associé dont les titres sont transmis ou, si la transmission résulte de son décès, par ses ayants cause, et par le ou les bénéficiaires de la transmission ;</p>
<p>– en cas de rachat des titres par la société, par l'associé dont les titres sont rachetés et par les associés présents dans la société à la date du rachat.</p>
<p>La société adresse cette demande, établie sur papier libre et en un seul exemplaire, à la direction départementale ou, le cas échéant, régionale des finances publiques auprès de laquelle elle souscrit ses déclarations de résultats. Elle l'adresse dans les soixante jours à compter du jour de la transmission ou du rachat des titres.</p>
<p>L'associé dont les titres sont transmis ou rachetés joint une copie de la demande à sa déclaration de revenus prévue à l'article 170 du code général des impôts, afférente à l'année de la transmission des titres. Si la transmission résulte du décès du contribuable, ses ayants cause joignent cette copie à la déclaration établie au nom du défunt et prévue au 2 de l'article 204 du même code.</p>
""",
    "Réécriture à droit constant : les signataires sont présentés directement pour chacune des deux opérations, puis la société est désignée comme responsable de l'envoi. Les cinq alinéas, le délai de soixante jours, la copie et le traitement du décès sont conservés.",
    "Le premier alinéa de l'article 93 B a été vérifié dans le corpus : les signataires et l'option d'imposition immédiate correspondent. Imprécision préexistante conservée au dernier alinéa : l'associé dont les titres sont « transmis ou rachetés » doit joindre la copie à la déclaration afférente à « l'année de la transmission », sans mention expresse de l'année du rachat. Une clarification de ce dernier cas doit être décidée explicitement, plutôt qu'introduite silencieusement. Le délai de soixante jours pour la demande reste distinct de l'exception liée au décès pour les déclarations prévue à l'article 41-0 bis E.",
)

add(
    "41-0 bis E",
    """
<p>Pour l'application du premier alinéa de l'article 93 B du code général des impôts, la société détermine, sur une déclaration spéciale établie conformément à l'article 40 A, le résultat réalisé depuis la fin de sa dernière période d'imposition jusqu'à la date de la transmission ou du rachat des titres.</p>
<p>L'associé dont les titres sont transmis ou rachetés est immédiatement imposable sur sa quote-part du résultat de la société arrêté dans les conditions du premier alinéa. Cette quote-part est inscrite sur le formulaire de déclaration prévu à l'article 48.</p>
<p>Les déclarations mentionnées aux premier et deuxième alinéas sont adressées, dans les soixante jours à compter du jour de la transmission ou du rachat des titres, à la direction départementale ou, le cas échéant, régionale des finances publiques auprès de laquelle la société souscrit ses déclarations. Toutefois, si la transmission résulte du décès du contribuable, elles sont adressées à cette même direction dans le délai prévu au 2 de l'article 204 du code général des impôts.</p>
""",
    "La société est désignée comme le sujet du calcul du résultat intermédiaire, et l'assiette immédiate de l'associé ainsi que les délais sont formulés plus directement. Ces règles sont réécrites à droit constant, en conservant les trois alinéas et leurs renvois ordinaux. Par coordination de fond, le renvoi à 40 A permet le réemploi des données proposé à cet article pour préparer la déclaration, sans modifier l'option de l'article 93 B ni ses délais propres.",
    "Les articles 93 B du CGI et 48 de l'annexe III ont été consultés dans le corpus. Maintien de la période allant de la fin de la dernière période d'imposition à la date de l'opération, du délai ordinaire de soixante jours et de la dérogation du 2 de l'article 204 en cas de décès. Le renvoi à 40 A comprend la mesure de réemploi proposée pour préparer la déclaration, mais ne modifie ni cette période spéciale ni les délais propres au présent article. Les premier et deuxième alinéas demeurent les cibles du troisième.",
)

add(
    "41-0 bis F",
    """
<p>Pour l'application du second alinéa de l'article 93 B du code général des impôts, l'associé bénéficiaire de la transmission des titres ou, en cas de rachat des titres, les associés présents dans la société au 31 décembre de l'année d'imposition joignent à leur déclaration de revenus prévue à l'article 170 du même code une note sur papier libre. Cette note détaille le calcul de la quote-part du résultat de la société imposable à leur nom selon le second alinéa de l'article 93 B.</p>
""",
    "Réécriture à droit constant : une première phrase désigne les associés tenus de joindre la note, puis une seconde précise le contenu de celle-ci. Le renvoi au second alinéa de l'article 93 B et la distinction entre transmission et rachat sont maintenus dans l'alinéa unique.",
    "Le second alinéa de l'article 93 B a été vérifié dans le corpus. En cas de rachat, la référence reste celle des associés présents au 31 décembre de l'année d'imposition, à distinguer des associés présents à la date du rachat qui signent la demande de 41-0 bis D. Maintien du support sur papier libre et du rattachement à la déclaration de l'article 170 du CGI.",
)

add(
    "41 bis",
    """
<p>Les sociétés qui souhaitent bénéficier du 2° de l'article 112 du code général des impôts déposent une demande spéciale au bureau compétent pour l'assiette de la retenue à la source sur le revenu des capitaux mobiliers, dans les vingt jours à compter de la date de la décision d'amortissement. Elles joignent à cette demande un état détaillé et estimatif de tous les biens composant l'actif social au jour de la demande, ainsi que de tous les éléments du passif.</p>
<p>L'actif est estimé à sa valeur réelle, quelles que soient les évaluations figurant dans les bilans et les autres documents.</p>
""",
    "Réécriture à droit constant : la demande et ses pièces jointes sont présentées en deux phrases, puis la règle de valeur réelle est formulée directement. Le délai de vingt jours, la date d'évaluation et l'intégralité de l'actif et du passif sont conservés dans les deux alinéas d'origine.",
    "Le 2° de l'article 112 du CGI, consulté dans le corpus, vise un régime spécial d'amortissement du capital des sociétés concessionnaires de collectivités publiques, non un régime général d'amortissement des investissements. Les mesures générales sur l'entreprise ne sont pas étendues à ce régime. Le délai court de la décision d'amortissement, alors que l'état porte sur les biens au jour de la demande ; ces dates distinctes sont maintenues. La terminologie historique relative au bureau compétent et à la retenue à la source est conservée.",
)

add(
    "41 ter",
    """
<p>La société joint également à la demande prévue à l'article 41 bis les déclarations suivantes :</p>
<p>a Si la demande est fondée sur la caducité de tout ou partie de l'actif social, notamment sur son dépérissement progressif, une déclaration indiquant les causes, la nature et l'importance de la moins-value qui doit se produire dans cet actif ;</p>
<p>b Si la demande est fondée sur l'obligation de remettre à l'autorité concédante, en fin de concession, tout ou partie de l'actif social, une déclaration détaillée et, s'il y a lieu, estimative, portant, d'une part, sur l'actif social actuel et, d'autre part, sur les biens à remettre à l'autorité concédante en fin de concession.</p>
""",
    "Réécriture à droit constant : la société est expressément chargée de joindre les déclarations et les conditions d'application de chaque branche sont placées en tête. Les lettres a et b, les trois alinéas et tous les éléments d'évaluation sont conservés.",
    "Les pièces s'ajoutent à celles de 41 bis. Le a maintient une moins-value à venir et la caducité totale ou partielle, y compris le dépérissement progressif. Le b conserve la distinction entre actif actuel et biens à remettre, ainsi que le caractère seulement éventuel de l'estimation. Le régime spécial du 2° de l'article 112 du CGI n'est pas étendu par la réforme.",
)

add(
    "41 quater",
    """
<p>En cas de contestation des déclarations estimatives prévues aux articles 41 bis et 41 ter, s'appliquent la procédure de saisine de la commission départementale de conciliation prévue au 2 de l'article 667 du code général des impôts et la procédure de rectification contradictoire prévue à l'article L. 55 du livre des procédures fiscales.</p>
""",
    "Réécriture à droit constant : la phrase distingue clairement les deux procédures applicables et rattache chacune à son texte de référence. L'alinéa unique et les renvois sont maintenus, sans modification du droit de contestation.",
    "Le 2 de l'article 667 du CGI a été vérifié dans le corpus : il prévoit la saisine de la commission départementale de conciliation. Le renvoi à L. 55 du LPF est maintenu ; ce livre n'est pas fourni parmi les fichiers du corpus consulté. Aucune procédure ni compétence nouvelle n'est créée et les deux références restent cumulativement applicables selon la source.",
)

add(
    "41 quinquies",
    """
<p>Pour chaque opération d'amortissement, l'exonération prévue au 2° de l'article 112 du code général des impôts est accordée à concurrence de la fraction du capital social qui ne pourrait être retrouvée au moment de l'opération. Cette fraction est déterminée en tenant compte des amortissements déjà effectués en franchise d'impôt.</p>
""",
    "Réécriture à droit constant : la limite de l'exonération et la prise en compte des amortissements antérieurs sont exprimées dans deux phrases, au sein du même alinéa. Le champ du régime spécial et le moment de l'appréciation sont conservés ; aucune exonération des bénéfices réinvestis n'est créée.",
    "La formule ancienne « le capital social ne pourrait se retrouver » est explicitée par une fraction non retrouvée, sans créer de méthode d'évaluation nouvelle. Le rattachement au 2° de l'article 112 du CGI et aux sociétés concessionnaires demeure. Les amortissements déjà effectués en franchise d'impôt doivent être pris en compte et ne peuvent ouvrir une seconde fois droit à l'exonération.",
)

add(
    "41 octies",
    """
<p>Pour les obligations, effets publics et autres titres d'emprunt négociables dont les primes de remboursement sont assujetties, par l'article 118 du code général des impôts, à la retenue à la source sur le revenu des capitaux mobiliers, le taux unique d'émission, lorsqu'il existe, sert de base à la liquidation de l'impôt sur ces primes.</p>
<p>Si le taux d'émission a varié, il est calculé séparément pour chaque emprunt. Ce taux moyen est égal au montant brut total de l'emprunt, diminué des seuls intérêts courus au moment de chaque vente, divisé par le nombre de titres correspondant à cet emprunt.</p>
<p>Si l'émission d'un emprunt à des taux variables n'est pas terminée, la moyenne est calculée d'après la situation de l'emprunt au 31 décembre de l'année précédant celle du tirage.</p>
""",
    "Réécriture à droit constant : le cas du taux unique, la formule de moyenne par emprunt et le cas d'une émission inachevée sont présentés dans les trois alinéas d'origine. Le numérateur, le dénominateur, la seule déduction autorisée et la date de référence sont explicités sans changer le calcul.",
    "Le « taux d'émission » reste un paramètre de l'emprunt, distinct d'un taux d'impôt. Le montant brut ne subit que la déduction des intérêts courus lors de chaque vente ; la moyenne d'une émission inachevée reste arrêtée au 31 décembre de l'année précédant le tirage. Point préexistant à contrôler : dans le corpus, l'article 118 qualifie les revenus, dont les lots et primes, sans énoncer lui-même l'assujettissement à la retenue formulé ici. Ce rattachement historique est conservé, sans conclure à la suppression du régime ni lui substituer un prélèvement moderne.",
)

add(
    "41 nonies",
    """
<p>Si le taux d'émission ne peut être déterminé selon l'article 41 octies, il est représenté par un capital égal à vingt fois l'intérêt annuel stipulé, lors de l'émission, au profit du porteur du titre.</p>
<p>Si aucun intérêt n'a été stipulé, le taux d'émission est fixé au moyen d'une déclaration estimative certifiée et signée.</p>
""",
    "Réécriture à droit constant : les deux hypothèses subsidiaires sont formulées directement, en conservant les deux alinéas. Le multiplicateur de vingt, la référence à l'intérêt annuel stipulé à l'émission et la déclaration certifiée et signée demeurent inchangés.",
    "L'article ne s'applique qu'à défaut de détermination selon 41 octies ; l'absence de stipulation d'intérêts déclenche ensuite la déclaration estimative. Le capital représentant le taux d'émission n'est ni un nouveau taux fiscal ni une actualisation financière. La source ne désigne pas l'auteur de la certification ; la proposition n'invente pas de qualité de certificateur.",
)

add(
    "41 decies",
    """
<p>Les sociétés, compagnies, entreprises et tous les autres assujettis au paiement de la retenue à la source doivent communiquer aux agents des impôts les documents et écritures relatifs aux lots et primes de remboursement. Cette obligation s'applique au siège social comme dans les succursales ou les agences.</p>
""",
    "Réécriture à droit constant : l'obligation de communication et les lieux où elle s'applique sont exposés en deux phrases, sans changer l'alinéa unique. L'ensemble des assujettis et les documents et écritures relatifs aux lots et primes sont conservés.",
    "La communication aux agents des impôts est distincte d'une nouvelle saisie déclarative ; la mesure de réemploi des données ne supprime pas ce contrôle. Le champ demeure celui des assujettis à la retenue à la source du régime concerné, avec communication tant au siège que dans les succursales ou agences. Aucun pouvoir d'accès ou destinataire supplémentaire n'est ajouté.",
)

add(
    "41 undecies",
    """
<p>Les obligations, effets publics et titres d'emprunt des sociétés et collectivités étrangères désignées aux 1°, 2° et 7° de l'article 120 du code général des impôts sont soumis aux dispositions précédentes.</p>
""",
    "Réécriture à droit constant : l'application du dispositif aux titres étrangers est exprimée directement, avec maintien des trois catégories de titres et des trois subdivisions de l'article 120. Aucune extension à d'autres personnes ou produits étrangers n'est introduite.",
    "La formule collective « dispositions précédentes » est conservée plutôt que remplacée par une liste supposée d'articles, afin de ne pas modifier silencieusement la portée de ce renvoi historique. Les références aux seuls 1°, 2° et 7° de l'article 120 du CGI sont maintenues. Les dispositions relatives aux primes de remboursement ne sont pas transformées en régime fiscal général des capitaux étrangers.",
)


def main():
    source = json.loads(Path("source.json").read_text())
    assert len(source) == 24
    assert len(drafts) == 24
    assert {s["number"] for s in source} == set(drafts)
    answer = []
    for article in source:
        item = {key: article[key] for key in (
            "code_id", "source_id", "source_sha256", "number"
        )}
        item.update(drafts[article["number"]])
        item["status"] = "rewrite_draft"
        answer.append(item)
    Path("answer.json").write_text(
        json.dumps(answer, ensure_ascii=False, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
